import { ThinkingLevel, Type } from "@google/genai";
import {
  extractGroundingSources,
  formatGeminiError,
  generateContentResilient,
  generateContentStreamResilient,
  getGeminiClient,
  LITE_FALLBACK_MODEL,
  PRIMARY_MODEL,
} from "./gemini.ts";
import type {
  AgentId,
  AgentMessage,
  CrewPhase,
  GroundedSource,
  LessonDetailSection,
  LessonKeyPoint,
  LessonOverview,
  LessonStructureDiagram,
  ResearchClaim,
  StudentProfileContext,
  StructureDiagramBranch,
} from "../src/types.ts";

export interface InvestigateRequest {
  topic: string;
  depth: "standard" | "deep";
  studentContext?: StudentProfileContext;
  image?: {
    mimeType: string;
    data: string;
    name?: string;
  };
}

export type SseEmitter = (event: string, data: unknown) => void;

const AGENT_PROFILES: Record<
  AgentId,
  { name: string; role: string }
> = {
  researcher: {
    name: "Elena Vance",
    role: "Concept Explorer & Syllabus Researcher",
  },
  fact_checker: {
    name: "Marcus Thorne",
    role: "Doubt Solver & Fact-Checker",
  },
  editor: {
    name: "Clara Lin",
    role: "Study Notes Editor & Exam Coach",
  },
};

function makeMessage(
  agentId: AgentId,
  phase: CrewPhase,
  headline: string,
  content: string,
  extra?: Partial<AgentMessage>
): AgentMessage {
  return {
    id: `${agentId}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    agentId,
    agentName: AGENT_PROFILES[agentId].name,
    agentRole: AGENT_PROFILES[agentId].role,
    phase,
    timestamp: new Date().toISOString(),
    headline,
    content,
    ...extra,
  };
}

export async function generateLessonOverviewWithGemini(
  ai: ReturnType<typeof getGeminiClient>,
  topic: string,
  sc?: StudentProfileContext,
  researchMemo?: string,
  fastBackground = false
): Promise<LessonOverview> {
  const audience = sc
    ? `${sc.studentClass} CBSE (NCERT) · Subject: ${sc.subject}${
        sc.lessonTitle ? ` · Lesson: "${sc.lessonTitle}"` : ""
      }`
    : "CBSE school student (Classes 6–12)";

  const memoBlock = researchMemo
    ? `\nReference Lesson Notes:\n${researchMemo.slice(0, 6000)}\n`
    : "";

  const resp = await generateContentResilient(ai, {
    model: fastBackground ? LITE_FALLBACK_MODEL : PRIMARY_MODEL,
    contents: `Create a COMPLETE Gemini Study Loop package for ONLY this CBSE NCERT chapter:
Target: ${audience}
Topic: "${topic}"${memoBlock}

Return strictly valid JSON with ALL FOUR parts populated completely:
1. "fullSummary": 2–3 clear paragraphs (~200 words total) explaining every major concept of this lesson in simple words.
2. "keyPoints": 8 to 10 crisp exam Key Points (each 1–2 sentences) with a short tag ("Concept", "Formula", "Law", "Process", or "Exam Tip").
3. "allDetailsSections": EXACTLY 5 or 6 distinct subtopic objects covering the ENTIRE chapter from start to end (every important topic included):
   - "title": Clear subtopic heading (under 55 chars)
   - "content": 3–4 crisp sentences explaining everything in this subtopic clearly + common exam trap
   - "formulaOrRule": 1 single concise line (under 140 chars) giving the exact formula with units, balanced equation, or grammar/core rule
   - "example": 1–2 concise sentences (under 220 chars) showing a step-by-step NCERT or daily-life example.
4. "structureDiagram": Visual map showing the structure of this lesson:
   - "diagramTitle": Under 56 chars
   - "diagramType": "hierarchy", "process", or "concept_map"
   - "centralTitle": Under 34 chars
   - "centralSubtitle": Under 56 chars
   - "branches": 4 to 6 branch objects, each with "title" (under 28 chars), optional "subtitle" (under 34 chars), "accent" ("blue"|"indigo"|"emerald"|"amber"|"rose"|"violet"), and "items" (3 short bullets under 44 chars each).`,
    config: {
      maxOutputTokens: 8192,
      ...(fastBackground
        ? {}
        : { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }),
      systemInstruction:
        "You are Gemini Study Architect for CBSE Classes 6–12. Follow field length limits strictly so every array (8–10 keyPoints, 5–6 allDetailsSections, 4–6 branches) is populated cleanly without rambling.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          fullSummary: { type: Type.STRING },
          keyPoints: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                tag: { type: Type.STRING },
                point: { type: Type.STRING },
              },
              required: ["id", "tag", "point"],
            },
          },
          allDetailsSections: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                content: { type: Type.STRING },
                formulaOrRule: { type: Type.STRING },
                example: { type: Type.STRING },
              },
              required: ["title", "content", "formulaOrRule", "example"],
            },
          },
          structureDiagram: {
            type: Type.OBJECT,
            properties: {
              diagramTitle: { type: Type.STRING },
              diagramType: { type: Type.STRING },
              centralTitle: { type: Type.STRING },
              centralSubtitle: { type: Type.STRING },
              branches: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    subtitle: { type: Type.STRING },
                    accent: { type: Type.STRING },
                    items: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                    },
                  },
                  required: ["title", "items"],
                },
              },
            },
            required: [
              "diagramTitle",
              "diagramType",
              "centralTitle",
              "centralSubtitle",
              "branches",
            ],
          },
        },
        required: [
          "fullSummary",
          "keyPoints",
          "allDetailsSections",
          "structureDiagram",
        ],
      },
    },
  });

  const parsed = JSON.parse((resp.text || "{}").trim()) as {
    fullSummary?: string;
    keyPoints?: LessonKeyPoint[];
    allDetailsSections?: Array<{
      title: string;
      content: string;
      formulaOrRule?: string;
      example?: string;
    }>;
    structureDiagram?: Partial<LessonStructureDiagram>;
  };

  const validAccents = new Set([
    "blue",
    "indigo",
    "emerald",
    "amber",
    "rose",
    "violet",
  ]);
  const fallbackAccents: Array<StructureDiagramBranch["accent"]> = [
    "blue",
    "indigo",
    "emerald",
    "amber",
    "rose",
    "violet",
  ];

  const keyPoints = (Array.isArray(parsed.keyPoints) ? parsed.keyPoints : [])
    .slice(0, 10)
    .map((kp, i) => ({
      id: kp.id || `KP${i + 1}`,
      tag: kp.tag || "Key Point",
      point: kp.point,
    }));

  let allDetailsSections: LessonDetailSection[] = (
    Array.isArray(parsed.allDetailsSections) ? parsed.allDetailsSections : []
  )
    .slice(0, 8)
    .map((sec, i) => ({
      title: String(sec.title || `Topic ${i + 1}`).trim(),
      content: String(sec.content || "").trim(),
      formulaOrRule: sec.formulaOrRule?.trim().slice(0, 260) || undefined,
      example: sec.example?.trim().slice(0, 360) || undefined,
    }))
    .filter((sec) => sec.content.length > 0);

  const rawDiagram = parsed.structureDiagram || {};
  const rawType = String(rawDiagram.diagramType || "concept_map");
  const diagramType: LessonStructureDiagram["diagramType"] =
    rawType === "hierarchy" || rawType === "process" ? rawType : "concept_map";

  let branches: StructureDiagramBranch[] = (
    Array.isArray(rawDiagram.branches) ? rawDiagram.branches : []
  )
    .slice(0, 6)
    .map((b, i) => ({
      title: String(b.title || `Part ${i + 1}`).slice(0, 38),
      subtitle: b.subtitle ? String(b.subtitle).slice(0, 44) : undefined,
      accent: validAccents.has(String(b.accent))
        ? (b.accent as StructureDiagramBranch["accent"])
        : fallbackAccents[i % fallbackAccents.length],
      items: (Array.isArray(b.items) ? b.items : [])
        .slice(0, 4)
        .map((it) => String(it).slice(0, 56)),
    }))
    .filter((b) => b.items.length > 0 || b.title.length > 0);

  // Guarantee populated branches & detail sections via cross-derivation if either is sparse
  if (branches.length < 3 && allDetailsSections.length > 0) {
    branches = allDetailsSections.slice(0, 6).map((sec, i) => ({
      title: sec.title.slice(0, 34),
      subtitle: sec.formulaOrRule
        ? sec.formulaOrRule.slice(0, 40)
        : undefined,
      accent: fallbackAccents[i % fallbackAccents.length],
      items: [
        sec.content.split(/[.!?]/)[0]?.trim().slice(0, 52) || sec.title,
        ...(sec.formulaOrRule ? [sec.formulaOrRule.slice(0, 52)] : []),
        ...(sec.example ? [`Ex: ${sec.example.slice(0, 48)}`] : []),
      ].slice(0, 3),
    }));
  }

  if (allDetailsSections.length < 2 && branches.length > 0) {
    allDetailsSections = branches.map((b, i) => ({
      title: b.title,
      content: `${b.subtitle ? `${b.subtitle}. ` : ""}${b.items.join(". ")}.`,
      formulaOrRule: keyPoints[i]?.point,
    }));
  }

  return {
    lessonTitle: sc?.lessonTitle,
    fullSummary:
      parsed.fullSummary?.trim() ||
      `Complete CBSE summary for ${sc?.lessonTitle || topic}.`,
    keyPoints,
    allDetailsSections,
    structureDiagram: {
      diagramTitle:
        rawDiagram.diagramTitle ||
        `${sc?.lessonTitle || "Lesson"} — Structure Map`,
      diagramType,
      centralTitle:
        rawDiagram.centralTitle || sc?.lessonTitle || topic.slice(0, 34),
      centralSubtitle:
        rawDiagram.centralSubtitle ||
        `${sc?.studentClass || "CBSE"} ${sc?.subject || "Study"} Structure`,
      branches,
    },
    generatedBy: "Gemini",
  };
}

export async function runCrewInvestigation(
  req: InvestigateRequest,
  emit: SseEmitter,
  signal: AbortSignal
): Promise<void> {
  const ai = getGeminiClient();
  const topic = req.topic.trim();
  const thinkingDepth =
    req.depth === "deep" ? ThinkingLevel.HIGH : ThinkingLevel.MEDIUM;

  const sc = req.studentContext;
  const boardDisplay = "CBSE (NCERT)";
  const studentAudienceLine = sc
    ? `Target Student Profile: ${sc.studentClass} · ${boardDisplay} · Subject: ${sc.subject}${
        sc.lessonTitle ? ` · Lesson: "${sc.lessonTitle}"` : ""
      }`
    : "Target Audience: CBSE school student (Classes 6–12), crystal-clear conceptual explanation.";

  const sourcesMap = new Map<string, GroundedSource>();
  const allSources: GroundedSource[] = [];

  const registerSources = (
    raw: Array<{ title: string; url: string; domain: string }>,
    discoveredBy: AgentId
  ): GroundedSource[] => {
    const added: GroundedSource[] = [];
    for (const item of raw) {
      if (!sourcesMap.has(item.url)) {
        const entry: GroundedSource = {
          id: allSources.length + 1,
          title: item.title,
          url: item.url,
          domain: item.domain,
          discoveredBy,
        };
        sourcesMap.set(item.url, entry);
        allSources.push(entry);
        added.push(entry);
      }
    }
    if (added.length > 0) {
      emit("sources_discovered", { sources: allSources });
    }
    return added;
  };

  const checkAborted = () => {
    if (signal.aborted) {
      throw new Error("Study loop stopped by student.");
    }
  };

  try {
    // -------------------------------------------------------------------------
    // STEP 0: VISUAL EVIDENCE / TEXTBOOK PHOTO ANALYSIS (If attached)
    // -------------------------------------------------------------------------
    let visualBrief = "";
    if (req.image?.data && req.image?.mimeType) {
      checkAborted();
      emit("phase_change", { phase: "analyzing_image", iterationLoop: 1 });

      const visualResp = await generateContentResilient(ai, {
        model: PRIMARY_MODEL,
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: req.image!.mimeType,
                data: req.image!.data,
              },
            },
            {
              text: `You are Elena Vance, Concept Explorer helping a student (${studentAudienceLine}). The student attached this visual ("${
                req.image?.name || "uploaded study image"
              }") for the study topic: "${topic}".
Read and explain what is shown in plain, neat student-friendly language: extract any formulas, diagrams, labels, questions, numbers, or textbook steps visible, and note any tricky parts to verify.`,
            },
          ],
        },
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.MEDIUM },
        },
      });

      visualBrief = visualResp.text?.trim() || "Visual study attachment inspected.";
      emit("visual_brief", { visualBrief });
      emit(
        "agent_message",
        makeMessage(
          "researcher",
          "analyzing_image",
          "Examined uploaded diagram / textbook visual",
          visualBrief
        )
      );
    }

    // -------------------------------------------------------------------------
    // STEP 1: STUDENT STUDY PLAN & CONCEPT DECOMPOSITION (Agent 1)
    // -------------------------------------------------------------------------
    checkAborted();
    emit("phase_change", { phase: "planning", iterationLoop: 1 });

    const planResp = await generateContentResilient(ai, {
      model: LITE_FALLBACK_MODEL,
      contents: `${studentAudienceLine}
Study Lesson / Topic: "${topic}"
${visualBrief ? `\nAttached Visual Summary:\n${visualBrief}\n` : ""}
Focus STRICTLY on THIS lesson only. Break this entire CBSE lesson down so NOTHING from the chapter is left out. Formulate 4 comprehensive search queries covering:
(1) All core concepts, subtopics & plain-language explanations in this exact lesson,
(2) Every definition, law, chemical/math formula, rule, or diagram structure in this lesson,
(3) Step-by-step solved NCERT/textbook examples & real-life applications,
(4) Common exam mistakes & high-weightage CBSE board/school questions for this lesson.`,
      config: {
        systemInstruction:
          "You are Elena Vance, Concept Explorer & Syllabus Researcher. Keep plans encouraging, structured, and matched strictly to the student's class level (6 to 12).",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            strategySummary: {
              type: Type.STRING,
              description:
                "A friendly 2-3 sentence study roadmap explaining how we will master this topic easily.",
            },
            subQueries: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Exactly 4 targeted study & syllabus search sub-queries.",
            },
          },
          required: ["strategySummary", "subQueries"],
        },
      },
    });

    const planJson = JSON.parse((planResp.text || "{}").trim()) as {
      strategySummary?: string;
      subQueries?: string[];
    };
    const subQueries = (planJson.subQueries || [topic]).slice(0, 4);
    const strategySummary =
      planJson.strategySummary ||
      `Organized the lesson into ${subQueries.length} easy-to-follow learning steps.`;

    emit("plan_ready", { subQueries, strategySummary });
    emit(
      "agent_message",
      makeMessage(
        "researcher",
        "planning",
        "Lesson roadmap & concept breakdown",
        strategySummary,
        { subQueries }
      )
    );

    // -------------------------------------------------------------------------
    // STEP 2: LIVE SYLLABUS & CONCEPT GROUNDING (Agent 1: Concept Explorer)
    // -------------------------------------------------------------------------
    checkAborted();
    emit("phase_change", { phase: "researching", iterationLoop: 1 });

    const researchResp = await generateContentResilient(ai, {
      model: PRIMARY_MODEL,
      contents: `${studentAudienceLine}
Teach ONLY and COMPLETELY this exact CBSE lesson/topic: "${topic}"
${visualBrief ? `\nInclude details from the attached visual:\n${visualBrief}\n` : ""}
Answer these 4 learning tracks thoroughly using live Google Search for up-to-date NCERT / CBSE accuracy so the student gets EVERYTHING in this lesson in one place:
${subQueries.map((q, i) => `${i + 1}. ${q}`).join("\n")}

Cover EVERY part of this lesson clearly and neatly for a ${sc?.studentClass || "CBSE"} student:
- Every subtopic and section in the NCERT chapter (don't skip minor topics!)
- Simple everyday analogies so each concept clicks immediately
- All definitions, laws, properties, reactions, derivations, or formulas with SI units
- Step-by-step worked examples / solved problems
- Diagrams or processes explained step-by-step in clear words`,
      config: {
        systemInstruction:
          "You are Elena Vance, Concept Explorer. Stay 100% inside the requested CBSE lesson and teach every single subtopic completely and clearly at the student's class level (6 to 12). Use simple language, vivid examples, and Google Search for NCERT syllabus accuracy.",
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingLevel: thinkingDepth },
      },
    });

    const rawResearchMemo =
      researchResp.text?.trim() || "No study notes returned.";
    const round1Sources = extractGroundingSources(researchResp);
    registerSources(round1Sources, "researcher");

    // Extract 8–10 key concepts / facts for Marcus to audit
    const claimsExtractResp = await generateContentResilient(ai, {
      model: LITE_FALLBACK_MODEL,
      contents: `Extract 8 to 10 key study concepts, subtopics, definitions, formulas, or syllabus facts from this study memo (covering the whole lesson cleanly) so our Fact-Checker can verify them for the student.
Study Memo:
${rawResearchMemo}

Available Grounded Source IDs:
${allSources.map((s) => `[${s.id}] ${s.title} (${s.domain})`).join("\n")}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING, description: "e.g. K1, K2..." },
              statement: {
                type: Type.STRING,
                description:
                  "Clear, concise concept, formula, or syllabus fact.",
              },
              category: {
                type: Type.STRING,
                description:
                  "Short label e.g. Core Concept, Formula, Example, Syllabus Fact",
              },
              confidence: {
                type: Type.STRING,
                description: "high, medium, or low",
              },
              sourceIds: {
                type: Type.ARRAY,
                items: { type: Type.INTEGER },
              },
            },
            required: ["id", "statement", "category", "confidence"],
          },
        },
      },
    });

    let claims: ResearchClaim[] = [];
    try {
      const parsed = JSON.parse((claimsExtractResp.text || "[]").trim()) as Array<{
        id: string;
        statement: string;
        category: string;
        confidence: string;
        sourceIds?: number[];
      }>;
      claims = parsed.slice(0, 10).map((c, idx) => ({
        id: c.id || `K${idx + 1}`,
        statement: c.statement,
        category: c.category || "Concept",
        confidence:
          c.confidence === "high" || c.confidence === "low"
            ? c.confidence
            : "medium",
        status: "extracted",
        sourceIds: Array.isArray(c.sourceIds)
          ? c.sourceIds.filter((n) => n >= 1 && n <= allSources.length)
          : allSources.length > 0
          ? [1]
          : [],
      }));
    } catch {
      claims = [];
    }

    emit("claims_updated", { claims });
    emit(
      "agent_message",
      makeMessage(
        "researcher",
        "researching",
        `Prepared ${claims.length} core concepts from ${allSources.length} verified sources`,
        rawResearchMemo
      )
    );

    // Generate Gemini Full Summary + Key Points + Visual Structure Diagram early
    let lessonOverview: LessonOverview | null = null;
    try {
      checkAborted();
      lessonOverview = await generateLessonOverviewWithGemini(
        ai,
        topic,
        sc,
        rawResearchMemo
      );
      emit("lesson_overview", { lessonOverview });
    } catch {
      // Non-fatal: continue with full study guide even if structured overview hits transient parse
    }

    // -------------------------------------------------------------------------
    // STEP 3: DOUBT & FACT-CHECKER AUDIT (Agent 2: Marcus Thorne)
    // -------------------------------------------------------------------------
    checkAborted();
    emit("phase_change", { phase: "fact_checking", iterationLoop: 1 });

    const factCheckSearchResp = await generateContentResilient(ai, {
      model: PRIMARY_MODEL,
      contents: `You are Marcus Thorne, Doubt Solver & Fact-Checker (${studentAudienceLine}).
Audit Elena's study points on "${topic}" using Google Search.

Key Study Points Under Review:
${claims.map((c) => `- [${c.id}] (${c.category}): ${c.statement}`).join("\n")}

Write a clear, student-helpful review:
1. Confirm which concepts, units, and definitions match the latest ${boardDisplay} curriculum accurately.
2. Flag at least 1–2 common student misconceptions, tricky edge cases, sign/unit traps, or syllabus nuances that need extra clarification—and ask 1–2 follow-up questions for Elena to make crystal clear for students.`,
      config: {
        systemInstruction:
          "You are Marcus Thorne, a sharp, student-friendly Fact-Checker & Exam Doubt Solver. Protect students from wrong formulas, oversimplified myths, and outdated syllabus facts.",
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingLevel: thinkingDepth },
      },
    });

    const factCheckCritique =
      factCheckSearchResp.text?.trim() || "Syllabus and concept audit completed.";
    const round2Sources = extractGroundingSources(factCheckSearchResp);
    registerSources(round2Sources, "fact_checker");

    const verdictExtractResp = await generateContentResilient(ai, {
      model: LITE_FALLBACK_MODEL,
      contents: `Based on Marcus Thorne's student doubt & fact-check review below, assign each concept an audit status ('verified' or 'disputed' for points needing extra clarification) and list 1–2 follow-up clarification queries.

Concepts:
${claims.map((c) => `[${c.id}] ${c.statement}`).join("\n")}

Review:
${factCheckCritique}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            verdicts: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  status: {
                    type: Type.STRING,
                    description: "verified or disputed",
                  },
                  note: { type: Type.STRING },
                },
                required: ["id", "status", "note"],
              },
            },
            secondaryQuestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "1 to 2 targeted clarification queries.",
            },
          },
          required: ["verdicts", "secondaryQuestions"],
        },
      },
    });

    let secondaryQuestions: string[] = [];
    let disputedCount = 0;
    try {
      const parsedVerdicts = JSON.parse(
        (verdictExtractResp.text || "{}").trim()
      ) as {
        verdicts?: Array<{ id: string; status: string; note: string }>;
        secondaryQuestions?: string[];
      };
      const verdictMap = new Map(
        (parsedVerdicts.verdicts || []).map((v) => [v.id, v])
      );
      claims = claims.map((c) => {
        const v = verdictMap.get(c.id);
        if (!v) return c;
        const isDisputed = v.status.toLowerCase() === "disputed";
        if (isDisputed) disputedCount++;
        return {
          ...c,
          status: isDisputed ? "disputed" : "verified",
          factCheckNote: v.note,
        };
      });
      secondaryQuestions = (parsedVerdicts.secondaryQuestions || []).slice(0, 2);
    } catch {
      secondaryQuestions = [`Common misconceptions and exam traps in ${topic}`];
    }

    if (secondaryQuestions.length === 0) {
      secondaryQuestions = [
        `Common student mistakes and latest exam tips for ${topic}`,
      ];
    }

    emit("claims_updated", { claims });
    emit(
      "agent_message",
      makeMessage(
        "fact_checker",
        "fact_checking",
        `Fact-check complete: ${disputedCount} point${disputedCount === 1 ? "" : "s"} flagged for clearer explanation`,
        factCheckCritique,
        {
          subQueries: secondaryQuestions,
          flaggedCount: disputedCount,
        }
      )
    );

    // -------------------------------------------------------------------------
    // STEP 4: SELF-CORRECTION & MISCONCEPTION CLARIFICATION LOOP
    // -------------------------------------------------------------------------
    checkAborted();
    emit("phase_change", { phase: "self_correcting", iterationLoop: 2 });

    const rebuttalResp = await generateContentResilient(ai, {
      model: PRIMARY_MODEL,
      contents: `${studentAudienceLine}
Marcus Thorne asked for clearer verification and misconception checks on:
${secondaryQuestions.map((q, i) => `${i + 1}. ${q}`).join("\n")}

Fact-Checker Notes:
${factCheckCritique}

Use Google Search to double-check these nuances and write simple, crystal-clear clarifications (with a quick example) so any student in ${sc?.studentClass || "school"} immediately avoids the trap.`,
      config: {
        systemInstruction:
          "You are Elena Vance, Concept Explorer. Clarify tricky doubts with utmost simplicity and accuracy using Google Search.",
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingLevel: thinkingDepth },
      },
    });

    const rebuttalText =
      rebuttalResp.text?.trim() || "Clarified tricky concepts and verified syllabus alignment.";
    const round3Sources = extractGroundingSources(rebuttalResp);
    registerSources(round3Sources, "researcher");

    emit(
      "agent_message",
      makeMessage(
        "researcher",
        "self_correcting",
        "Clarified tricky doubts & verified examples",
        rebuttalText
      )
    );

    checkAborted();
    const resolutionResp = await generateContentResilient(ai, {
      model: LITE_FALLBACK_MODEL,
      contents: `Review Elena's clarifications and finalize every concept in the Study Ledger before Clara Lin builds the final neat Study Notes.

Current Concepts:
${claims
  .map(
    (c) =>
      `[${c.id}] (${c.status}): ${c.statement} | Note: ${
        c.factCheckNote || "None"
      }`
  )
  .join("\n")}

Elena's Clarifications:
${rebuttalText}`,
      config: {
        systemInstruction:
          "You are Marcus Thorne, Fact-Checker. Finalize each concept ('verified' or 'corrected') with a short, student-friendly takeaway note.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            signOffSummary: { type: Type.STRING },
            resolutions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  finalStatus: {
                    type: Type.STRING,
                    description: "verified or corrected",
                  },
                  correctionNote: { type: Type.STRING },
                },
                required: ["id", "finalStatus", "correctionNote"],
              },
            },
          },
          required: ["signOffSummary", "resolutions"],
        },
      },
    });

    let signOffSummary =
      "All concepts, formulas, and common misconceptions are verified and cleared for the final Study Guide.";
    try {
      const parsedRes = JSON.parse((resolutionResp.text || "{}").trim()) as {
        signOffSummary?: string;
        resolutions?: Array<{
          id: string;
          finalStatus: string;
          correctionNote: string;
        }>;
      };
      if (parsedRes.signOffSummary) {
        signOffSummary = parsedRes.signOffSummary;
      }
      const resMap = new Map(
        (parsedRes.resolutions || []).map((r) => [r.id, r])
      );
      claims = claims.map((c) => {
        const r = resMap.get(c.id);
        if (!r) return { ...c, status: "verified" };
        return {
          ...c,
          status:
            r.finalStatus.toLowerCase() === "corrected"
              ? "corrected"
              : "verified",
          correctionNote: r.correctionNote,
        };
      });
    } catch {
      claims = claims.map((c) => ({
        ...c,
        status: c.status === "disputed" ? "corrected" : "verified",
      }));
    }

    emit("claims_updated", { claims });
    emit(
      "agent_message",
      makeMessage(
        "fact_checker",
        "self_correcting",
        "All concepts & misconceptions verified",
        signOffSummary
      )
    );

    // -------------------------------------------------------------------------
    // STEP 5: NEAT STUDENT STUDY GUIDE SYNTHESIS (Agent 3: Clara Lin)
    // -------------------------------------------------------------------------
    checkAborted();
    emit("phase_change", { phase: "finalizing", iterationLoop: 2 });
    emit(
      "agent_message",
      makeMessage(
        "editor",
        "finalizing",
        "Compiling neat, student-friendly Study Guide",
        "Organizing plain-language explanations, worked examples, key formulas, common mistakes to avoid, and practice questions."
      )
    );

    const sourcesContext = allSources
      .map((s) => `[${s.id}] ${s.title} — ${s.url}`)
      .join("\n");

    const claimsContext = claims
      .map(
        (c) =>
          `- **${c.id} [${c.status.toUpperCase()} · ${c.category}]**: ${
            c.statement
          }${c.factCheckNote ? ` | Check: ${c.factCheckNote}` : ""}${
            c.correctionNote ? ` | Clarified: ${c.correctionNote}` : ""
          } (Sources: ${c.sourceIds.map((id) => `[${id}]`).join(", ") || "General"})`
      )
      .join("\n");

    const reportStream = await generateContentStreamResilient(ai, {
      model: PRIMARY_MODEL,
      contents: `Compile a COMPLETE, THOROUGH, Lesson-Only Master Study Guide covering EACH AND EVERYTHING in this CBSE lesson:
"${topic}"
(${studentAudienceLine})

${visualBrief ? `### Uploaded Visual Analysis\n${visualBrief}\n` : ""}

### Verified Concept Ledger
${claimsContext}

### Complete Concept Explorer Notes & Doubt Clarifications
${rawResearchMemo}

--- Clarified Points ---
${rebuttalText}

### Grounded Learning Sources (Use ONLY these real URLs for clickable links)
${sourcesContext || "No external web URLs returned."}

Format the Markdown Study Guide cleanly for a ${sc?.studentClass || "school"} student — stay STRICTLY on this exact lesson and leave NOTHING out:
1. Start with a clear H1 title (# Lesson Title) and a 1-sentence italic summary of what this lesson covers.
2. **## 1. Quick Intuition (In Plain Words)**: Explain the core idea of the chapter in simple, friendly everyday language with a memorable real-life analogy.
3. **## 2. Complete Lesson Breakdown (Every Topic & Subtopic)**: Create a dedicated \`### Subtopic Name\` heading for EVERY topic, subtopic, definition, rule, process, derivation, or law in this lesson. Explain each clearly with bullet points and simple examples so the student needs no outside guide.
4. **## 3. All Formulas, Laws, Reactions & Summary Table**: List every formula/law/reaction/rule in this lesson with SI units, plus at least one clean Markdown comparison/summary table.
5. **## 4. Step-by-Step Solved Examples**: Walk through 2–3 NCERT/exam-level solved numericals or conceptual problems showing every step clearly.
6. **## 5. Common Exam Traps & Doubt Clarifications**: Highlight the mistakes Marcus Thorne flagged and exactly how to avoid losing marks.
7. **## 6. Important Exam Questions & Full Answers (1, 3 & 5 Marks)**: Give 4–5 important CBSE school/board questions from this lesson with crisp, complete answers right below each question.
8. Cite sources inline using clickable Markdown links like [[1]](URL) matching ONLY the real URLs above, and end with a **## Verified Study Links** numbered list.`,
      config: {
        systemInstruction:
          "You are Clara Lin, Study Notes Editor & Exam Coach. Compile complete, exhaustive, crystal-clear lesson notes covering every subtopic of the requested CBSE lesson in simple language, with zero off-topic filler.",
        thinkingConfig: { thinkingLevel: thinkingDepth },
      },
    });

    let fullReport = "";
    for await (const chunk of reportStream) {
      checkAborted();
      const textChunk = chunk.text || "";
      if (textChunk) {
        fullReport += textChunk;
        emit("report_chunk", { chunk: textChunk });
      }
    }

    emit("phase_change", { phase: "complete", iterationLoop: 2 });
    emit("investigation_complete", {
      reportMarkdown: fullReport,
      claims,
      sources: allSources,
      lessonOverview,
      completedAt: new Date().toISOString(),
    });
  } catch (err) {
    if (signal.aborted) return;
    const message = formatGeminiError(err);
    emit("phase_change", { phase: "error", iterationLoop: 1 });
    emit("crew_error", { message });
  }
}
