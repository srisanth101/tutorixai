import {
  GoogleGenAI,
  GenerateContentResponse,
  type GenerateContentParameters,
  type GenerateContentConfig,
} from "@google/genai";

export const PRIMARY_MODEL = "gemini-4-hydrogen";
export const LITE_FALLBACK_MODEL = "gemini-3.1-flash-lite";

let cachedAi: GoogleGenAI | null = null;
let hydrogenCooldownUntil = 0;

export function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      "GEMINI_API_KEY is not configured. Please add your Gemini API key in Settings > Secrets."
    );
  }
  if (!cachedAi) {
    cachedAi = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return cachedAi;
}

export function isRateLimitError(err: unknown): boolean {
  const raw = err instanceof Error ? err.message : String(err);
  return /RESOURCE_EXHAUSTED|429|rate.?limit|quota/i.test(raw);
}

function parseRetryDelayMs(err: unknown): number | null {
  const raw = err instanceof Error ? err.message : String(err);
  const secMatch = raw.match(/retry\s*(?:in|after)?\s*(\d+(?:\.\d+)?)\s*s/i);
  if (secMatch) {
    const ms = Math.round(Number(secMatch[1]) * 1000);
    if (Number.isFinite(ms) && ms > 0) {
      return Math.min(Math.max(ms, 1200), 10000);
    }
  }
  return null;
}

export function formatGeminiError(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err);
  if (/API_KEY_INVALID|PERMISSION_DENIED|403|401/i.test(raw)) {
    return "Gemini API authorization failed. Please verify your API key in Settings > Secrets.";
  }
  if (isRateLimitError(raw)) {
    return "Gemini API rate limit reached across active quota. Please wait ~30–60 seconds and try again, or attach a higher-quota API key in Settings > Secrets.";
  }
  if (/NOT_FOUND|404/i.test(raw)) {
    return "Requested Gemini model is unavailable. Check model configuration.";
  }
  return raw || "An unexpected error occurred while communicating with Gemini.";
}

export async function withRetry<T>(
  fn: () => Promise<T>,
  maxRetries = 2,
  baseDelayMs = 1200,
  retryOnRateLimit = true
): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err;
      const msg = err instanceof Error ? err.message : String(err);
      const isNonRetryable = /API_KEY_INVALID|PERMISSION_DENIED|400|401|403|404/i.test(
        msg
      );
      if (
        isNonRetryable ||
        (!retryOnRateLimit && isRateLimitError(err)) ||
        attempt === maxRetries
      ) {
        throw err;
      }
      const hinted = isRateLimitError(err) ? parseRetryDelayMs(err) : null;
      const cappedHinted = hinted ? Math.min(hinted, 3000) : null;
      const jitter = Math.floor(Math.random() * 350);
      const delay = cappedHinted ?? baseDelayMs * Math.pow(2, attempt) + jitter;
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
  throw lastError;
}

function buildLiteConfig(
  config?: GenerateContentConfig,
  stripTools = false
): GenerateContentConfig | undefined {
  if (!config) return undefined;
  const copy: GenerateContentConfig = { ...config };
  // thinkingConfig levels like HIGH / XHIGH are only valid on gemini-4-hydrogen
  delete copy.thinkingConfig;
  if (stripTools) {
    delete copy.tools;
  }
  return copy;
}

export async function generateContentResilient(
  ai: GoogleGenAI,
  params: GenerateContentParameters
): Promise<GenerateContentResponse> {
  const requestedModel = params.model || PRIMARY_MODEL;
  const canTryHydrogen =
    requestedModel === PRIMARY_MODEL && Date.now() >= hydrogenCooldownUntil;

  if (canTryHydrogen) {
    try {
      return await withRetry(
        () => ai.models.generateContent(params),
        1,
        1000,
        false
      );
    } catch (err) {
      if (!isRateLimitError(err)) {
        throw err;
      }
      // Put primary model on brief cooldown and transparently fall back to Flash Lite
      hydrogenCooldownUntil = Date.now() + 45_000;
    }
  }

  const hasTools = Boolean(params.config?.tools);

  // Fallback / Direct Lite execution
  try {
    return await withRetry(
      () =>
        ai.models.generateContent({
          ...params,
          model: LITE_FALLBACK_MODEL,
          config: buildLiteConfig(params.config, false),
        }),
      1,
      1200,
      !hasTools
    );
  } catch (liteErr) {
    const msg = liteErr instanceof Error ? liteErr.message : String(liteErr);
    if (
      (/400|tool|search|grounding/i.test(msg) || isRateLimitError(liteErr)) &&
      hasTools
    ) {
      return await withRetry(
        () =>
          ai.models.generateContent({
            ...params,
            model: LITE_FALLBACK_MODEL,
            config: buildLiteConfig(params.config, true),
          }),
        1,
        1500,
        true
      );
    }
    throw liteErr;
  }
}

export async function generateContentStreamResilient(
  ai: GoogleGenAI,
  params: GenerateContentParameters
) {
  const requestedModel = params.model || PRIMARY_MODEL;
  const canTryHydrogen =
    requestedModel === PRIMARY_MODEL && Date.now() >= hydrogenCooldownUntil;

  if (canTryHydrogen) {
    try {
      return await withRetry(
        () => ai.models.generateContentStream(params),
        1,
        1000,
        false
      );
    } catch (err) {
      if (!isRateLimitError(err)) {
        throw err;
      }
      hydrogenCooldownUntil = Date.now() + 45_000;
    }
  }

  const hasTools = Boolean(params.config?.tools);

  try {
    return await withRetry(
      () =>
        ai.models.generateContentStream({
          ...params,
          model: LITE_FALLBACK_MODEL,
          config: buildLiteConfig(params.config, false),
        }),
      1,
      1200,
      !hasTools
    );
  } catch (liteErr) {
    const msg = liteErr instanceof Error ? liteErr.message : String(liteErr);
    if (
      (/400|tool|search|grounding/i.test(msg) || isRateLimitError(liteErr)) &&
      hasTools
    ) {
      return await withRetry(
        () =>
          ai.models.generateContentStream({
            ...params,
            model: LITE_FALLBACK_MODEL,
            config: buildLiteConfig(params.config, true),
          }),
        1,
        1500,
        true
      );
    }
    throw liteErr;
  }
}

export async function sendChatMessageResilient(
  ai: GoogleGenAI,
  options: {
    history: Array<{ role: "user" | "model"; parts: Array<{ text: string }> }>;
    config: GenerateContentConfig;
    message:
      | string
      | Array<{ text: string } | { inlineData: { mimeType: string; data: string } }>;
  }
): Promise<GenerateContentResponse> {
  const canTryHydrogen = Date.now() >= hydrogenCooldownUntil;

  if (canTryHydrogen) {
    try {
      return await withRetry(
        async () => {
          const chat = ai.chats.create({
            model: PRIMARY_MODEL,
            history: options.history,
            config: options.config,
          });
          return await chat.sendMessage({ message: options.message });
        },
        1,
        1000,
        false
      );
    } catch (err) {
      if (!isRateLimitError(err)) {
        throw err;
      }
      hydrogenCooldownUntil = Date.now() + 45_000;
    }
  }

  const hasTools = Boolean(options.config?.tools);

  try {
    return await withRetry(
      async () => {
        const chat = ai.chats.create({
          model: LITE_FALLBACK_MODEL,
          history: options.history,
          config: buildLiteConfig(options.config, false),
        });
        return await chat.sendMessage({ message: options.message });
      },
      1,
      1200,
      !hasTools
    );
  } catch (liteErr) {
    const msg = liteErr instanceof Error ? liteErr.message : String(liteErr);
    if (
      (/400|tool|search|grounding/i.test(msg) || isRateLimitError(liteErr)) &&
      hasTools
    ) {
      return await withRetry(
        async () => {
          const chat = ai.chats.create({
            model: LITE_FALLBACK_MODEL,
            history: options.history,
            config: buildLiteConfig(options.config, true),
          });
          return await chat.sendMessage({ message: options.message });
        },
        1,
        1500,
        true
      );
    }
    throw liteErr;
  }
}

export interface ExtractedSourceItem {
  title: string;
  url: string;
  domain: string;
}

export function extractGroundingSources(
  response: GenerateContentResponse
): ExtractedSourceItem[] {
  const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
  if (!Array.isArray(chunks)) return [];

  const seen = new Set<string>();
  const results: ExtractedSourceItem[] = [];

  for (const chunk of chunks) {
    const uri = chunk?.web?.uri;
    const title = chunk?.web?.title;
    if (typeof uri === "string" && uri.startsWith("http") && !seen.has(uri)) {
      seen.add(uri);
      let domain = "";
      try {
        domain = new URL(uri).hostname.replace(/^www\./, "");
      } catch {
        domain = "source";
      }
      results.push({
        title: typeof title === "string" && title.trim() ? title.trim() : domain,
        url: uri,
        domain,
      });
    }
  }

  return results;
}
