export type AgentId = 'researcher' | 'fact_checker' | 'editor';

export type CrewPhase =
  | 'idle'
  | 'analyzing_image'
  | 'planning'
  | 'researching'
  | 'fact_checking'
  | 'self_correcting'
  | 'finalizing'
  | 'complete'
  | 'error';

export type ClaimStatus = 'extracted' | 'verified' | 'disputed' | 'corrected' | 'unverified';

export interface GroundedSource {
  id: number;
  title: string;
  url: string;
  domain: string;
  discoveredBy: AgentId;
}

export interface ResearchClaim {
  id: string;
  statement: string;
  category: string;
  confidence: 'high' | 'medium' | 'low';
  status: ClaimStatus;
  sourceIds: number[];
  factCheckNote?: string;
  correctionNote?: string;
}

export interface AgentMessage {
  id: string;
  agentId: AgentId;
  agentName: string;
  agentRole: string;
  phase: CrewPhase;
  timestamp: string;
  headline: string;
  content: string;
  subQueries?: string[];
  flaggedCount?: number;
}

export interface UploadedImagePayload {
  mimeType: string;
  data: string; // base64 without data URL prefix
  name: string;
  previewUrl?: string;
}

export type StudentClass =
  | "Class 6"
  | "Class 7"
  | "Class 8"
  | "Class 9"
  | "Class 10"
  | "Class 11"
  | "Class 12";

export interface StudentProfileContext {
  studentClass: StudentClass;
  board: "CBSE";
  subject: string;
  lessonTitle?: string;
}

export interface LessonKeyPoint {
  id: string;
  tag: string;
  point: string;
}

export interface StructureDiagramBranch {
  title: string;
  subtitle?: string;
  accent?: 'blue' | 'indigo' | 'emerald' | 'amber' | 'rose' | 'violet';
  items: string[];
}

export interface LessonStructureDiagram {
  diagramTitle: string;
  diagramType: 'hierarchy' | 'process' | 'concept_map';
  centralTitle: string;
  centralSubtitle: string;
  branches: StructureDiagramBranch[];
}

export interface LessonDetailSection {
  title: string;
  content: string;
  formulaOrRule?: string;
  example?: string;
}

export interface YoutubeVideoSuggestion {
  id: string;
  title: string;
  channelTitle: string;
  searchQuery: string;
  videoId?: string;
  thumbnailUrl?: string;
  watchUrl?: string;
  embedUrl?: string;
  badge?: string;
}

export interface LessonOverview {
  lessonTitle?: string;
  fullSummary: string;
  keyPoints: LessonKeyPoint[];
  allDetailsSections: LessonDetailSection[];
  structureDiagram: LessonStructureDiagram;
  youtubeSuggestions?: YoutubeVideoSuggestion[];
  generatedBy: string;
}

export interface InvestigationState {
  topic: string;
  depth: 'standard' | 'deep';
  phase: CrewPhase;
  iterationLoop: number;
  visualBrief: string | null;
  subQueries: string[];
  messages: AgentMessage[];
  claims: ResearchClaim[];
  sources: GroundedSource[];
  lessonOverview: LessonOverview | null;
  reportMarkdown: string;
  error: string | null;
  startedAt: string | null;
  completedAt: string | null;
  studentContext?: StudentProfileContext;
}

export interface ChatTurn {
  id: string;
  role: 'user' | 'model';
  persona?: 'crew' | AgentId;
  text: string;
  imagePreview?: string;
  sources?: GroundedSource[];
  timestamp: string;
  thinkingUsed?: boolean;
}

export type BlackholeMode = 'survival' | 'crash' | 'cheatsheet' | 'questions';

export type UserRole = 'student' | 'teacher';

export interface TeacherSession {
  token: string;
  teacherName: string;
  organization: 'KVS';
}

export interface TestQuestion {
  id: string;
  question: string;
  options: [string, string, string, string];
  correctIndex: number;
  marks: number;
  explanation: string;
}

export interface StudentTest {
  id: string;
  testCode: string;
  title: string;
  studentClass: StudentClass;
  subject: string;
  chapter: string;
  durationMinutes: number;
  createdBy: string;
  createdAt: string;
  questions: TestQuestion[];
  published: boolean;
}

export interface StudentIdentity {
  studentId: string;
  name: string;
  board: string;
  studentClass: StudentClass;
  schoolName?: string;
  isKvStudent?: boolean;
  createdAt: string;
}

export interface TestSubmission {
  id: string;
  testId: string;
  studentId?: string;
  studentName: string;
  studentClass: StudentClass;
  rollNumber: string;
  score: number;
  totalMarks: number;
  submittedAt: string;
  answers: number[];
}

export interface SavedQuestionPaper {
  id: string;
  title: string;
  schoolName: string;
  teacherName: string;
  studentClass: StudentClass;
  subject: string;
  examType: string;
  totalMarks: number;
  duration: string;
  paperMarkdown: string;
  answerKeyMarkdown: string;
  createdAt: string;
}

