import React, { useEffect, useRef, useState } from "react";
import {
  BookOpen,
  Box,
  ClipboardCheck,
  IdCard,
  MessageSquare,
  Orbit,
  Sparkles,
  UserCircle2,
} from "lucide-react";
import { RoleGateway } from "./components/RoleGateway";
import { StudentOnboardingModal } from "./components/StudentOnboardingModal";
import { CbseSyllabusPage } from "./components/CbseSyllabusPage";
import { NewsroomWorkspace } from "./components/NewsroomWorkspace";
import { LessonStage3D } from "./components/LessonStage3D";
import { MarkdownReportView } from "./components/MarkdownReportView";
import { CrewChatPanel } from "./components/CrewChatPanel";
import { BlackholePage } from "./components/BlackholePage";
import { StudentTestsPage } from "./components/StudentTestsPage";
import { TeacherPortalPage } from "./components/TeacherPortalPage";
import {
  HomeLandingPage,
  type HomeDestination,
} from "./components/HomeLandingPage";
import { buildInstantLessonOverview } from "./utils/instantLessonOverview";
import { safeJsonResponse } from "./utils/freeLocalChat";
import {
  getBaselineLessons,
  getSubjectsForClass,
  type StudentClass,
  type SyllabusLesson,
} from "./data/syllabusCatalog";
import type {
  AgentMessage,
  CrewPhase,
  GroundedSource,
  InvestigationState,
  LessonOverview,
  ResearchClaim,
  StudentIdentity,
  StudentProfileContext,
  TeacherSession,
  UploadedImagePayload,
  UserRole,
} from "./types";

type AppPage =
  | "home"
  | "syllabus"
  | "loop"
  | "notes"
  | "chat"
  | "tests"
  | "teacher"
  | "stage"
  | "blackhole";

const INITIAL_STUDENT_CONTEXT: StudentProfileContext = {
  studentClass: "Class 10",
  board: "CBSE",
  subject: "Science",
  lessonTitle: "Electricity",
};

const INITIAL_STATE: InvestigationState = {
  topic: "",
  depth: "standard",
  phase: "idle",
  iterationLoop: 0,
  visualBrief: null,
  subQueries: [],
  messages: [],
  claims: [],
  sources: [],
  lessonOverview: null,
  reportMarkdown: "",
  error: null,
  startedAt: null,
  completedAt: null,
};

const STUDENT_PROFILE_STORAGE_KEY = "studysphere_student_profile";
const OVERVIEWS_STORAGE_KEY = "studysphere_overviews_v1";

function overviewCacheKey(
  studentClass: string,
  subject: string,
  lessonTitle: string
): string {
  return `${studentClass.trim().toLowerCase()}|${subject
    .trim()
    .toLowerCase()}|${lessonTitle.trim().toLowerCase()}`;
}

export default function App() {
  const [studentIdentity, setStudentIdentity] =
    useState<StudentIdentity | null>(() => {
      try {
        const raw = localStorage.getItem(STUDENT_PROFILE_STORAGE_KEY);
        return raw ? (JSON.parse(raw) as StudentIdentity) : null;
      } catch {
        return null;
      }
    });
  const [showProfileModal, setShowProfileModal] = useState(false);

  const [cachedOverviews, setCachedOverviews] = useState<
    Record<string, LessonOverview>
  >(() => {
    try {
      const raw = localStorage.getItem(OVERVIEWS_STORAGE_KEY);
      return raw ? (JSON.parse(raw) as Record<string, LessonOverview>) : {};
    } catch {
      return {};
    }
  });

  const [showTeacherLogin, setShowTeacherLogin] = useState(false);
  const [teacherSession, setTeacherSession] = useState<TeacherSession | null>(
    () => {
      try {
        const raw = sessionStorage.getItem("studysphere_teacher_session");
        return raw ? (JSON.parse(raw) as TeacherSession) : null;
      } catch {
        return null;
      }
    }
  );
  const [userRole, setUserRole] = useState<UserRole>(() => {
    const saved = sessionStorage.getItem("studysphere_role");
    return saved === "teacher" ? "teacher" : "student";
  });

  const [activePage, setActivePage] = useState<AppPage>(() => {
    if (typeof window !== "undefined" && window.location.hash === "#teacher") {
      return "teacher";
    }
    const saved = sessionStorage.getItem("studysphere_role");
    const hasSession = Boolean(
      sessionStorage.getItem("studysphere_teacher_session")
    );
    return saved === "teacher" && hasSession ? "teacher" : "home";
  });
  const [returnPage, setReturnPage] = useState<AppPage>("home");
  const [pendingJourneyDestination, setPendingJourneyDestination] =
    useState<AppPage | null>(null);

  const [studentContext, setStudentContext] = useState<StudentProfileContext>(
    () => {
      try {
        const raw = localStorage.getItem(STUDENT_PROFILE_STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw) as StudentIdentity;
          if (parsed?.studentClass) {
            const firstSubj = getSubjectsForClass(parsed.studentClass)[0];
            const firstLess = getBaselineLessons(
              parsed.studentClass,
              firstSubj
            )[0];
            return {
              studentClass: parsed.studentClass,
              board: "CBSE",
              subject: firstSubj,
              lessonTitle: firstLess?.title,
            };
          }
        }
      } catch {
        // Fallback to default
      }
      return INITIAL_STUDENT_CONTEXT;
    }
  );
  const [lessons, setLessons] = useState<SyllabusLesson[]>(() =>
    getBaselineLessons(
      studentContext.studentClass,
      studentContext.subject
    )
  );
  const [lessonsSyncing, setLessonsSyncing] = useState(false);
  const [lessonsSyncedLive, setLessonsSyncedLive] = useState(false);

  const [topicInput, setTopicInput] = useState(
    "Class 10 CBSE Science — Ch 11: Electricity. Explain clearly in easy student-understandable language with daily-life examples, formulas, and common exam mistakes."
  );
  const [depth, setDepth] = useState<"standard" | "deep">("standard");
  const [attachedImage, setAttachedImage] =
    useState<UploadedImagePayload | null>(null);
  const [state, setState] = useState<InvestigationState>(INITIAL_STATE);
  const [overviewLoading, setOverviewLoading] = useState(false);
  const [pendingChatPrompt, setPendingChatPrompt] = useState<string | null>(
    null
  );

  const abortRef = useRef<AbortController | null>(null);
  const syllabusAbortRef = useRef<AbortController | null>(null);
  const clientSyllabusCache = useRef<Map<string, SyllabusLesson[]>>(new Map());
  const autoFetchedKeyRef = useRef<string>("");

  // Verify saved teacher token cleanly on mount
  useEffect(() => {
    if (!teacherSession?.token) return;
    fetch("/api/teacher/verify", {
      headers: { Authorization: `Bearer ${teacherSession.token}` },
    })
      .then((res) => {
        if (!res.ok) {
          setTeacherSession(null);
          sessionStorage.removeItem("studysphere_teacher_session");
          if (userRole === "teacher") {
            setUserRole("student");
            sessionStorage.setItem("studysphere_role", "student");
            setActivePage("syllabus");
          }
        }
      })
      .catch(() => {
        // Ignore transient offline error
      });
  }, []);

  // Load baseline CBSE chapters immediately when class or subject changes
  useEffect(() => {
    const base = getBaselineLessons(
      studentContext.studentClass,
      studentContext.subject
    );
    const key = `${studentContext.studentClass}|CBSE|${studentContext.subject}`;
    const cached = clientSyllabusCache.current.get(key);
    if (cached && cached.length >= base.length) {
      setLessons(cached);
      setLessonsSyncedLive(true);
    } else {
      setLessons(base);
      setLessonsSyncedLive(false);
    }
  }, [studentContext.studentClass, studentContext.subject]);

  // Persist cached lesson overviews locally for 0ms repeat access
  const mergeCachedOverviews = (
    cls: string,
    subject: string,
    incoming: Record<string, LessonOverview>
  ) => {
    const entries = Object.entries(incoming);
    if (entries.length === 0) return;
    setCachedOverviews((prev) => {
      const next = { ...prev };
      let changed = false;
      for (const [title, ov] of entries) {
        const k = overviewCacheKey(cls, subject, ov.lessonTitle || title);
        if (!next[k] || next[k].generatedBy === "Instant") {
          next[k] = { ...ov, lessonTitle: ov.lessonTitle || title };
          changed = true;
        }
      }
      if (!changed) return prev;
      try {
        localStorage.setItem(OVERVIEWS_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore storage quota gracefully
      }
      return next;
    });
  };

  // Silently auto-prefetch ALL chapter summaries for the active Class & Subject
  useEffect(() => {
    if (lessons.length === 0) return;
    let cancelled = false;
    let pollId: number | undefined;

    const triggerPrefetch = async () => {
      try {
        const res = await fetch("/api/study-loop/prefetch-subject", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            studentClass: studentContext.studentClass,
            subject: studentContext.subject,
            lessons: lessons.map((l) => ({
              chapterNumber: l.chapterNumber,
              title: l.title,
              summary: l.summary,
            })),
          }),
        });
        if (!res.ok || cancelled) return;
        const data = await safeJsonResponse<{
          cached?: Record<string, LessonOverview>;
          prefetchingRemaining?: number;
        }>(res);
        if (!data) return;
        if (data.cached) {
          mergeCachedOverviews(
            studentContext.studentClass,
            studentContext.subject,
            data.cached
          );
        }

        if (Number(data.prefetchingRemaining) > 0) {
          pollId = window.setInterval(async () => {
            if (cancelled) return;
            try {
              const r = await fetch(
                `/api/study-loop/cached-batch?studentClass=${encodeURIComponent(
                  studentContext.studentClass
                )}&subject=${encodeURIComponent(studentContext.subject)}`
              );
              if (!r.ok || cancelled) return;
              const batch = await safeJsonResponse<{
                cached?: Record<string, LessonOverview>;
                inProgress?: boolean;
              }>(r);
              if (!batch) return;
              if (batch.cached) {
                mergeCachedOverviews(
                  studentContext.studentClass,
                  studentContext.subject,
                  batch.cached
                );
              }
              if (!batch.inProgress && pollId) {
                window.clearInterval(pollId);
              }
            } catch {
              // Ignore transient errors silently
            }
          }, 5000);
        }
      } catch {
        // Ignore network errors silently
      }
    };

    void triggerPrefetch();

    return () => {
      cancelled = true;
      if (pollId) window.clearInterval(pollId);
    };
  }, [studentContext.studentClass, studentContext.subject, lessons]);

  // Immediately show instant or cached lesson overview in Study Loop + silently hydrate full notes
  useEffect(() => {
    if (activePage !== "loop") return;
    const activeLessonObj =
      lessons.find((l) => l.title === studentContext.lessonTitle) || lessons[0];
    const activeLessonTitle =
      activeLessonObj?.title || studentContext.lessonTitle || "";
    const cacheKey = overviewCacheKey(
      studentContext.studentClass,
      studentContext.subject,
      activeLessonTitle
    );
    const cachedFull = cachedOverviews[cacheKey];

    const effectiveCtx: StudentProfileContext = studentContext.lessonTitle
      ? studentContext
      : { ...studentContext, lessonTitle: activeLessonTitle || undefined };
    if (!studentContext.lessonTitle && activeLessonTitle) {
      setStudentContext(effectiveCtx);
    }

    // If cached rich overview just arrived, hydrate immediately
    if (
      cachedFull &&
      (!state.lessonOverview ||
        state.lessonOverview.lessonTitle !== activeLessonTitle ||
        state.lessonOverview.generatedBy === "Instant")
    ) {
      setState((prev) => ({
        ...prev,
        lessonOverview: cachedFull,
      }));
      autoFetchedKeyRef.current = cacheKey;
      return;
    }

    // Otherwise display instant 0ms structured overview immediately while silently fetching in background
    if (
      !state.lessonOverview ||
      state.lessonOverview.lessonTitle !== activeLessonTitle
    ) {
      const instant = buildInstantLessonOverview(effectiveCtx, activeLessonObj);
      setState((prev) => ({
        ...prev,
        lessonOverview: instant,
      }));
    }

    if (cachedFull || overviewLoading || autoFetchedKeyRef.current === cacheKey) {
      return;
    }
    autoFetchedKeyRef.current = cacheKey;

    const effectiveTopic =
      topicInput.trim() ||
      `${studentContext.studentClass} CBSE ${studentContext.subject}${
        activeLessonTitle ? ` — ${activeLessonTitle}` : ""
      }. Explain clearly with full summary, key points, all subtopics, formulas, and examples.`;
    if (!topicInput.trim()) {
      setTopicInput(effectiveTopic);
    }
    void handleGenerateQuickOverview(effectiveTopic, effectiveCtx, true);
  }, [
    activePage,
    studentContext.studentClass,
    studentContext.subject,
    studentContext.lessonTitle,
    lessons,
    cachedOverviews,
  ]);

  const handleSelectStudent = () => {
    setUserRole("student");
    sessionStorage.setItem("studysphere_role", "student");
    setShowTeacherLogin(false);
    setActivePage("syllabus");
  };

  const handleTeacherAuthenticated = (session: TeacherSession) => {
    setTeacherSession(session);
    sessionStorage.setItem(
      "studysphere_teacher_session",
      JSON.stringify(session)
    );
    setUserRole("teacher");
    sessionStorage.setItem("studysphere_role", "teacher");
    setShowTeacherLogin(false);
    setActivePage("teacher");
  };

  const handleTeacherLogout = async () => {
    if (teacherSession?.token) {
      fetch("/api/teacher/logout", {
        method: "POST",
        headers: { Authorization: `Bearer ${teacherSession.token}` },
      }).catch(() => {});
    }
    setTeacherSession(null);
    sessionStorage.removeItem("studysphere_teacher_session");
    sessionStorage.setItem("studysphere_role", "student");
    setUserRole("student");
    setShowTeacherLogin(false);
    setActivePage("syllabus");
  };

  const openAccountPortal = () => {
    if (teacherSession) {
      setUserRole("teacher");
      sessionStorage.setItem("studysphere_role", "teacher");
      setActivePage("teacher");
    } else {
      setShowTeacherLogin(true);
    }
  };

  // Support navigating directly to #teacher URL hash without exposing a Teacher button in student UI
  useEffect(() => {
    const onHashChange = () => {
      if (window.location.hash === "#teacher") {
        if (teacherSession) {
          setUserRole("teacher");
          sessionStorage.setItem("studysphere_role", "teacher");
          setActivePage("teacher");
        } else {
          setShowTeacherLogin(true);
        }
      }
    };
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, [teacherSession]);

  const fetchLatestLessons = async (ctx: StudentProfileContext) => {
    const key = `${ctx.studentClass}|CBSE|${ctx.subject}`;
    const baseline = getBaselineLessons(ctx.studentClass, ctx.subject);

    syllabusAbortRef.current?.abort();
    const controller = new AbortController();
    syllabusAbortRef.current = controller;
    setLessonsSyncing(true);

    try {
      const res = await fetch("/api/syllabus/lessons", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          studentClass: ctx.studentClass,
          subject: ctx.subject,
        }),
      });

      if (!res.ok) return;
      const data = await safeJsonResponse<{ lessons?: SyllabusLesson[] }>(res);
      if (
        data &&
        Array.isArray(data.lessons) &&
        data.lessons.length >= baseline.length
      ) {
        clientSyllabusCache.current.set(key, data.lessons);
        setLessons(data.lessons);
        setLessonsSyncedLive(true);
      } else {
        setLessonsSyncedLive(true);
      }
    } catch {
      // Keep baseline lessons cleanly
    } finally {
      if (!controller.signal.aborted) {
        setLessonsSyncing(false);
      }
    }
  };

  const buildLessonTopicPrompt = (
    cls: StudentClass,
    subject: string,
    lesson?: SyllabusLesson
  ) =>
    lesson
      ? `${cls} CBSE ${subject} — ${lesson.chapterNumber}: ${lesson.title}. Cover ONLY this lesson with ALL full details: every subtopic, easy intuition, all definitions/laws/formulas, solved NCERT examples, common exam mistakes, and important exam questions with answers.`
      : `${cls} CBSE ${subject}. Cover the complete lesson with full summary, key points, all subtopics, formulas, and examples.`;

  const handleChangeStudentClass = (cls: StudentClass) => {
    const validSubjects = getSubjectsForClass(cls);
    const nextSubject = validSubjects.includes(studentContext.subject)
      ? studentContext.subject
      : validSubjects[0];
    const firstLesson = getBaselineLessons(cls, nextSubject)[0];
    const nextCtx: StudentProfileContext = {
      studentClass: cls,
      board: "CBSE",
      subject: nextSubject,
      lessonTitle: firstLesson?.title,
    };
    autoFetchedKeyRef.current = "";
    setStudentContext(nextCtx);
    setTopicInput(buildLessonTopicPrompt(cls, nextSubject, firstLesson));
    setState((prev) => ({
      ...prev,
      lessonOverview: null,
      reportMarkdown: "",
      messages: [],
      claims: [],
      sources: [],
      error: null,
    }));
  };

  const handleChangeSubject = (subject: string) => {
    const firstLesson = getBaselineLessons(
      studentContext.studentClass,
      subject
    )[0];
    const nextCtx: StudentProfileContext = {
      ...studentContext,
      subject,
      lessonTitle: firstLesson?.title,
    };
    autoFetchedKeyRef.current = "";
    setStudentContext(nextCtx);
    setTopicInput(
      buildLessonTopicPrompt(
        studentContext.studentClass,
        subject,
        firstLesson
      )
    );
    setState((prev) => ({
      ...prev,
      lessonOverview: null,
      reportMarkdown: "",
      messages: [],
      claims: [],
      sources: [],
      error: null,
    }));
  };

  const handleStudentOnboarded = (profile: StudentIdentity) => {
    setStudentIdentity(profile);
    try {
      localStorage.setItem(
        STUDENT_PROFILE_STORAGE_KEY,
        JSON.stringify(profile)
      );
    } catch {
      // Ignore storage failure
    }
    setShowProfileModal(false);

    if (profile.studentClass !== studentContext.studentClass) {
      handleChangeStudentClass(profile.studentClass);
    }

    if (pendingJourneyDestination) {
      const target = pendingJourneyDestination;
      setPendingJourneyDestination(null);
      if (target === "chat" || target === "stage") {
        setReturnPage("syllabus");
      }
      setActivePage(target);
    } else if (activePage === "home") {
      setActivePage("syllabus");
    }
  };

  const handleStudentLogout = () => {
    try {
      localStorage.removeItem(STUDENT_PROFILE_STORAGE_KEY);
    } catch {
      // Ignore
    }
    setStudentIdentity(null);
    setShowProfileModal(false);
    setPendingJourneyDestination(null);
    setActivePage("home");
  };

  const handleGetIntoJourney = () => {
    if (!studentIdentity) {
      setPendingJourneyDestination("syllabus");
      setShowProfileModal(true);
      return;
    }
    setActivePage("syllabus");
  };

  const handleNavigateFromHome = (destination: HomeDestination) => {
    if (!studentIdentity) {
      setPendingJourneyDestination(destination);
      setShowProfileModal(true);
      return;
    }
    if (destination === "chat" || destination === "stage") {
      setReturnPage("home");
    }
    setActivePage(destination);
  };

  const handleSelectLessonInLoop = (lesson: SyllabusLesson) => {
    const nextTopic = buildLessonTopicPrompt(
      studentContext.studentClass,
      studentContext.subject,
      lesson
    );
    const nextCtx: StudentProfileContext = {
      ...studentContext,
      lessonTitle: lesson.title,
    };
    const key = overviewCacheKey(
      nextCtx.studentClass,
      nextCtx.subject,
      lesson.title
    );
    const cachedFull = cachedOverviews[key];
    autoFetchedKeyRef.current = key;
    setStudentContext(nextCtx);
    setTopicInput(nextTopic);
    setState({
      ...INITIAL_STATE,
      topic: nextTopic,
      studentContext: nextCtx,
      lessonOverview: cachedFull || buildInstantLessonOverview(nextCtx, lesson),
    });
    if (!cachedFull) {
      void handleGenerateQuickOverview(nextTopic, nextCtx, true);
    }
  };

  const handleStartStudyLoopForLesson = (lesson: SyllabusLesson) => {
    const nextTopic = buildLessonTopicPrompt(
      studentContext.studentClass,
      studentContext.subject,
      lesson
    );
    const nextCtx: StudentProfileContext = {
      ...studentContext,
      lessonTitle: lesson.title,
    };
    const key = overviewCacheKey(
      nextCtx.studentClass,
      nextCtx.subject,
      lesson.title
    );
    const cachedFull = cachedOverviews[key];
    autoFetchedKeyRef.current = key;
    setStudentContext(nextCtx);
    setTopicInput(nextTopic);
    setState({
      ...INITIAL_STATE,
      topic: nextTopic,
      studentContext: nextCtx,
      lessonOverview: cachedFull || buildInstantLessonOverview(nextCtx, lesson),
    });
    setActivePage("loop");
    if (!cachedFull) {
      void handleGenerateQuickOverview(nextTopic, nextCtx, true);
    }
  };

  const handleAskChatForLesson = (lesson: SyllabusLesson) => {
    const nextCtx: StudentProfileContext = {
      ...studentContext,
      lessonTitle: lesson.title,
    };
    setStudentContext(nextCtx);
    setPendingChatPrompt(
      `I am studying ${studentContext.studentClass} CBSE ${studentContext.subject} (${lesson.chapterNumber}: ${lesson.title}). Please explain the core concepts clearly in simple words and help me clear any doubts!`
    );
    setReturnPage("syllabus");
    setActivePage("chat");
  };

  const handleOpen3DForLesson = (lesson: SyllabusLesson) => {
    const nextTopic = `${studentContext.studentClass} CBSE ${studentContext.subject} — ${lesson.chapterNumber}: ${lesson.title}`;
    setStudentContext((prev) => ({
      ...prev,
      lessonTitle: lesson.title,
    }));
    setTopicInput(nextTopic);
    setReturnPage("syllabus");
    setActivePage("stage");
  };

  const handleOpenBlackholeForLesson = (lesson: SyllabusLesson) => {
    const nextTopic = `${studentContext.studentClass} CBSE ${studentContext.subject} — ${lesson.chapterNumber}: ${lesson.title}`;
    setStudentContext((prev) => ({
      ...prev,
      lessonTitle: lesson.title,
    }));
    setTopicInput(nextTopic);
    setActivePage("blackhole");
  };

  const handleStopInvestigation = () => {
    abortRef.current?.abort();
    abortRef.current = null;
    setState((prev) => ({
      ...prev,
      phase: prev.reportMarkdown ? "complete" : "idle",
    }));
  };

  const handleNewTopic = () => {
    if (abortRef.current) {
      abortRef.current.abort();
      abortRef.current = null;
    }
    setState(INITIAL_STATE);
    setOverviewLoading(false);
    setTopicInput("");
    setAttachedImage(null);
    setStudentContext((prev) => ({ ...prev, lessonTitle: undefined }));
    setActivePage("loop");
  };

  const handleGenerateQuickOverview = async (
    overrideTopic?: string,
    overrideCtx?: StudentProfileContext,
    silent = false
  ) => {
    const cleanTopic = (overrideTopic ?? topicInput).trim();
    const activeCtx = overrideCtx ?? studentContext;
    if (!cleanTopic || overviewLoading) return;
    setOverviewLoading(true);
    if (!silent) {
      setState((prev) => ({ ...prev, error: null }));
    }
    try {
      const res = await fetch("/api/study-loop/overview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic: cleanTopic,
          studentContext: activeCtx,
        }),
      });
      const data = await safeJsonResponse<{
        lessonOverview?: LessonOverview;
        error?: string;
      }>(res);
      if (!res.ok || !data) {
        if (!silent) {
          throw new Error(
            data?.error ||
              "Live refresh requires server mode — showing built-in NCERT study notes."
          );
        }
        return;
      }
      if (data.lessonOverview) {
        const fetched = data.lessonOverview;
        if (activeCtx.lessonTitle) {
          mergeCachedOverviews(activeCtx.studentClass, activeCtx.subject, {
            [activeCtx.lessonTitle]: fetched,
          });
        }
        setState((prev) => ({
          ...prev,
          topic: prev.topic || cleanTopic,
          lessonOverview: fetched,
        }));
      }
    } catch (err) {
      if (!silent) {
        setState((prev) => ({
          ...prev,
          error:
            err instanceof Error
              ? err.message
              : "Could not refresh detailed lesson notes.",
        }));
      }
    } finally {
      setOverviewLoading(false);
    }
  };

  const handleStartInvestigation = async (
    overrideTopic?: string,
    overrideContext?: StudentProfileContext
  ) => {
    const cleanTopic = (overrideTopic ?? topicInput).trim();
    const activeCtx = overrideContext ?? studentContext;
    if (!cleanTopic) return;

    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setState((prev) => ({
      ...INITIAL_STATE,
      lessonOverview: prev.lessonOverview,
      topic: cleanTopic,
      depth,
      studentContext: activeCtx,
      phase: attachedImage ? "analyzing_image" : "planning",
      iterationLoop: 1,
      startedAt: new Date().toISOString(),
    }));

    try {
      const response = await fetch("/api/crew/investigate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          topic: cleanTopic,
          depth,
          studentContext: activeCtx,
          image: attachedImage
            ? {
                mimeType: attachedImage.mimeType,
                data: attachedImage.data,
                name: attachedImage.name,
              }
            : undefined,
        }),
      });

      const ct = response.headers.get("content-type")?.toLowerCase() || "";
      if (!response.ok || !response.body || ct.includes("text/html")) {
        const errPayload = await safeJsonResponse<{ error?: string }>(response);
        throw new Error(
          errPayload?.error ||
            "Deep web-verified streaming requires backend server mode. Your Study Loop lesson overview & Free AI Chat remain available."
        );
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      const processBlock = (block: string) => {
        const lines = block.split("\n");
        let eventName = "message";
        const dataLines: string[] = [];

        for (const line of lines) {
          if (line.startsWith("event:")) {
            eventName = line.slice(6).trim();
          } else if (line.startsWith("data:")) {
            dataLines.push(line.slice(5).trim());
          }
        }

        if (dataLines.length === 0) return;
        const rawData = dataLines.join("\n");
        let payload: Record<string, unknown>;
        try {
          payload = JSON.parse(rawData);
        } catch {
          return;
        }

        if (eventName === "phase_change") {
          setState((prev) => ({
            ...prev,
            phase: payload.phase as CrewPhase,
            iterationLoop:
              typeof payload.iterationLoop === "number"
                ? payload.iterationLoop
                : prev.iterationLoop,
          }));
        } else if (eventName === "visual_brief") {
          setState((prev) => ({
            ...prev,
            visualBrief: String(payload.visualBrief || ""),
          }));
        } else if (eventName === "plan_ready") {
          setState((prev) => ({
            ...prev,
            subQueries: Array.isArray(payload.subQueries)
              ? (payload.subQueries as string[])
              : prev.subQueries,
          }));
        } else if (eventName === "sources_discovered") {
          setState((prev) => ({
            ...prev,
            sources: Array.isArray(payload.sources)
              ? (payload.sources as GroundedSource[])
              : prev.sources,
          }));
        } else if (eventName === "claims_updated") {
          setState((prev) => ({
            ...prev,
            claims: Array.isArray(payload.claims)
              ? (payload.claims as ResearchClaim[])
              : prev.claims,
          }));
        } else if (eventName === "agent_message") {
          const msg = payload as unknown as AgentMessage;
          setState((prev) => ({
            ...prev,
            messages: [...prev.messages, msg],
          }));
        } else if (eventName === "lesson_overview") {
          if (payload.lessonOverview) {
            setState((prev) => ({
              ...prev,
              lessonOverview: payload.lessonOverview as LessonOverview,
            }));
          }
        } else if (eventName === "report_chunk") {
          const chunk = String(payload.chunk || "");
          setState((prev) => ({
            ...prev,
            reportMarkdown: prev.reportMarkdown + chunk,
          }));
        } else if (eventName === "investigation_complete") {
          setState((prev) => ({
            ...prev,
            phase: "complete",
            reportMarkdown: String(
              payload.reportMarkdown || prev.reportMarkdown
            ),
            claims: Array.isArray(payload.claims)
              ? (payload.claims as ResearchClaim[])
              : prev.claims,
            sources: Array.isArray(payload.sources)
              ? (payload.sources as GroundedSource[])
              : prev.sources,
            lessonOverview: payload.lessonOverview
              ? (payload.lessonOverview as LessonOverview)
              : prev.lessonOverview,
            completedAt: String(
              payload.completedAt || new Date().toISOString()
            ),
          }));
        } else if (eventName === "crew_error") {
          setState((prev) => ({
            ...prev,
            phase: "error",
            error: String(payload.message || "Study loop error occurred."),
          }));
        }
      };

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const blocks = buffer.split("\n\n");
        buffer = blocks.pop() || "";
        for (const block of blocks) {
          if (block.trim()) processBlock(block);
        }
      }

      if (buffer.trim()) {
        processBlock(buffer);
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") {
        return;
      }
      setState((prev) => ({
        ...prev,
        phase: "error",
        error:
          err instanceof Error
            ? err.message
            : "Connection lost during study loop.",
      }));
    } finally {
      abortRef.current = null;
    }
  };

  // KVS Teacher Login Dialog Screen (opened via Account logo or Teacher button)
  if (showTeacherLogin) {
    return (
      <RoleGateway
        defaultMode="teacher"
        onSelectStudent={handleSelectStudent}
        onTeacherAuthenticated={handleTeacherAuthenticated}
        onCancel={() => setShowTeacherLogin(false)}
      />
    );
  }

  // Standalone Pure-Dark Separate Blackhole Page
  if (activePage === "blackhole") {
    return (
      <BlackholePage
        studentContext={studentContext}
        onChangeStudentClass={handleChangeStudentClass}
        onChangeSubject={handleChangeSubject}
        initialTopic={topicInput}
        onBackToMain={() =>
          setActivePage(
            userRole === "teacher" && teacherSession ? "teacher" : "syllabus"
          )
        }
      />
    );
  }

  // Standalone Separate KVS Teacher Portal Page
  if (activePage === "teacher") {
    if (!teacherSession) {
      return (
        <RoleGateway
          defaultMode="teacher"
          onSelectStudent={handleSelectStudent}
          onTeacherAuthenticated={handleTeacherAuthenticated}
          onCancel={() => setActivePage("syllabus")}
        />
      );
    }
    return (
      <TeacherPortalPage
        session={teacherSession}
        onLogout={handleTeacherLogout}
        onBackToStudentPortal={handleSelectStudent}
        onSwitchToStudentTools={(target) => {
          setUserRole("student");
          sessionStorage.setItem("studysphere_role", "student");
          setActivePage(target);
        }}
      />
    );
  }

  // Standalone Full-Screen Interactive 3D Lesson Stage
  if (activePage === "stage") {
    return (
      <LessonStage3D
        studentContext={studentContext}
        topic={state.topic || topicInput}
        fullStage={true}
        onExitStage={() =>
          setActivePage(
            returnPage === "stage" || returnPage === "chat"
              ? "syllabus"
              : returnPage
          )
        }
      />
    );
  }

  // Standalone Full-Screen Home Landing Page (Zero Menu Bar)
  if (activePage === "home") {
    return (
      <>
        <HomeLandingPage
          studentIdentity={studentIdentity}
          studentContext={studentContext}
          onGetIntoJourney={handleGetIntoJourney}
          onNavigate={handleNavigateFromHome}
          onOpenProfileModal={() => setShowProfileModal(true)}
          onOpenTeacherPortal={openAccountPortal}
        />

        {showProfileModal && (
          <StudentOnboardingModal
            existingProfile={studentIdentity}
            defaultClass={studentContext.studentClass}
            onComplete={handleStudentOnboarded}
            onLogout={handleStudentLogout}
            onOpenTeacherLogin={() => {
              setShowProfileModal(false);
              setPendingJourneyDestination(null);
              setShowTeacherLogin(true);
            }}
            onClose={() => {
              setShowProfileModal(false);
              setPendingJourneyDestination(null);
            }}
          />
        )}
      </>
    );
  }

  const navItems: Array<{
    id: AppPage;
    label: string;
    icon: React.ReactNode;
    activeClass: string;
    idleClass: string;
  }> = [
    {
      id: "syllabus",
      label: "CBSE Syllabus",
      icon: <BookOpen className="w-3.5 h-3.5" />,
      activeClass:
        "bg-gradient-to-b from-blue-500 to-blue-600 text-white border-blue-400/50 shadow-[0_4px_12px_rgba(37,99,235,0.34),inset_0_1px_0_rgba(255,255,255,0.35)]",
      idleClass:
        "bg-gradient-to-b from-white/95 to-blue-50/90 text-blue-700 border-blue-200/75 hover:to-blue-100/85",
    },
    {
      id: "loop",
      label: "Study Loop",
      icon: <Sparkles className="w-3.5 h-3.5" />,
      activeClass:
        "bg-gradient-to-b from-indigo-500 to-violet-600 text-white border-indigo-400/50 shadow-[0_4px_12px_rgba(99,102,241,0.34),inset_0_1px_0_rgba(255,255,255,0.35)]",
      idleClass:
        "bg-gradient-to-b from-white/95 to-indigo-50/90 text-indigo-700 border-indigo-200/75 hover:to-indigo-100/85",
    },
    {
      id: "chat",
      label: "Free AI Chat",
      icon: <MessageSquare className="w-3.5 h-3.5" />,
      activeClass:
        "bg-gradient-to-b from-emerald-500 to-teal-600 text-white border-emerald-400/50 shadow-[0_4px_12px_rgba(16,185,129,0.34),inset_0_1px_0_rgba(255,255,255,0.35)]",
      idleClass:
        "bg-gradient-to-b from-white/95 to-emerald-50/90 text-emerald-700 border-emerald-200/75 hover:to-emerald-100/85",
    },
    ...(studentIdentity?.isKvStudent
      ? [
          {
            id: "tests" as AppPage,
            label: "KVS Tests",
            icon: <ClipboardCheck className="w-3.5 h-3.5" />,
            activeClass:
              "bg-gradient-to-b from-amber-500 to-orange-500 text-white border-amber-300/60 shadow-[0_4px_12px_rgba(245,158,11,0.34),inset_0_1px_0_rgba(255,255,255,0.35)]",
            idleClass:
              "bg-gradient-to-b from-white/95 to-amber-50/90 text-amber-700 border-amber-200/75 hover:to-amber-100/85",
          },
        ]
      : []),
    {
      id: "stage",
      label: "3D Stage",
      icon: <Box className="w-3.5 h-3.5" />,
      activeClass:
        "bg-gradient-to-b from-fuchsia-500 to-rose-500 text-white border-fuchsia-300/50 shadow-[0_4px_12px_rgba(217,70,239,0.34),inset_0_1px_0_rgba(255,255,255,0.35)]",
      idleClass:
        "bg-gradient-to-b from-white/95 to-rose-50/90 text-rose-700 border-rose-200/75 hover:to-rose-100/85",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col ios-app-bg text-stone-900">
      {/* Strict 3-Zone Top Bar Contract with Tutorix AI Logo & Account Button */}
      <header className="no-print sticky top-0 z-30 border-b backdrop-blur-xl bg-white/75 border-slate-200/80 shadow-[0_1px_12px_rgba(15,23,42,0.04)]">
          <div className="max-w-[1380px] mx-auto px-4 sm:px-6 min-h-16 py-2 flex flex-wrap lg:flex-nowrap items-center justify-between gap-3 lg:gap-4">
            {/* Zone 1: Tutorix AI Brand Lockup */}
            <a
              href="#home"
              onClick={(e) => {
                e.preventDefault();
                setActivePage("home");
              }}
              title="Back to Tutorix AI Home"
              className="inline-flex items-center gap-2.5 font-display text-xl font-semibold tracking-tight text-stone-900 whitespace-nowrap shrink-0 hover:opacity-85 transition-opacity"
            >
              <img
                src="/assets/aistudio/image_555f3288.png"
                alt="Tutorix AI logo"
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-xl shadow-xs object-cover"
              />
              <span>Tutorix AI</span>
            </a>

            {/* Zone 2: Colorful iOS Glass Navigation Dock (Zero Sliding) */}
            <nav
              aria-label="Primary Workspace Navigation"
              className="order-3 lg:order-2 w-full lg:w-auto inline-flex flex-wrap items-center justify-center gap-1.5 p-1.5 rounded-[20px] bg-white/65 backdrop-blur-2xl border border-white/90 shadow-[0_4px_18px_rgba(15,23,42,0.06),inset_0_1px_0_rgba(255,255,255,0.95)]"
            >
              {navItems.map((item) => {
                const isActive =
                  activePage === item.id ||
                  (item.id === "loop" && activePage === "notes");
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      if (item.id === "chat" || item.id === "stage") {
                        setReturnPage(activePage);
                      }
                      setActivePage(item.id);
                    }}
                    className={`inline-flex items-center gap-1.5 py-1.5 px-3 rounded-[14px] text-xs font-semibold border transition-all duration-200 active:scale-[0.96] whitespace-nowrap shrink-0 cursor-pointer ${
                      isActive
                        ? item.activeClass
                        : `${item.idleClass} shadow-[0_1px_3px_rgba(15,23,42,0.04),inset_0_1px_0_rgba(255,255,255,0.95)]`
                    }`}
                  >
                    {item.icon}
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>

            {/* Zone 3: Student Fixed ID + Blackhole CTA + Teacher Account Logo Button */}
            <div className="order-2 lg:order-3 flex items-center gap-2 shrink-0">
              {studentIdentity && (
                <button
                  type="button"
                  onClick={() => setShowProfileModal(true)}
                  title={`${studentIdentity.name} · ${
                    studentIdentity.board || "CBSE"
                  } · ${studentIdentity.studentClass} · ID: ${
                    studentIdentity.studentId
                  }`}
                  className="ios-glass-btn inline-flex items-center gap-1.5 px-2.5 py-2 rounded-2xl text-xs font-medium text-indigo-800 border-indigo-200/80 cursor-pointer whitespace-nowrap shrink-0"
                >
                  <IdCard className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                  <span className="hidden xl:inline max-w-[110px] truncate">
                    {studentIdentity.name}
                  </span>
                  <span className="font-mono-tabular text-[11px] font-semibold text-indigo-700">
                    {studentIdentity.studentId}
                  </span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setActivePage("blackhole")}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-semibold bg-black text-white hover:bg-zinc-900 border border-white/15 shadow-md transition-transform active:scale-[0.97] whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Orbit className="w-3.5 h-3.5 text-amber-300" />
                <span>Blackhole</span>
              </button>

              <button
                type="button"
                onClick={openAccountPortal}
                title={
                  teacherSession
                    ? `${teacherSession.teacherName} (KVS Teacher Portal)`
                    : "Account · KVS Teacher Login"
                }
                aria-label="Teacher Account Login"
                className={`ios-glass-btn inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-medium cursor-pointer whitespace-nowrap shrink-0 ${
                  teacherSession
                    ? "text-blue-700 border-blue-200"
                    : "text-stone-800"
                }`}
              >
                <UserCircle2 className="w-4 h-4" />
                <span className="hidden lg:inline">
                  {teacherSession ? teacherSession.teacherName : "Teacher Portal"}
                </span>
              </button>
            </div>
          </div>
        </header>

      {/* Student Name / Board / Class Onboarding */}
      {((!studentIdentity && userRole === "student" && !showTeacherLogin) ||
        showProfileModal) && (
        <StudentOnboardingModal
          existingProfile={studentIdentity}
          defaultClass={studentContext.studentClass}
          onComplete={handleStudentOnboarded}
          onLogout={handleStudentLogout}
          onOpenTeacherLogin={() => {
            setShowProfileModal(false);
            setPendingJourneyDestination(null);
            setShowTeacherLogin(true);
          }}
          onClose={
            studentIdentity
              ? () => {
                  setShowProfileModal(false);
                  setPendingJourneyDestination(null);
                }
              : undefined
          }
        />
      )}

      {/* Separate Dedicated Pages */}
      <main className="flex-1">
        {activePage === "syllabus" && (
          <CbseSyllabusPage
            studentContext={studentContext}
            studentIdentity={studentIdentity}
            onEditStudentProfile={() => setShowProfileModal(true)}
            cachedOverviews={Object.fromEntries(
              lessons
                .map((l) => [
                  l.title,
                  cachedOverviews[
                    overviewCacheKey(
                      studentContext.studentClass,
                      studentContext.subject,
                      l.title
                    )
                  ],
                ])
                .filter((pair): pair is [string, LessonOverview] =>
                  Boolean(pair[1])
                )
            )}
            onChangeStudentClass={handleChangeStudentClass}
            onChangeSubject={handleChangeSubject}
            lessons={lessons}
            lessonsSyncing={lessonsSyncing}
            lessonsSyncedLive={lessonsSyncedLive}
            onRefreshLessons={() => fetchLatestLessons(studentContext)}
            onStartStudyLoopForLesson={handleStartStudyLoopForLesson}
            onAskChatForLesson={handleAskChatForLesson}
            onOpenBlackholeForLesson={handleOpenBlackholeForLesson}
            onOpen3DForLesson={handleOpen3DForLesson}
            onSwitchRole={openAccountPortal}
          />
        )}

        {activePage === "loop" && (
          <NewsroomWorkspace
            state={state}
            studentContext={studentContext}
            lessons={lessons}
            onChangeStudentClass={handleChangeStudentClass}
            onChangeSubject={handleChangeSubject}
            onSelectLesson={handleSelectLessonInLoop}
            topicInput={topicInput}
            setTopicInput={setTopicInput}
            depth={depth}
            setDepth={setDepth}
            attachedImage={attachedImage}
            setAttachedImage={setAttachedImage}
            onStartInvestigation={(override) =>
              handleStartInvestigation(override)
            }
            onStopInvestigation={handleStopInvestigation}
            onOpenSyllabus={() => setActivePage("syllabus")}
            onExpand3DStage={() => {
              setReturnPage("loop");
              setActivePage("stage");
            }}
            onOpenReport={() => setActivePage("notes")}
            onOpenChat={() => {
              setReturnPage("loop");
              setActivePage("chat");
            }}
            onAskTopicInChat={(prompt) => {
              setPendingChatPrompt(prompt);
              setReturnPage("loop");
              setActivePage("chat");
            }}
            overviewLoading={overviewLoading}
            onGenerateQuickOverview={() => handleGenerateQuickOverview()}
            onNewTopic={handleNewTopic}
          />
        )}

        {activePage === "notes" && (
          <MarkdownReportView
            topic={state.topic}
            phase={state.phase}
            reportMarkdown={state.reportMarkdown}
            claims={state.claims}
            sources={state.sources}
            visualBrief={state.visualBrief}
            completedAt={state.completedAt}
            onGoToNewsroom={() => setActivePage("loop")}
            onAskTopicInChat={(prompt) => {
              setPendingChatPrompt(prompt);
              setReturnPage("notes");
              setActivePage("chat");
            }}
          />
        )}

        {activePage === "chat" && (
          <CrewChatPanel
            topic={state.topic || topicInput}
            claims={state.claims}
            reportMarkdown={state.reportMarkdown}
            studentContext={studentContext}
            pendingPrompt={pendingChatPrompt}
            onConsumePendingPrompt={() => setPendingChatPrompt(null)}
            onBack={() =>
              setActivePage(
                returnPage === "chat" || returnPage === "stage"
                  ? "syllabus"
                  : returnPage
              )
            }
          />
        )}

        {activePage === "tests" && (
          <StudentTestsPage
            studentContext={studentContext}
            studentIdentity={studentIdentity}
            onAskDoubtInAiChat={(prompt) => {
              setPendingChatPrompt(prompt);
              setReturnPage("tests");
              setActivePage("chat");
            }}
            onOpenTeacherLogin={openAccountPortal}
          />
        )}
      </main>
    </div>
  );
}
