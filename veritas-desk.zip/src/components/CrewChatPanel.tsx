import React, { useRef, useState, useEffect } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  Send,
  ImagePlus,
  X,
  ExternalLink,
  Loader2,
  BrainCircuit,
  Trash2,
  ArrowLeft,
  Sparkles,
} from "lucide-react";
import {
  generateFreeLocalTutorReply,
  safeJsonResponse,
} from "../utils/freeLocalChat";
import type {
  AgentId,
  ChatTurn,
  GroundedSource,
  ResearchClaim,
  StudentProfileContext,
  UploadedImagePayload,
} from "../types";

interface CrewChatPanelProps {
  topic: string;
  claims: ResearchClaim[];
  reportMarkdown: string;
  studentContext: StudentProfileContext;
  pendingPrompt?: string | null;
  onConsumePendingPrompt?: () => void;
  onBack?: () => void;
}

const PERSONA_OPTIONS: Array<{
  id: "crew" | AgentId;
  label: string;
  subtitle: string;
}> = [
  { id: "crew", label: "Study Crew", subtitle: "All 3 tutors" },
  { id: "researcher", label: "Elena · Concepts", subtitle: "Simple examples" },
  { id: "fact_checker", label: "Marcus · Doubts", subtitle: "Fix mistakes" },
  { id: "editor", label: "Clara · Exam Coach", subtitle: "Notes & quizzes" },
];

export const CrewChatPanel: React.FC<CrewChatPanelProps> = ({
  topic,
  claims,
  reportMarkdown,
  studentContext,
  pendingPrompt,
  onConsumePendingPrompt,
  onBack,
}) => {
  const [turns, setTurns] = useState<ChatTurn[]>([]);
  const [input, setInput] = useState("");
  const [persona, setPersona] = useState<"crew" | AgentId>("crew");
  const [deepThinking, setDeepThinking] = useState(true);
  const [attachedImage, setAttachedImage] =
    useState<UploadedImagePayload | null>(null);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const threadEndRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const activeSubjectLabel = `${studentContext.studentClass} CBSE ${studentContext.subject}`;

  const starterPrompts = [
    `Explain ${
      studentContext.lessonTitle || studentContext.subject
    } in super simple words with a daily-life example for ${studentContext.studentClass}.`,
    `I have a doubt in ${
      studentContext.lessonTitle || activeSubjectLabel
    } — walk me through the core concept and solved numericals/examples step by step.`,
    `Give me 5 important CBSE questions (with easy answers) from ${
      studentContext.lessonTitle || activeSubjectLabel
    }.`,
  ];

  useEffect(() => {
    threadEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [turns, sending]);

  useEffect(() => {
    if (pendingPrompt && pendingPrompt.trim()) {
      const promptToRun = pendingPrompt.trim();
      onConsumePendingPrompt?.();
      void sendMessage(promptToRun);
    }
  }, [pendingPrompt]);

  const handleImagePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Please select a PNG, JPEG, or WebP image.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || "");
      const base64 = result.split(",")[1] || "";
      setAttachedImage({
        mimeType: file.type,
        data: base64,
        name: file.name,
        previewUrl: result,
      });
      setError(null);
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const sendMessage = async (overrideText?: string) => {
    const textToSend = (overrideText ?? input).trim();
    if ((!textToSend && !attachedImage) || sending) return;

    const userTurn: ChatTurn = {
      id: `user-${Date.now()}`,
      role: "user",
      text: textToSend || "Please explain this textbook photo step by step.",
      imagePreview: attachedImage?.previewUrl,
      timestamp: new Date().toISOString(),
    };

    const currentImage = attachedImage;
    const historySnapshot = turns.map((t) => ({ role: t.role, text: t.text }));

    setTurns((prev) => [...prev, userTurn]);
    if (!overrideText) setInput("");
    setAttachedImage(null);
    setSending(true);
    setError(null);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userTurn.text,
          history: historySnapshot,
          persona,
          deepThinking,
          studentContext,
          investigationContext: topic
            ? {
                topic,
                claims,
                reportMarkdown,
              }
            : undefined,
          image: currentImage
            ? {
                mimeType: currentImage.mimeType,
                data: currentImage.data,
              }
            : undefined,
        }),
      });

      const data = await safeJsonResponse<{
        reply?: string;
        sources?: GroundedSource[];
      }>(res);

      if (res.ok && data?.reply) {
        const modelTurn: ChatTurn = {
          id: `model-${Date.now()}`,
          role: "model",
          persona,
          text: data.reply,
          sources: Array.isArray(data.sources) ? data.sources : [],
          timestamp: new Date().toISOString(),
          thinkingUsed: deepThinking,
        };
        setTurns((prev) => [...prev, modelTurn]);
        return;
      }
    } catch {
      // Seamless free local AI tutor fallback below
    } finally {
      setSending(false);
    }

    // Free built-in NCERT study tutor response (works seamlessly on Vercel static builds & offline!)
    const localReply = generateFreeLocalTutorReply({
      message: userTurn.text,
      persona,
      deepThinking,
      studentContext,
      hasImage: Boolean(currentImage),
      investigationContext: topic
        ? {
            topic,
            claims,
            reportMarkdown,
          }
        : undefined,
    });

    const fallbackTurn: ChatTurn = {
      id: `model-${Date.now()}`,
      role: "model",
      persona,
      text: localReply,
      sources: [],
      timestamp: new Date().toISOString(),
      thinkingUsed: deepThinking,
    };
    setTurns((prev) => [...prev, fallbackTurn]);
  };

  return (
    <div className="page-transition-enter max-w-[1040px] mx-auto px-3.5 sm:px-6 py-4 sm:py-6">
      <div className="ios-glass-card rounded-3xl overflow-hidden flex flex-col h-[calc(100vh-9.75rem)] min-h-[500px] max-h-[760px] shadow-xl border border-white/85 text-stone-900">
        {/* Framed Chat Toolbar Header */}
        <div className="px-4 sm:px-6 py-3.5 border-b border-slate-200/80 bg-white/80 backdrop-blur-xl flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="ios-glass-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-2xl text-xs font-medium text-stone-800 cursor-pointer whitespace-nowrap shrink-0"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
            )}
            <img
              src="/assets/aistudio/image_555f3288.png"
              alt="Tutorix AI logo"
              referrerPolicy="no-referrer"
              className="w-8 h-8 rounded-xl object-cover shrink-0 shadow-xs"
            />
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="font-display text-base font-semibold text-stone-900 leading-tight">
                  Free AI Study Chat
                </h1>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/80">
                  <Sparkles className="w-2.5 h-2.5" />
                  <span>Free · Always Ready</span>
                </span>
              </div>
              <p className="text-[11px] text-stone-500 truncate">
                {activeSubjectLabel}
                {studentContext.lessonTitle
                  ? ` · ${studentContext.lessonTitle}`
                  : ""}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Persona Segmented Control */}
            <div className="ios-segmented hidden md:flex items-center gap-1 p-1 rounded-2xl">
              {PERSONA_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setPersona(opt.id)}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-medium transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                    persona === opt.id
                      ? "bg-white text-stone-900 shadow-sm"
                      : "text-stone-600 hover:text-stone-900"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            {/* Deep Thinking Toggle */}
            <button
              type="button"
              onClick={() => setDeepThinking((v) => !v)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-2xl text-xs font-medium cursor-pointer whitespace-nowrap ${
                deepThinking
                  ? "ios-glass-btn-primary"
                  : "ios-glass-btn text-stone-700"
              }`}
            >
              <BrainCircuit className="w-3.5 h-3.5" />
              <span>{deepThinking ? "Deep Think: On" : "Deep Think: Off"}</span>
            </button>

            {turns.length > 0 && (
              <button
                type="button"
                onClick={() => setTurns([])}
                title="Clear conversation"
                className="ios-glass-btn inline-flex items-center gap-1 px-3 py-1.5 rounded-2xl text-xs text-stone-700 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            )}
          </div>
        </div>

        {/* Scrollable Conversation Thread Inside Framed Window */}
        <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-5 bg-white/40">
          <div className="max-w-3xl mx-auto space-y-5">
            {turns.length === 0 ? (
              <div className="max-w-xl mx-auto py-8 sm:py-10 text-center">
                <p className="font-display text-xl sm:text-2xl font-semibold text-stone-900">
                  Tutorix AI Study Chat · {activeSubjectLabel}
                </p>
                <p className="mt-2 text-xs sm:text-sm text-stone-600 leading-relaxed">
                  Ask any doubt from your lesson, get instant free step-by-step
                  NCERT explanations, formulas, solved examples, or practice CBSE
                  questions.
                </p>

                <div className="mt-5 space-y-2.5 text-left">
                  {starterPrompts.map((prompt) => (
                    <button
                      key={prompt}
                      type="button"
                      onClick={() => sendMessage(prompt)}
                      className="ios-glass-btn w-full text-left px-4 py-3 rounded-2xl text-xs font-medium text-stone-800 cursor-pointer"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              turns.map((turn) => {
                const isUser = turn.role === "user";
                const personaMeta = PERSONA_OPTIONS.find(
                  (p) => p.id === (turn.persona || "crew")
                );
                return (
                  <div
                    key={turn.id}
                    className={`flex ${isUser ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[88%] sm:max-w-[82%] rounded-2xl px-4 sm:px-5 py-3.5 shadow-2xs ${
                        isUser
                          ? "bg-stone-900 text-stone-50"
                          : "bg-white/95 border border-stone-200/90 text-stone-900"
                      }`}
                    >
                      <div
                        className={`flex items-center gap-2 text-[11px] mb-1.5 ${
                          isUser ? "text-stone-300" : "text-stone-500"
                        }`}
                      >
                        <span className="font-semibold">
                          {isUser
                            ? "Student"
                            : personaMeta?.label || "Study Crew"}
                        </span>
                        {!isUser && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{personaMeta?.subtitle}</span>
                          </>
                        )}
                      </div>

                      {turn.imagePreview && (
                        <img
                          src={turn.imagePreview}
                          alt="Uploaded homework or diagram"
                          referrerPolicy="no-referrer"
                          className="mb-3 max-h-52 rounded-lg border border-white/20 object-contain"
                        />
                      )}

                      {isUser ? (
                        <p className="text-sm leading-relaxed whitespace-pre-wrap">
                          {turn.text}
                        </p>
                      ) : (
                        <div className="prose-sm text-sm text-stone-800 leading-relaxed space-y-2.5 [&_a]:text-blue-700 [&_a]:underline [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:list-decimal [&_ol]:pl-5 [&_h3]:font-semibold [&_h3]:text-stone-900 [&_h4]:font-semibold [&_h4]:text-stone-900 [&_code]:bg-slate-100 [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:rounded-md [&_code]:text-xs">
                          <ReactMarkdown
                            remarkPlugins={[remarkGfm]}
                            components={{
                              a: ({ href, children }) => (
                                <a
                                  href={href}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                >
                                  {children}
                                </a>
                              ),
                            }}
                          >
                            {turn.text}
                          </ReactMarkdown>
                        </div>
                      )}

                      {turn.sources && turn.sources.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-stone-200">
                          <p className="text-[11px] font-medium text-stone-500 mb-1.5">
                            Helpful Learning Links
                          </p>
                          <div className="flex flex-wrap gap-x-4 gap-y-1">
                            {turn.sources.map((src) => (
                              <a
                                key={src.url}
                                href={src.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 text-xs text-blue-700 hover:underline"
                              >
                                <span className="truncate max-w-[200px]">
                                  {src.title}
                                </span>
                                <ExternalLink className="w-3 h-3 shrink-0" />
                              </a>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}

            {sending && (
              <div className="flex justify-start">
                <div className="rounded-2xl px-4 py-3 bg-white/95 border border-stone-200 text-xs text-stone-600 flex items-center gap-2.5 shadow-2xs">
                  <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                  <span>
                    {PERSONA_OPTIONS.find((p) => p.id === persona)?.label} is
                    preparing an easy explanation...
                  </span>
                </div>
              </div>
            )}

            <div ref={threadEndRef} />
          </div>
        </div>

        {/* File type validation notice if any */}
        {error && (
          <div className="px-4 sm:px-6 pb-2">
            <div className="px-4 py-2 rounded-2xl border border-red-200 bg-red-50 text-xs text-red-800 flex items-center justify-between">
              <span>{error}</span>
              <button
                type="button"
                onClick={() => setError(null)}
                className="text-red-700 hover:text-red-900 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Framed Bottom Composer */}
        <div className="px-4 sm:px-6 py-3.5 border-t border-slate-200/80 bg-white/85 backdrop-blur-xl shrink-0">
          {attachedImage && (
            <div className="mb-2.5 inline-flex items-center gap-2.5 px-3 py-1.5 rounded-2xl border border-slate-200/80 bg-white">
              <img
                src={attachedImage.previewUrl}
                alt={attachedImage.name}
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-lg object-cover"
              />
              <span className="text-xs text-stone-700 max-w-[180px] truncate">
                {attachedImage.name}
              </span>
              <button
                type="button"
                onClick={() => setAttachedImage(null)}
                className="text-stone-400 hover:text-stone-800 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          <div className="flex items-end gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImagePick}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              title="Upload textbook page, diagram, or homework question"
              className="ios-glass-btn p-2.5 rounded-2xl text-stone-700 cursor-pointer shrink-0"
            >
              <ImagePlus className="w-4 h-4" />
            </button>

            <textarea
              rows={2}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void sendMessage();
                }
              }}
              placeholder={`Ask any ${studentContext.studentClass} ${studentContext.subject} doubt or question...`}
              className="flex-1 resize-none rounded-2xl border border-slate-200/90 bg-white px-4 py-2 text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:border-blue-500"
            />

            <button
              type="button"
              onClick={() => sendMessage()}
              disabled={sending || (!input.trim() && !attachedImage)}
              className="ios-glass-btn-primary inline-flex items-center gap-1.5 px-5 py-2.5 rounded-2xl text-sm font-medium disabled:opacity-40 cursor-pointer shrink-0"
            >
              <Send className="w-4 h-4" />
              <span>Ask</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
