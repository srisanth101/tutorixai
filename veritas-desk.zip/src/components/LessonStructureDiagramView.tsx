import React, { useRef, useState } from "react";
import { Download, MessageSquare, Sparkles } from "lucide-react";
import type { LessonStructureDiagram, StructureDiagramBranch } from "../types";

interface LessonStructureDiagramViewProps {
  diagram: LessonStructureDiagram;
  onAskTopicInChat?: (topicLabel: string) => void;
}

const ACCENT_PALETTE: Record<
  NonNullable<StructureDiagramBranch["accent"]>,
  { fill: string; stroke: string; headerFill: string; text: string; dot: string }
> = {
  blue: {
    fill: "#EFF6FF",
    stroke: "#93C5FD",
    headerFill: "#2563EB",
    text: "#1E3A8A",
    dot: "#3B82F6",
  },
  indigo: {
    fill: "#EEF2FF",
    stroke: "#A5B4FC",
    headerFill: "#4F46E5",
    text: "#312E81",
    dot: "#6366F1",
  },
  emerald: {
    fill: "#ECFDF5",
    stroke: "#6EE7B7",
    headerFill: "#059669",
    text: "#064E3B",
    dot: "#10B981",
  },
  amber: {
    fill: "#FFFBEB",
    stroke: "#FCD34D",
    headerFill: "#D97706",
    text: "#78350F",
    dot: "#F59E0B",
  },
  rose: {
    fill: "#FFF1F2",
    stroke: "#FDA4AF",
    headerFill: "#E11D48",
    text: "#881337",
    dot: "#F43F5E",
  },
  violet: {
    fill: "#F5F3FF",
    stroke: "#C4B5FD",
    headerFill: "#7C3AED",
    text: "#4C1D95",
    dot: "#8B5CF6",
  },
};

function wrapSvgLines(text: string, maxChars: number, maxLines = 2): string[] {
  const words = text.trim().split(/\s+/);
  const lines: string[] = [];
  let current = "";
  for (const w of words) {
    if (!current) {
      current = w;
    } else if (current.length + 1 + w.length <= maxChars) {
      current += ` ${w}`;
    } else {
      lines.push(current);
      current = w;
      if (lines.length === maxLines) break;
    }
  }
  if (current && lines.length < maxLines) {
    lines.push(current);
  } else if (current && lines.length === maxLines) {
    const last = lines[maxLines - 1];
    if (!last.endsWith("…")) {
      lines[maxLines - 1] = `${last.slice(0, Math.max(0, maxChars - 1))}…`;
    }
  }
  return lines;
}

export const LessonStructureDiagramView: React.FC<
  LessonStructureDiagramViewProps
> = ({ diagram, onAskTopicInChat }) => {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [downloading, setDownloading] = useState(false);

  const branches = diagram.branches.slice(0, 6);
  const cols = branches.length <= 2 ? branches.length || 1 : branches.length === 4 ? 2 : 3;
  const rows = Math.max(1, Math.ceil(branches.length / cols));

  const svgWidth = 1080;
  const headerY = 34;
  const hubW = 460;
  const hubH = 92;
  const hubX = (svgWidth - hubW) / 2;
  const hubY = 74;

  const gridTop = 212;
  const colGap = 24;
  const rowGap = 24;
  const marginX = 36;
  const cardW = (svgWidth - marginX * 2 - colGap * (cols - 1)) / cols;
  const cardH = 210;
  const svgHeight = gridTop + rows * cardH + (rows - 1) * rowGap + 44;

  const handleDownloadPng = () => {
    const svgEl = svgRef.current;
    if (!svgEl || downloading) return;
    setDownloading(true);
    try {
      const serializer = new XMLSerializer();
      const svgStr = serializer.serializeToString(svgEl);
      const blob = new Blob([svgStr], {
        type: "image/svg+xml;charset=utf-8",
      });
      const url = URL.createObjectURL(blob);
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = svgWidth * 2;
        canvas.height = svgHeight * 2;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.fillStyle = "#F8FAFC";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const pngUrl = canvas.toDataURL("image/png");
          const a = document.createElement("a");
          a.href = pngUrl;
          const slug = diagram.centralTitle
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "-")
            .slice(0, 32);
          a.download = `${slug || "lesson"}-structure-gemini.png`;
          a.click();
        }
        URL.revokeObjectURL(url);
        setDownloading(false);
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        setDownloading(false);
      };
      img.src = url;
    } catch {
      setDownloading(false);
    }
  };

  return (
    <div className="ios-glass-card rounded-3xl p-5 md:p-6 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[11px] font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs">
            <Sparkles className="w-3 h-3" />
            <span>Gemini Visual Structure</span>
          </span>
          <span className="text-xs text-stone-500">
            Click any box in the diagram to ask Gemini AI Chat
          </span>
        </div>

        <button
          type="button"
          onClick={handleDownloadPng}
          disabled={downloading}
          className="ios-glass-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-stone-800 cursor-pointer whitespace-nowrap disabled:opacity-50"
        >
          <Download className="w-3.5 h-3.5" />
          <span>{downloading ? "Saving PNG..." : "Save Structure Image"}</span>
        </button>
      </div>

      <div className="rounded-2xl border border-slate-200/80 bg-[#F8FAFC] overflow-hidden shadow-inner">
        <svg
          ref={svgRef}
          viewBox={`0 0 ${svgWidth} ${svgHeight}`}
          className="w-full h-auto block select-none"
          role="img"
          aria-label={diagram.diagramTitle}
        >
          <defs>
            <linearGradient id="ss-bg" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#F8FAFC" />
              <stop offset="100%" stopColor="#EEF2FF" />
            </linearGradient>
            <linearGradient id="ss-hub" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#0BC5C2" />
              <stop offset="100%" stopColor="#1D4ED8" />
            </linearGradient>
          </defs>

          <rect width={svgWidth} height={svgHeight} fill="url(#ss-bg)" rx="18" />

          {/* Subtle Blueprint Grid */}
          <g stroke="#CBD5E1" strokeOpacity="0.28" strokeWidth="1">
            {Array.from({ length: 14 }).map((_, i) => (
              <line
                key={`v-${i}`}
                x1={(i + 1) * 75}
                y1={0}
                x2={(i + 1) * 75}
                y2={svgHeight}
              />
            ))}
            {Array.from({ length: 10 }).map((_, i) => (
              <line
                key={`h-${i}`}
                x1={0}
                y1={(i + 1) * 75}
                x2={svgWidth}
                y2={(i + 1) * 75}
              />
            ))}
          </g>

          {/* Diagram Header Title */}
          <text
            x={svgWidth / 2}
            y={headerY}
            textAnchor="middle"
            fill="#0F172A"
            fontSize="16"
            fontWeight="700"
            fontFamily="Plus Jakarta Sans, sans-serif"
          >
            {diagram.diagramTitle}
          </text>
          <text
            x={svgWidth - 28}
            y={headerY}
            textAnchor="end"
            fill="#64748B"
            fontSize="11"
            fontWeight="600"
            fontFamily="Plus Jakarta Sans, sans-serif"
          >
            Generated by Gemini
          </text>

          {/* Connector Paths from Central Hub to Each Branch Card */}
          {branches.map((branch, idx) => {
            const col = idx % cols;
            const row = Math.floor(idx / cols);
            const x = marginX + col * (cardW + colGap);
            const y = gridTop + row * (cardH + rowGap);
            const targetX = x + cardW / 2;
            const targetY = y;
            const startX = svgWidth / 2;
            const startY = hubY + hubH;
            const palette =
              ACCENT_PALETTE[branch.accent || "blue"] || ACCENT_PALETTE.blue;

            const midY = row === 0 ? startY + 24 : y - 14;
            return (
              <path
                key={`edge-${idx}`}
                d={`M ${startX} ${startY} C ${startX} ${midY}, ${targetX} ${
                  midY
                }, ${targetX} ${targetY}`}
                fill="none"
                stroke={palette.stroke}
                strokeWidth="2.4"
                strokeDasharray={
                  diagram.diagramType === "process" ? "6 4" : undefined
                }
              />
            );
          })}

          {/* Central Hub Node */}
          <g
            onClick={() =>
              onAskTopicInChat?.(
                `${diagram.centralTitle}: ${diagram.centralSubtitle}`
              )
            }
            style={{ cursor: onAskTopicInChat ? "pointer" : "default" }}
          >
            <rect
              x={hubX}
              y={hubY}
              width={hubW}
              height={hubH}
              rx="20"
              fill="url(#ss-hub)"
            />
            <rect
              x={hubX + 2}
              y={hubY + 2}
              width={hubW - 4}
              height={hubH - 4}
              rx="18"
              fill="none"
              stroke="#FFFFFF"
              strokeOpacity="0.35"
              strokeWidth="1.5"
            />
            <text
              x={svgWidth / 2}
              y={hubY + 38}
              textAnchor="middle"
              fill="#FFFFFF"
              fontSize="19"
              fontWeight="700"
              fontFamily="Plus Jakarta Sans, sans-serif"
            >
              {wrapSvgLines(diagram.centralTitle, 38, 1)[0]}
            </text>
            <text
              x={svgWidth / 2}
              y={hubY + 64}
              textAnchor="middle"
              fill="#E0F2FE"
              fontSize="12.5"
              fontWeight="500"
              fontFamily="Plus Jakarta Sans, sans-serif"
            >
              {wrapSvgLines(diagram.centralSubtitle, 58, 1)[0]}
            </text>
          </g>

          {/* Branch Cards */}
          {branches.map((branch, idx) => {
            const col = idx % cols;
            const row = Math.floor(idx / cols);
            const x = marginX + col * (cardW + colGap);
            const y = gridTop + row * (cardH + rowGap);
            const palette =
              ACCENT_PALETTE[branch.accent || "blue"] || ACCENT_PALETTE.blue;
            const maxCharsPerLine = cols === 3 ? 33 : 48;

            return (
              <g
                key={`card-${idx}`}
                onClick={() =>
                  onAskTopicInChat?.(
                    `${branch.title} (${branch.items.join("; ")})`
                  )
                }
                style={{ cursor: onAskTopicInChat ? "pointer" : "default" }}
              >
                <rect
                  x={x}
                  y={y}
                  width={cardW}
                  height={cardH}
                  rx="16"
                  fill="#FFFFFF"
                  stroke={palette.stroke}
                  strokeWidth="1.8"
                />
                {/* Colored Header Pill Strip */}
                <rect
                  x={x}
                  y={y}
                  width={cardW}
                  height={44}
                  rx="16"
                  fill={palette.headerFill}
                />
                <rect
                  x={x}
                  y={y + 28}
                  width={cardW}
                  height={16}
                  fill={palette.headerFill}
                />
                <text
                  x={x + 16}
                  y={y + 27}
                  fill="#FFFFFF"
                  fontSize="13.5"
                  fontWeight="700"
                  fontFamily="Plus Jakarta Sans, sans-serif"
                >
                  {idx + 1}. {wrapSvgLines(branch.title, maxCharsPerLine - 4, 1)[0]}
                </text>

                {branch.subtitle && (
                  <text
                    x={x + 16}
                    y={y + 64}
                    fill={palette.text}
                    fontSize="11.5"
                    fontWeight="600"
                    fontFamily="Plus Jakarta Sans, sans-serif"
                  >
                    {wrapSvgLines(branch.subtitle, maxCharsPerLine, 1)[0]}
                  </text>
                )}

                {/* Items inside Card */}
                {branch.items.slice(0, 4).map((item, itemIdx) => {
                  const baseY =
                    y + (branch.subtitle ? 88 : 72) + itemIdx * 31;
                  const lines = wrapSvgLines(item, maxCharsPerLine, 2);
                  return (
                    <g key={`item-${itemIdx}`}>
                      <circle
                        cx={x + 20}
                        cy={baseY - 4}
                        r="3.2"
                        fill={palette.dot}
                      />
                      <text
                        x={x + 30}
                        y={baseY}
                        fill="#334155"
                        fontSize="11.5"
                        fontWeight="500"
                        fontFamily="Plus Jakarta Sans, sans-serif"
                      >
                        {lines.map((line, lIdx) => (
                          <tspan
                            key={lIdx}
                            x={x + 30}
                            dy={lIdx === 0 ? 0 : 13}
                          >
                            {line}
                          </tspan>
                        ))}
                      </text>
                    </g>
                  );
                })}
              </g>
            );
          })}

          {/* Footer Legend */}
          <text
            x={svgWidth / 2}
            y={svgHeight - 14}
            textAnchor="middle"
            fill="#64748B"
            fontSize="11"
            fontFamily="Plus Jakarta Sans, sans-serif"
          >
            Tutorix AI · Lesson Structure Diagram (click any section to ask in AI Study Chat)
          </text>
        </svg>
      </div>

      {onAskTopicInChat && (
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-stone-500">
          <span>
            Tip: Click any branch box above to get a deeper AI Tutor explanation.
          </span>
          <button
            type="button"
            onClick={() => onAskTopicInChat(diagram.diagramTitle)}
            className="inline-flex items-center gap-1.5 text-emerald-700 font-semibold hover:underline cursor-pointer"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Explain whole diagram in Free AI Chat</span>
          </button>
        </div>
      )}
    </div>
  );
};
