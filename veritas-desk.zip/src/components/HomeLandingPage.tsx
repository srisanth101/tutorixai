import React, { useEffect, useState } from "react";
import {
  ArrowRight,
  BookOpen,
  Box,
  ClipboardCheck,
  Compass,
  GraduationCap,
  IdCard,
  Layers,
  MessageSquare,
  Orbit,
  Sparkles,
  UserCircle2,
} from "lucide-react";
import type { StudentIdentity, StudentProfileContext } from "../types";

export type HomeDestination =
  | "syllabus"
  | "loop"
  | "chat"
  | "stage"
  | "tests"
  | "blackhole";

interface HomeLandingPageProps {
  studentIdentity: StudentIdentity | null;
  studentContext: StudentProfileContext;
  onGetIntoJourney: () => void;
  onNavigate: (destination: HomeDestination) => void;
  onOpenProfileModal: () => void;
  onOpenTeacherPortal: () => void;
}

const ROTATING_HIGHLIGHTS = [
  "Instant NCERT & All-India chapter summaries with zero wait",
  "Visual lesson structure maps, key points & every exam formula",
  "Full-screen Gemini AI chat for doubts & textbook problem photos",
  "Interactive 3D lab simulations, KVS tests & Blackhole revision mode",
];

interface FeatureTile {
  id: HomeDestination;
  title: string;
  subtitle: string;
  meta: string;
  accentGradient: string;
  borderTint: string;
  iconBg: string;
  iconColor: string;
  icon: React.ReactNode;
  spanClass?: string;
}

export const HomeLandingPage: React.FC<HomeLandingPageProps> = ({
  studentIdentity,
  studentContext,
  onGetIntoJourney,
  onNavigate,
  onOpenProfileModal,
  onOpenTeacherPortal,
}) => {
  const [highlightIndex, setHighlightIndex] = useState(0);
  const [logoError, setLogoError] = useState(false);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setHighlightIndex((prev) => (prev + 1) % ROTATING_HIGHLIGHTS.length);
    }, 3200);
    return () => window.clearInterval(timer);
  }, []);

  const features: FeatureTile[] = [
    {
      id: "syllabus",
      title: "All-India CBSE & NCERT Chapters",
      subtitle:
        "Browse complete chapter libraries for Classes 6–12 across Science, Mathematics, Social Science, Physics, Chemistry, Biology & Computer Science with preloaded summaries.",
      meta: "Classes 6–12 · Instant Access",
      accentGradient: "from-blue-500/18 via-sky-400/10 to-transparent",
      borderTint: "hover:border-blue-300/80",
      iconBg:
        "bg-gradient-to-br from-blue-500 to-blue-700 text-white shadow-blue-500/35",
      iconColor: "text-blue-700",
      icon: <BookOpen className="w-5 h-5" />,
      spanClass: "md:col-span-2",
    },
    {
      id: "loop",
      title: "Study Loop & Concept Maps",
      subtitle:
        "Full lesson summary, key points, visual chapter structure map, formulas, common mistakes & NCERT answers in one clean study view.",
      meta: "Summary · Diagram · Formulas",
      accentGradient: "from-indigo-500/18 via-violet-400/10 to-transparent",
      borderTint: "hover:border-indigo-300/80",
      iconBg:
        "bg-gradient-to-br from-indigo-500 to-violet-700 text-white shadow-indigo-500/35",
      iconColor: "text-indigo-700",
      icon: <Sparkles className="w-5 h-5" />,
    },
    {
      id: "chat",
      title: "Gemini AI Doubt Chat",
      subtitle:
        "Ask follow-up questions on any subtopic or snap a photo of a textbook problem for clear step-by-step explanations.",
      meta: "Text & Image Solver",
      accentGradient: "from-emerald-500/18 via-teal-400/10 to-transparent",
      borderTint: "hover:border-emerald-300/80",
      iconBg:
        "bg-gradient-to-br from-emerald-500 to-teal-700 text-white shadow-emerald-500/35",
      iconColor: "text-emerald-700",
      icon: <MessageSquare className="w-5 h-5" />,
    },
    {
      id: "stage",
      title: "Interactive 3D Lab Stage",
      subtitle:
        "Explore live 3D WebGL labs for Electricity Circuits, Ray Optics, Gravitation Orbits, Atomic Structure, Mitosis & Coordinate Geometry.",
      meta: "6 Live 3D Simulations",
      accentGradient: "from-fuchsia-500/18 via-rose-400/10 to-transparent",
      borderTint: "hover:border-fuchsia-300/80",
      iconBg:
        "bg-gradient-to-br from-fuchsia-500 to-rose-600 text-white shadow-fuchsia-500/35",
      iconColor: "text-fuchsia-700",
      icon: <Box className="w-5 h-5" />,
    },
    ...(studentIdentity?.isKvStudent
      ? [
          {
            id: "tests" as HomeDestination,
            title: "KVS Tests & Question Papers",
            subtitle:
              "Attempt real teacher-assigned assessments with instant scoring and review explanations using your Fixed Student ID.",
            meta: "Online Assessments",
            accentGradient: "from-amber-500/18 via-orange-400/10 to-transparent",
            borderTint: "hover:border-amber-300/80",
            iconBg:
              "bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-amber-500/35",
            iconColor: "text-amber-700",
            icon: <ClipboardCheck className="w-5 h-5" />,
          },
        ]
      : []),
    {
      id: "blackhole",
      title: "Blackhole Exam Survival Mode",
      subtitle:
        "Pure dark high-focus workspace for rapid last-minute chapter sprints, board-level drills, and distraction-free revision.",
      meta: "High-Focus Revision",
      accentGradient: "from-zinc-900/14 via-slate-700/8 to-transparent",
      borderTint: "hover:border-zinc-400/70",
      iconBg:
        "bg-gradient-to-br from-zinc-900 to-slate-800 text-amber-300 shadow-zinc-900/35",
      iconColor: "text-zinc-800",
      icon: <Orbit className="w-5 h-5" />,
      spanClass: "md:col-span-2",
    },
  ];

  return (
    <div className="min-h-screen ios-app-bg text-stone-900 relative overflow-hidden">
      {/* Architectural Grid + Atmospheric Daylight Mesh */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 home-architectural-grid"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none home-mesh-drift absolute -top-28 -left-24 w-[520px] h-[520px] rounded-full bg-gradient-to-br from-blue-400/24 via-sky-300/18 to-transparent blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none home-mesh-drift absolute top-16 -right-24 w-[540px] h-[540px] rounded-full bg-gradient-to-bl from-indigo-400/22 via-violet-300/16 to-transparent blur-3xl"
      />

      {/* Minimal Floating Top Strip (Zero Menu Bar) */}
      <div className="relative z-20 max-w-[1220px] mx-auto px-5 sm:px-8 pt-5 sm:pt-7 flex items-center justify-between gap-4">
        <div className="inline-flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-white/90 border border-white shadow-sm p-0.5 overflow-hidden flex items-center justify-center">
            {!logoError ? (
              <img
                src="/assets/aistudio/image_555f3288.png"
                alt="Tutorix AI"
                referrerPolicy="no-referrer"
                onError={() => setLogoError(true)}
                className="w-full h-full rounded-[10px] object-cover"
              />
            ) : (
              <GraduationCap className="w-5 h-5 text-blue-600" />
            )}
          </div>
          <span className="font-display text-lg sm:text-xl font-semibold tracking-tight text-stone-900">
            Tutorix AI
          </span>
        </div>

        <div className="flex items-center gap-2.5">
          {studentIdentity && (
            <button
              type="button"
              onClick={onOpenProfileModal}
              className="ios-glass-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-indigo-800 border-indigo-200/80 cursor-pointer"
            >
              <IdCard className="w-3.5 h-3.5 text-indigo-600" />
              <span className="hidden sm:inline">{studentIdentity.name}</span>
              <span className="font-mono-tabular font-semibold">
                {studentIdentity.studentId}
              </span>
            </button>
          )}

          <button
            type="button"
            onClick={onOpenTeacherPortal}
            className="ios-glass-btn inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold text-stone-700 hover:text-stone-950 cursor-pointer"
          >
            <UserCircle2 className="w-3.5 h-3.5 text-stone-600" />
            <span>Teacher Portal</span>
          </button>
        </div>
      </div>

      {/* Main Content Container */}
      <main className="relative z-10 max-w-[1220px] mx-auto px-5 sm:px-8 pt-6 sm:pt-10 pb-14">
        {/* Hero Stage Card */}
        <section className="relative rounded-[36px] p-6 sm:p-11 lg:p-14 border border-white/90 bg-white/62 backdrop-blur-2xl shadow-[0_30px_80px_-24px_rgba(30,58,138,0.18),inset_0_1px_0_rgba(255,255,255,0.95)] overflow-hidden">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -right-24 -top-24 w-[420px] h-[420px] rounded-full bg-gradient-to-br from-sky-300/22 via-indigo-300/18 to-transparent blur-2xl"
          />

          <div className="relative grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
            {/* Left Column: Kinetic Headline + Subhead + Animated Journey CTA */}
            <div className="lg:col-span-7 space-y-6">
              <div className="home-stagger-1 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs font-semibold uppercase tracking-[0.16em] text-blue-700">
                <span className="inline-flex items-center gap-1.5">
                  <GraduationCap className="w-4 h-4 text-blue-600" />
                  All-India Study Companion
                </span>
                <span className="text-stone-400">·</span>
                <span className="text-stone-600">Classes 6–12</span>
                <span className="text-stone-400">·</span>
                <span className="text-stone-600">CBSE · ICSE · State Boards</span>
              </div>

              {/* Expressive Masked Kinetic Headline */}
              <h1 className="font-display font-semibold tracking-tight text-stone-900 leading-[1.03] text-[clamp(2.55rem,5.6vw,4.65rem)] text-balance">
                <span className="block">
                  <span className="home-word-clip mr-3">
                    <span className="home-word-reveal-1">Welcome</span>
                  </span>
                  <span className="home-word-clip">
                    <span className="home-word-reveal-2 text-stone-600">to</span>
                  </span>
                </span>
                <span className="block mt-1">
                  <span className="home-word-clip mr-3">
                    <span className="home-word-reveal-3 home-gradient-text">
                      Tutorix
                    </span>
                  </span>
                  <span className="home-word-clip">
                    <span className="home-word-reveal-4 home-gradient-text">
                      AI
                    </span>
                  </span>
                </span>
              </h1>

              {/* Smooth Cycling Spotlight Copy */}
              <div className="home-stagger-2 space-y-2.5">
                <div className="min-h-[2.6rem] sm:min-h-[2rem] flex items-center">
                  <p
                    key={highlightIndex}
                    className="home-ticker-item text-base sm:text-xl text-blue-950 font-semibold leading-snug text-balance"
                  >
                    {ROTATING_HIGHLIGHTS[highlightIndex]}
                  </p>
                </div>
                <p className="text-sm sm:text-base text-stone-600 max-w-xl leading-relaxed">
                  Every lesson opened cleanly with complete chapter summaries,
                  visual concept maps, formulas, Gemini AI doubt solving, live
                  3D labs, and KVS tests — ready the moment you step in.
                </p>
              </div>

              {/* Primary Animated "Get Into Journey" Action */}
              <div className="home-stagger-3 pt-1 flex flex-wrap items-center gap-3.5">
                <div className="relative inline-flex group">
                  <div
                    aria-hidden="true"
                    className="absolute -inset-1 rounded-[22px] bg-gradient-to-r from-blue-500/45 via-indigo-500/45 to-sky-400/45 blur-md opacity-70 group-hover:opacity-100 transition-opacity duration-300"
                  />
                  <button
                    type="button"
                    onClick={onGetIntoJourney}
                    className="home-journey-btn relative inline-flex items-center gap-3 px-8 py-4 min-h-[58px] rounded-[20px] text-white font-semibold text-base sm:text-[17px] tracking-tight cursor-pointer"
                  >
                    <span aria-hidden="true" className="home-journey-sheen" />
                    <Compass className="w-5 h-5 text-sky-200 transition-transform duration-300 group-hover:rotate-45 relative z-10" />
                    <span className="relative z-10">
                      {studentIdentity
                        ? `Continue ${studentContext.studentClass} Journey`
                        : "Get Into Journey"}
                    </span>
                    <ArrowRight className="w-5 h-5 relative z-10 transition-transform duration-200 group-hover:translate-x-1.5" />
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => onNavigate("loop")}
                  className="ios-glass-btn inline-flex items-center gap-2 px-5 py-4 min-h-[58px] rounded-[20px] text-sm font-semibold text-stone-800 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-indigo-600" />
                  <span>Preview Study Loop</span>
                </button>
              </div>
            </div>

            {/* Right Column: Floating Orbital StudySphere AI Medallion */}
            <div className="lg:col-span-5 flex flex-col items-center justify-center py-4 sm:py-6">
              <div className="relative flex items-center justify-center w-[280px] h-[280px] sm:w-[340px] sm:h-[340px]">
                {/* Soft Aura Backdrop */}
                <div
                  aria-hidden="true"
                  className="home-logo-aura absolute inset-6 rounded-full bg-gradient-to-tr from-blue-500/30 via-indigo-500/24 to-sky-300/32 blur-2xl"
                />

                {/* Outer Hairline Orbit Ring */}
                <div
                  aria-hidden="true"
                  className="home-orbit-ring absolute inset-0 rounded-full border border-dashed border-blue-400/35"
                >
                  <span className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 shadow-sm" />
                </div>

                {/* Inner Counter-Rotating Ring */}
                <div
                  aria-hidden="true"
                  className="home-orbit-ring-reverse absolute inset-7 rounded-full border border-indigo-400/25"
                >
                  <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full bg-gradient-to-br from-sky-400 to-blue-600 shadow-sm" />
                </div>

                {/* Central Floating Tutorix AI Brand Medallion */}
                <div className="home-logo-enter relative z-10 w-40 h-40 sm:w-44 sm:h-44 rounded-[36px] p-2.5 bg-white/95 border border-white shadow-[0_28px_56px_-18px_rgba(30,58,138,0.34),inset_0_1px_0_rgba(255,255,255,1)] flex items-center justify-center overflow-hidden">
                  {!logoError ? (
                    <img
                      src="/assets/aistudio/image_555f3288.png"
                      alt="Tutorix AI Official Logo"
                      referrerPolicy="no-referrer"
                      onError={() => setLogoError(true)}
                      className="w-full h-full rounded-[26px] object-cover"
                    />
                  ) : (
                    <div className="w-full h-full rounded-[26px] bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white">
                      <GraduationCap className="w-16 h-16" />
                    </div>
                  )}
                </div>

                {/* 3 Orbiting Interactive Capability Callout Chips */}
                <button
                  type="button"
                  onClick={() => onNavigate("loop")}
                  className="home-chip-float-1 absolute -top-1 sm:top-2 left-0 sm:left-2 z-20 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-white/90 backdrop-blur-xl border border-white shadow-[0_10px_24px_-8px_rgba(15,23,42,0.16)] text-[11px] font-semibold text-indigo-800 hover:scale-105 transition-transform cursor-pointer"
                >
                  <Layers className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Visual Diagrams</span>
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate("chat")}
                  className="home-chip-float-2 absolute top-1/2 -right-2 sm:-right-3 -translate-y-1/2 z-20 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-white/90 backdrop-blur-xl border border-white shadow-[0_10px_24px_-8px_rgba(15,23,42,0.16)] text-[11px] font-semibold text-emerald-800 hover:scale-105 transition-transform cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Gemini AI Chat</span>
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate("stage")}
                  className="home-chip-float-3 absolute bottom-1 sm:bottom-3 left-2 sm:left-4 z-20 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-white/90 backdrop-blur-xl border border-white shadow-[0_10px_24px_-8px_rgba(15,23,42,0.16)] text-[11px] font-semibold text-fuchsia-800 hover:scale-105 transition-transform cursor-pointer"
                >
                  <Box className="w-3.5 h-3.5 text-fuchsia-600" />
                  <span>3D Lab Stage</span>
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Everything Available Showcase */}
        <section className="mt-10 sm:mt-12">
          <div className="home-stagger-3 flex flex-wrap items-baseline justify-between gap-2 mb-5 px-1">
            <div>
              <h2 className="font-display text-2xl sm:text-[1.85rem] font-semibold tracking-tight text-stone-900">
                Everything Available Inside Tutorix AI
              </h2>
              <p className="text-xs sm:text-sm text-stone-600 mt-0.5">
                Tap any workspace below to jump right in
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-5">
            {features.map((item, idx) => (
              <button
                key={item.id}
                type="button"
                onClick={() => onNavigate(item.id)}
                className={`group text-left rounded-[26px] p-6 border border-white/90 bg-white/68 backdrop-blur-xl shadow-[0_12px_32px_-16px_rgba(15,23,42,0.12),inset_0_1px_0_rgba(255,255,255,0.95)] relative overflow-hidden cursor-pointer transition-all duration-200 hover:-translate-y-1.5 hover:shadow-[0_24px_48px_-16px_rgba(30,58,138,0.18)] active:scale-[0.985] ${
                  item.borderTint
                } ${item.spanClass || ""} ${
                  idx < 3 ? "home-stagger-4" : "home-stagger-5"
                }`}
              >
                <div
                  aria-hidden="true"
                  className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${item.accentGradient} opacity-65 group-hover:opacity-100 transition-opacity duration-200`}
                />

                <div className="relative z-10 flex flex-col h-full justify-between gap-5">
                  <div className="flex items-start justify-between gap-3">
                    <div
                      className={`w-11 h-11 rounded-2xl flex items-center justify-center shadow-lg transition-transform duration-200 group-hover:scale-105 ${item.iconBg}`}
                    >
                      {item.icon}
                    </div>
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-stone-500 group-hover:text-stone-950 transition-colors">
                      <span>Launch</span>
                      <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1" />
                    </span>
                  </div>

                  <div>
                    <p
                      className={`text-[11px] font-semibold uppercase tracking-[0.12em] ${item.iconColor} mb-1.5`}
                    >
                      {item.meta}
                    </p>
                    <h3 className="font-display text-lg sm:text-xl font-semibold text-stone-900 leading-snug">
                      {item.title}
                    </h3>
                    <p className="mt-1.5 text-xs sm:text-sm text-stone-600 leading-relaxed">
                      {item.subtitle}
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
};
