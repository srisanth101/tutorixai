import React, { useMemo, useState } from "react";
import {
  BookOpen,
  MessageSquare,
  Play,
  RefreshCw,
  Search,
  Orbit,
  UserCheck,
  Box,
} from "lucide-react";
import { findMatchingSimulation } from "./LessonStage3D";
import {
  STUDENT_CLASSES,
  getSubjectsForClass,
  type StudentClass,
  type SyllabusLesson,
} from "../data/syllabusCatalog";
import type {
  LessonOverview,
  StudentIdentity,
  StudentProfileContext,
} from "../types";

interface CbseSyllabusPageProps {
  studentContext: StudentProfileContext;
  studentIdentity?: StudentIdentity | null;
  onEditStudentProfile?: () => void;
  cachedOverviews?: Record<string, LessonOverview>;
  onChangeStudentClass: (cls: StudentClass) => void;
  onChangeSubject: (subject: string) => void;
  lessons: SyllabusLesson[];
  lessonsSyncing: boolean;
  lessonsSyncedLive: boolean;
  onRefreshLessons: () => void;
  onStartStudyLoopForLesson: (lesson: SyllabusLesson) => void;
  onAskChatForLesson: (lesson: SyllabusLesson) => void;
  onOpenBlackholeForLesson: (lesson: SyllabusLesson) => void;
  onOpen3DForLesson: (lesson: SyllabusLesson) => void;
  onSwitchRole?: () => void;
}

export const CbseSyllabusPage: React.FC<CbseSyllabusPageProps> = ({
  studentContext,
  studentIdentity,
  onEditStudentProfile,
  cachedOverviews = {},
  onChangeStudentClass,
  onChangeSubject,
  lessons,
  lessonsSyncing,
  lessonsSyncedLive,
  onRefreshLessons,
  onStartStudyLoopForLesson,
  onAskChatForLesson,
  onOpenBlackholeForLesson,
  onOpen3DForLesson,
  onSwitchRole,
}) => {
  const [chapterQuery, setChapterQuery] = useState("");
  const subjects = getSubjectsForClass(studentContext.studentClass);

  const filteredLessons = useMemo(() => {
    const q = chapterQuery.trim().toLowerCase();
    if (!q) return lessons;
    return lessons.filter(
      (l) =>
        l.title.toLowerCase().includes(q) ||
        l.chapterNumber.toLowerCase().includes(q) ||
        l.summary.toLowerCase().includes(q) ||
        (l.bookOrUnit || "").toLowerCase().includes(q)
    );
  }, [lessons, chapterQuery]);

  // Group by textbook / bookOrUnit when present (e.g. Social Science History/Geo/PolSci/Econ or Part 1/Part 2)
  const groupedLessons = useMemo(() => {
    const hasGroups = filteredLessons.some((l) => Boolean(l.bookOrUnit));
    if (!hasGroups) {
      return [{ groupName: `${studentContext.subject} Chapters`, items: filteredLessons }];
    }
    const groups = new Map<string, SyllabusLesson[]>();
    for (const lesson of filteredLessons) {
      const key = lesson.bookOrUnit || "Core Chapters";
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(lesson);
    }
    return Array.from(groups.entries()).map(([groupName, items]) => ({
      groupName,
      items,
    }));
  }, [filteredLessons, studentContext.subject]);

  return (
    <div className="page-transition-enter max-w-[1380px] mx-auto px-3.5 sm:px-6 py-5 sm:py-8 space-y-6 sm:space-y-8">
      {/* Header & Class / Subject Selection */}
      <section className="ios-glass-card rounded-3xl p-4 sm:p-6 md:p-8 space-y-5 sm:space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-xs font-medium text-stone-500">
              CBSE (NCERT) Curriculum · Classes 6 to 12 · All India Edition
            </p>
            <h1 className="font-display text-2xl md:text-3xl font-semibold text-stone-900 mt-1 text-balance">
              {studentIdentity
                ? `Welcome, ${studentIdentity.name}`
                : "Complete CBSE Lesson Directory"}
            </h1>
            {studentIdentity && (
              <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs">
                <span className="font-medium text-stone-700">
                  {studentIdentity.board || "CBSE"} ·{" "}
                  {studentIdentity.studentClass}
                </span>
                <span className="font-mono-tabular px-2 py-0.5 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200/80 font-semibold">
                  ID: {studentIdentity.studentId}
                </span>
                {onEditStudentProfile && (
                  <button
                    type="button"
                    onClick={onEditStudentProfile}
                    className="text-blue-700 hover:underline font-medium cursor-pointer"
                  >
                    Edit Profile
                  </button>
                )}
              </div>
            )}
            <p className="mt-1.5 text-sm text-stone-600 max-w-2xl">
              Choose your Class and Subject to view every NCERT chapter with
              auto-loaded summaries, key points, visual diagrams, and AI doubts.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {onSwitchRole && (
              <button
                type="button"
                onClick={onSwitchRole}
                className="ios-glass-btn inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-medium text-stone-800 cursor-pointer whitespace-nowrap"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Teacher Portal</span>
              </button>
            )}

            <button
              type="button"
              onClick={onRefreshLessons}
              disabled={lessonsSyncing}
              className="ios-glass-btn inline-flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-medium text-stone-800 disabled:opacity-50 cursor-pointer whitespace-nowrap"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 ${lessonsSyncing ? "animate-spin" : ""}`}
              />
              <span>
                {lessonsSyncing
                  ? "Checking CBSE Updates..."
                  : lessonsSyncedLive
                  ? "Synced Latest CBSE"
                  : "Sync Latest CBSE"}
              </span>
            </button>
          </div>
        </div>

        {/* Class 6–12 Glassmorphic Buttons */}
        <div className="space-y-3 pt-2 border-t border-slate-200/70">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-stone-600 w-16 shrink-0">
              Class
            </span>
            {STUDENT_CLASSES.map((cls) => (
              <button
                key={cls}
                type="button"
                onClick={() => {
                  onChangeStudentClass(cls);
                  setChapterQuery("");
                }}
                className={`px-3.5 py-1.5 rounded-2xl text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer ${
                  studentContext.studentClass === cls
                    ? "ios-glass-btn-primary"
                    : "ios-glass-btn text-stone-700"
                }`}
              >
                {cls}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-stone-600 w-16 shrink-0">
              Subject
            </span>
            {subjects.map((subj) => (
              <button
                key={subj}
                type="button"
                onClick={() => {
                  onChangeSubject(subj);
                  setChapterQuery("");
                }}
                className={`px-3.5 py-1.5 rounded-2xl text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer ${
                  studentContext.subject === subj
                    ? "ios-glass-btn-blue"
                    : "ios-glass-btn text-stone-700"
                }`}
              >
                {subj}
              </button>
            ))}
          </div>
        </div>

        {/* Filter Bar & Chapter Count */}
        <div className="pt-4 border-t border-slate-200/70 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-stone-600">
            <BookOpen className="w-4 h-4 text-stone-700" />
            <span className="font-semibold text-stone-900">
              {studentContext.studentClass} CBSE · {studentContext.subject}
            </span>
            <span className="text-stone-400" aria-hidden="true">
              ·
            </span>
            <span className="font-mono-tabular">
              {filteredLessons.length} of {lessons.length} chapters
            </span>
          </div>

          <div className="relative w-full sm:w-72">
            <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={chapterQuery}
              onChange={(e) => setChapterQuery(e.target.value)}
              placeholder="Filter chapters by title or topic..."
              className="w-full pl-9 pr-3.5 py-2 rounded-2xl border border-slate-200/80 bg-white/75 text-xs text-stone-900 placeholder:text-stone-400 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>
      </section>

      {/* Complete Chapter Grid Grouped Cleanly */}
      {filteredLessons.length === 0 ? (
        <div className="ios-glass-card rounded-3xl p-10 text-center">
          <p className="font-display text-lg font-medium text-stone-900">
            No matching chapters found
          </p>
          <p className="mt-1.5 text-xs text-stone-500">
            Clear your search filter to see all chapters in{" "}
            {studentContext.studentClass} CBSE {studentContext.subject}.
          </p>
        </div>
      ) : (
        <div className="space-y-8">
          {groupedLessons.map((group) => (
            <section key={group.groupName} className="space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200/80 pb-2">
                <h2 className="font-display text-lg font-semibold text-stone-900">
                  {group.groupName}
                </h2>
                <span className="font-mono-tabular text-xs text-stone-500">
                  {group.items.length} lessons
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4">
                {group.items.map((lesson) => {
                  const isActive = studentContext.lessonTitle === lesson.title;
                  return (
                    <article
                      key={lesson.id}
                      className={`rounded-3xl p-5 flex flex-col justify-between gap-4 transition-all ${
                        isActive
                          ? "bg-stone-900/95 text-white border border-white/15 shadow-xl backdrop-blur-xl"
                          : "ios-glass-card text-stone-900 hover:border-blue-300/70"
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <div
                            className={`text-[11px] font-mono-tabular ${
                              isActive ? "text-stone-300" : "text-stone-500"
                            }`}
                          >
                            {lesson.chapterNumber}
                            {lesson.bookOrUnit ? ` · ${lesson.bookOrUnit}` : ""}
                          </div>
                          {cachedOverviews[lesson.title] && (
                            <span
                              className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                                isActive
                                  ? "bg-emerald-500/20 text-emerald-300 border border-emerald-400/30"
                                  : "bg-emerald-50 text-emerald-700 border border-emerald-200/80"
                              }`}
                            >
                              Full Notes Ready
                            </span>
                          )}
                        </div>
                        <h3 className="text-sm font-semibold leading-snug">
                          {lesson.title}
                        </h3>
                        <p
                          className={`mt-1.5 text-xs leading-relaxed line-clamp-3 ${
                            isActive ? "text-stone-300" : "text-stone-600"
                          }`}
                        >
                          {cachedOverviews[lesson.title]?.fullSummary ||
                            lesson.summary}
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-200/40">
                        <button
                          type="button"
                          onClick={() => onStartStudyLoopForLesson(lesson)}
                          className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-medium cursor-pointer whitespace-nowrap ${
                            isActive
                              ? "bg-white text-stone-900 hover:bg-stone-100"
                              : "ios-glass-btn-primary"
                          }`}
                        >
                          <Play className="w-3 h-3 fill-current" />
                          <span>Study Loop</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onAskChatForLesson(lesson)}
                          className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-medium cursor-pointer whitespace-nowrap ${
                            isActive
                              ? "border border-stone-700 text-stone-200 hover:bg-stone-800"
                              : "ios-glass-btn text-stone-800"
                          }`}
                        >
                          <MessageSquare className="w-3 h-3" />
                          <span>AI Chat</span>
                        </button>

                        {Boolean(
                          findMatchingSimulation({
                            subject: studentContext.subject,
                            lessonTitle: lesson.title,
                          })
                        ) && (
                          <button
                            type="button"
                            onClick={() => onOpen3DForLesson(lesson)}
                            title="Launch interactive 3D Lesson Simulation"
                            className={`inline-flex items-center gap-1 px-2.5 py-2 rounded-2xl text-xs font-medium cursor-pointer whitespace-nowrap ${
                              isActive
                                ? "border border-stone-700 text-blue-300 hover:bg-stone-800"
                                : "ios-glass-btn-blue"
                            }`}
                          >
                            <Box className="w-3 h-3" />
                            <span>3D Stage</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => onOpenBlackholeForLesson(lesson)}
                          title="Open in Blackhole Pure Dark Mode"
                          className={`inline-flex items-center gap-1 px-2.5 py-2 rounded-2xl text-xs font-medium cursor-pointer whitespace-nowrap ${
                            isActive
                              ? "bg-black text-amber-300 border border-white/20 hover:bg-zinc-900"
                              : "bg-black text-white hover:bg-zinc-900 transition-colors"
                          }`}
                        >
                          <Orbit className="w-3 h-3 text-amber-300" />
                          <span>Blackhole</span>
                        </button>
                      </div>
                    </article>
                  );
                })}
              </div>
            </section>
          ))}
        </div>
      )}
    </div>
  );
};
