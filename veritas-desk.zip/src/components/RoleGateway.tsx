import React, { useState } from "react";
import {
  GraduationCap,
  ShieldCheck,
  ArrowRight,
  Lock,
  Loader2,
  ArrowLeft,
} from "lucide-react";
import { safeJsonResponse } from "../utils/freeLocalChat";
import type { TeacherSession } from "../types";

interface RoleGatewayProps {
  onSelectStudent: () => void;
  onTeacherAuthenticated: (session: TeacherSession) => void;
  defaultMode?: "choose" | "teacher";
  onCancel?: () => void;
}

const AUTHORIZED_KVS_TEACHERS = ["T.Sreenivas Rao"];

export const RoleGateway: React.FC<RoleGatewayProps> = ({
  onSelectStudent,
  onTeacherAuthenticated,
  defaultMode = "choose",
  onCancel,
}) => {
  const [step, setStep] = useState<"choose" | "teacher_login">(
    defaultMode === "teacher" ? "teacher_login" : "choose"
  );
  const [teacherName, setTeacherName] = useState(AUTHORIZED_KVS_TEACHERS[0]);
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleTeacherLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim() || loading) return;

    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/teacher/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          teacherName,
          password: password.trim(),
        }),
      });
      const data = await safeJsonResponse<{
        token?: string;
        teacherName?: string;
        error?: string;
      }>(res);
      if (!res.ok || !data?.token || !data?.teacherName) {
        throw new Error(
          data?.error ||
            "Teacher portal authentication requires backend server mode."
        );
      }
      onTeacherAuthenticated({
        token: data.token,
        teacherName: data.teacherName,
        organization: "KVS",
      });
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Could not verify password."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="ios-app-bg min-h-screen flex items-center justify-center px-6 py-12">
      <div className="page-transition-enter max-w-4xl w-full space-y-8">
        {/* Tutorix AI Brand Lockup */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center justify-center gap-3">
            <img
              src="/assets/aistudio/image_555f3288.png"
              alt="Tutorix AI logo"
              referrerPolicy="no-referrer"
              className="w-12 h-12 rounded-2xl shadow-md object-cover"
            />
            <span className="font-display text-3xl font-semibold tracking-tight text-stone-900">
              Tutorix AI
            </span>
          </div>
          <p className="text-xs font-medium text-stone-500">
            CBSE (NCERT) Classes 6 to 12 · Learning Suite & KVS Faculty Portal
          </p>
        </div>

        {step === "choose" ? (
          <div className="ios-glass-card rounded-3xl p-8 md:p-10 space-y-7">
            <div className="text-center max-w-lg mx-auto">
              <h1 className="font-display text-2xl md:text-3xl font-semibold text-stone-900 text-balance">
                Who are you?
              </h1>
              <p className="mt-2 text-sm text-stone-600 leading-relaxed">
                Students can jump straight in with zero login. KVS teachers can
                sign in with their faculty password to create student tests and
                official CBSE question papers.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Student Card — Instant Zero-Login Access */}
              <button
                type="button"
                onClick={onSelectStudent}
                className="ios-glass-btn text-left rounded-3xl p-6 md:p-7 flex flex-col justify-between gap-6 cursor-pointer group"
              >
                <div className="space-y-3">
                  <div className="w-11 h-11 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-md">
                    <GraduationCap className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="font-display text-xl font-semibold text-stone-900">
                      I am a Student
                    </h2>
                    <p className="text-xs font-medium text-blue-700 mt-0.5">
                      Open Access · No Password Needed
                    </p>
                  </div>
                  <p className="text-xs text-stone-600 leading-relaxed">
                    Browse all CBSE NCERT Classes 6–12 lessons, launch Study
                    Loop, ask doubts in AI Chat, take KVS tests, or enter
                    Blackhole mode.
                  </p>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-200/70 text-xs font-semibold text-stone-900">
                  <span>Enter Student Workspace</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </div>
              </button>

              {/* KVS Teacher Card — Password Protected */}
              <button
                type="button"
                onClick={() => {
                  setStep("teacher_login");
                  setError(null);
                }}
                className="ios-glass-btn text-left rounded-3xl p-6 md:p-7 flex flex-col justify-between gap-6 cursor-pointer group"
              >
                <div className="space-y-3">
                  <div className="w-11 h-11 rounded-2xl bg-stone-900 text-white flex items-center justify-center shadow-md">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="font-display text-xl font-semibold text-stone-900">
                      I am a Teacher (KVS)
                    </h2>
                    <p className="text-xs font-medium text-stone-500 mt-0.5">
                      KVS Faculty · Password Protected
                    </p>
                  </div>
                  <p className="text-xs text-stone-600 leading-relaxed">
                    Build and publish interactive tests for students, generate
                    official CBSE Question Papers & Marking Schemes, and use all
                    Tutorix AI tools.
                  </p>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-200/70 text-xs font-semibold text-stone-900">
                  <span>KVS Teacher Login</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </div>
              </button>
            </div>

            {onCancel && (
              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={onCancel}
                  className="text-xs font-medium text-stone-500 hover:text-stone-900 underline cursor-pointer"
                >
                  Return to current workspace
                </button>
              </div>
            )}
          </div>
        ) : (
          <form
            onSubmit={handleTeacherLogin}
            className="ios-glass-card max-w-md mx-auto rounded-3xl p-7 md:p-8 space-y-5"
          >
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  if (onCancel && defaultMode === "teacher") {
                    onCancel();
                  } else {
                    setStep("choose");
                  }
                  setError(null);
                }}
                className="ios-glass-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-stone-700 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
              <span className="text-xs font-medium text-stone-500">
                KVS Faculty Portal
              </span>
            </div>

            <div>
              <h1 className="font-display text-2xl font-semibold text-stone-900">
                KVS Teacher Sign In
              </h1>
              <p className="mt-1 text-xs text-stone-600">
                Select authorized KVS faculty member and enter your portal
                password.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label
                  htmlFor="kvs-teacher-select"
                  className="block text-xs font-semibold text-stone-700 mb-1.5"
                >
                  KVS Faculty Name
                </label>
                <select
                  id="kvs-teacher-select"
                  value={teacherName}
                  onChange={(e) => setTeacherName(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/85 px-3.5 py-2.5 text-sm font-medium text-stone-900 focus:outline-none focus:border-blue-500"
                >
                  {AUTHORIZED_KVS_TEACHERS.map((name) => (
                    <option key={name} value={name}>
                      {name} (KVS)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="kvs-teacher-password"
                  className="block text-xs font-semibold text-stone-700 mb-1.5"
                >
                  Teacher Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    id="kvs-teacher-password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter KVS teacher password"
                    autoFocus
                    className="w-full pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200/80 bg-white/85 text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            {error && (
              <div className="rounded-2xl border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs text-red-800">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading || !password.trim()}
              className="ios-glass-btn-primary w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl text-sm font-semibold disabled:opacity-45 cursor-pointer"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying KVS Portal...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Enter Teacher Portal</span>
                </>
              )}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
