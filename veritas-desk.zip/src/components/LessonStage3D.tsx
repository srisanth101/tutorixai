import React, { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import {
  ArrowLeft,
  ChevronDown,
  ChevronUp,
  Expand,
  Moon,
  Pause,
  Play,
  RotateCcw,
  Sun,
} from "lucide-react";
import type { StudentProfileContext } from "../types";

export type LessonSimId =
  | "electricity"
  | "optics"
  | "atom"
  | "solar"
  | "cell"
  | "geometry";

export type StudioTheme = "observatory" | "daylight";

interface LessonStage3DProps {
  studentContext: StudentProfileContext;
  topic?: string;
  fullStage: boolean;
  onExpandStage?: () => void;
  onExitStage?: () => void;
}

interface SimMeta {
  id: LessonSimId;
  title: string;
  shortLabel: string;
  param1Label: string;
  param1Min: number;
  param1Max: number;
  param1Step: number;
  param1Default: number;
  param1Unit: string;
  param2Label: string;
  param2Min: number;
  param2Max: number;
  param2Step: number;
  param2Default: number;
  param2Unit: string;
}

const SIM_CATALOG: Record<LessonSimId, SimMeta> = {
  electricity: {
    id: "electricity",
    title: "Electric Circuit & Ohm's Law Lab",
    shortLabel: "Circuit & Ohm's Law",
    param1Label: "Voltage (V)",
    param1Min: 1,
    param1Max: 12,
    param1Step: 0.5,
    param1Default: 6,
    param1Unit: "V",
    param2Label: "Resistance (R)",
    param2Min: 1,
    param2Max: 12,
    param2Step: 0.5,
    param2Default: 3,
    param2Unit: "Ω",
  },
  optics: {
    id: "optics",
    title: "Convex Lens & Ray Refraction Bench",
    shortLabel: "Optics & Lenses",
    param1Label: "Object Distance (u)",
    param1Min: 1.6,
    param1Max: 4.5,
    param1Step: 0.1,
    param1Default: 2.8,
    param1Unit: "m",
    param2Label: "Focal Length (f)",
    param2Min: 0.8,
    param2Max: 1.6,
    param2Step: 0.05,
    param2Default: 1.15,
    param2Unit: "m",
  },
  atom: {
    id: "atom",
    title: "Bohr Atomic Structure & Shells",
    shortLabel: "Atom & Shells",
    param1Label: "Atomic No. (Z)",
    param1Min: 1,
    param1Max: 18,
    param1Step: 1,
    param1Default: 6,
    param1Unit: "",
    param2Label: "Orbit Speed",
    param2Min: 0.2,
    param2Max: 2.5,
    param2Step: 0.1,
    param2Default: 1.0,
    param2Unit: "x",
  },
  solar: {
    id: "solar",
    title: "Solar System, Gravitation & Earth Tilt",
    shortLabel: "Solar & Earth Tilt",
    param1Label: "Orbit Speed",
    param1Min: 0.2,
    param1Max: 3.0,
    param1Step: 0.1,
    param1Default: 1.0,
    param1Unit: "x",
    param2Label: "Earth Tilt",
    param2Min: 0,
    param2Max: 35,
    param2Step: 0.5,
    param2Default: 23.5,
    param2Unit: "°",
  },
  cell: {
    id: "cell",
    title: "3D Living Cell & Organelle Explorer",
    shortLabel: "Cell & Bio Lab",
    param1Label: "ATP / Activity",
    param1Min: 0.2,
    param1Max: 2.5,
    param1Step: 0.1,
    param1Default: 1.0,
    param1Unit: "x",
    param2Label: "Cutaway Open",
    param2Min: 0,
    param2Max: 1,
    param2Step: 0.05,
    param2Default: 0.6,
    param2Unit: "",
  },
  geometry: {
    id: "geometry",
    title: "3D Mensuration Solids & Trigonometry",
    shortLabel: "3D Math Solids",
    param1Label: "Radius (r)",
    param1Min: 0.5,
    param1Max: 1.6,
    param1Step: 0.05,
    param1Default: 1.0,
    param1Unit: "u",
    param2Label: "Height (h)",
    param2Min: 0.8,
    param2Max: 2.8,
    param2Step: 0.05,
    param2Default: 1.8,
    param2Unit: "u",
  },
};

const ELEMENTS_1_18 = [
  "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
  "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar",
];

export function findMatchingSimulation(
  ctx: Pick<StudentProfileContext, "subject" | "lessonTitle">,
  topic = ""
): LessonSimId | null {
  const hay = (
    ctx.lessonTitle
      ? `${ctx.lessonTitle} ${topic}`
      : `${ctx.subject} ${topic}`
  ).toLowerCase();

  if (
    /\b(electric|electricity|circuit|ohm|current|resistor|voltage|potential difference|magnetic effect)\b/i.test(
      hay
    )
  ) {
    return "electricity";
  }
  if (
    /\b(optic|optics|light|reflection|refraction|lens|lenses|mirror|mirrors|human eye|colourful world|prism)\b/i.test(
      hay
    )
  ) {
    return "optics";
  }
  if (
    /\b(atom|atoms|molecule|molecules|structure of the atom|periodic|electronic configuration|valency|bohr|isotope)\b/i.test(
      hay
    )
  ) {
    return "atom";
  }
  if (
    /\b(solar system|solar|planet|planets|gravitation|motions of the earth|earth in the solar|orbit|astronomy)\b/i.test(
      hay
    )
  ) {
    return "solar";
  }
  if (
    /\b(cell|cells|fundamental unit of life|organelle|mitochondria|chloroplast|photosynthesis|tissues|life processes|heredity|reproduction|microorganism)\b/i.test(
      hay
    )
  ) {
    return "cell";
  }
  if (
    /\b(mensuration|surface area|surface areas and volumes|volume|volumes|cone|cylinder|sphere|solid shapes|visualising solid)\b/i.test(
      hay
    )
  ) {
    return "geometry";
  }
  return null;
}

export function matchLessonToSimulation(
  ctx: StudentProfileContext,
  topic = ""
): LessonSimId {
  return findMatchingSimulation(ctx, topic) ?? "electricity";
}

function createFloorGridTexture(isDaylight: boolean): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = isDaylight ? "#eae7df" : "#0b0f17";
  ctx.fillRect(0, 0, 512, 512);
  ctx.strokeStyle = isDaylight
    ? "rgba(24, 24, 27, 0.08)"
    : "rgba(148, 163, 184, 0.09)";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 512; i += 64) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, 512);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(512, i);
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(16, 16);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createEarthTexture(): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "#1d4ed8";
  ctx.fillRect(0, 0, 512, 256);
  ctx.fillStyle = "#16a34a";
  // Stylized continents
  ctx.beginPath();
  ctx.ellipse(140, 110, 48, 34, 0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(310, 95, 68, 42, -0.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(370, 165, 36, 26, 0.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#f8fafc";
  ctx.fillRect(0, 0, 512, 16);
  ctx.fillRect(0, 240, 512, 16);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export const LessonStage3D: React.FC<LessonStage3DProps> = ({
  studentContext,
  topic = "",
  fullStage,
  onExpandStage,
  onExitStage,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const exactMatchSim = useMemo(
    () => findMatchingSimulation(studentContext, topic),
    [studentContext.subject, studentContext.lessonTitle, topic]
  );
  const matchedSim = exactMatchSim ?? "electricity";

  const [activeSim, setActiveSim] = useState<LessonSimId>(matchedSim);
  const [param1, setParam1] = useState<number>(
    SIM_CATALOG[matchedSim].param1Default
  );
  const [param2, setParam2] = useState<number>(
    SIM_CATALOG[matchedSim].param2Default
  );
  const [paused, setPaused] = useState(false);
  const [studioTheme, setStudioTheme] = useState<StudioTheme>("observatory");
  const [dockCollapsed, setDockCollapsed] = useState(false);
  const [webglError, setWebglError] = useState(false);
  const [resetTrigger, setResetTrigger] = useState(0);

  // Automatically switch 3D simulation when the student selects a different lesson
  useEffect(() => {
    setActiveSim(matchedSim);
    setParam1(SIM_CATALOG[matchedSim].param1Default);
    setParam2(SIM_CATALOG[matchedSim].param2Default);
  }, [matchedSim]);

  const selectSimManually = (simId: LessonSimId) => {
    setActiveSim(simId);
    setParam1(SIM_CATALOG[simId].param1Default);
    setParam2(SIM_CATALOG[simId].param2Default);
  };

  const stateRef = useRef({
    activeSim,
    param1,
    param2,
    paused,
    studioTheme,
    resetTrigger,
  });
  stateRef.current = {
    activeSim,
    param1,
    param2,
    paused,
    studioTheme,
    resetTrigger,
  };

  // Keyboard shortcut 'H' to toggle dock in fullStage
  useEffect(() => {
    if (!fullStage) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.key.toLowerCase() === "h" &&
        !(e.target instanceof HTMLInputElement) &&
        !(e.target instanceof HTMLTextAreaElement)
      ) {
        setDockCollapsed((prev) => !prev);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [fullStage]);

  useEffect(() => {
    const mount = containerRef.current;
    if (!mount) return;

    const isSoftwareGl = (() => {
      try {
        const probeCanvas = document.createElement("canvas");
        const gl = probeCanvas.getContext("webgl2");
        if (!gl) return true;
        const ext = gl.getExtension("WEBGL_debug_renderer_info");
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension("WEBGL_lose_context")?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: "high-performance",
      });
    } catch {
      setWebglError(true);
      return;
    }

    const width = mount.clientWidth || window.innerWidth;
    const height = mount.clientHeight || 420;
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    mount.innerHTML = "";
    mount.appendChild(renderer.domElement);

    const onContextLost = (e: Event) => e.preventDefault();
    renderer.domElement.addEventListener("webglcontextlost", onContextLost);

    const scene = new THREE.Scene();
    const darkBg = new THREE.Color(0x0b0f17);
    const lightBg = new THREE.Color(0xeae7df);
    scene.background = darkBg.clone();
    scene.fog = new THREE.FogExp2(0x0b0f17, 0.025);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnvTex = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = roomEnvTex;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(44, width / height, 0.1, 100);
    camera.position.set(5.4, 4.2, 6.4);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 1.1, 0);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.06;
    controls.minDistance = 2.8;
    controls.maxDistance = 16;
    controls.maxPolarAngle = Math.PI / 2 - 0.05;
    controls.update();

    // 3-Point Studio Lighting
    const keyLight = new THREE.DirectionalLight(0xfff4e0, 2.1);
    keyLight.position.set(6, 9, 5);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.left = -7;
    keyLight.shadow.camera.right = 7;
    keyLight.shadow.camera.top = 7;
    keyLight.shadow.camera.bottom = -7;
    keyLight.shadow.bias = -0.0005;
    scene.add(keyLight);

    scene.add(new THREE.HemisphereLight(0xdbeafe, 0x1e293b, 0.9));
    const rimLight = new THREE.DirectionalLight(0x93c5fd, 0.85);
    rimLight.position.set(-5, 4, -5);
    scene.add(rimLight);

    const darkGridTex = createFloorGridTexture(false);
    const lightGridTex = createFloorGridTexture(true);
    const earthTex = createEarthTexture();

    const floorMat = new THREE.MeshStandardMaterial({
      map: darkGridTex,
      roughness: 0.88,
      metalness: 0.06,
    });
    const floor = new THREE.Mesh(new THREE.CircleGeometry(30, 64), floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    // Shared calibrated materials
    const slateMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.72,
      metalness: 0.14,
    });
    const copperMat = new THREE.MeshPhysicalMaterial({
      color: 0xd97706,
      roughness: 0.22,
      metalness: 0.92,
    });
    const brassMat = new THREE.MeshPhysicalMaterial({
      color: 0xeab308,
      roughness: 0.2,
      metalness: 0.9,
    });
    const ceramicMat = new THREE.MeshStandardMaterial({
      color: 0xf1f5f9,
      roughness: 0.55,
      metalness: 0.08,
    });
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0xe0f2fe,
      roughness: 0.06,
      metalness: 0,
      transmission: isSoftwareGl ? 0 : 0.82,
      transparent: true,
      opacity: isSoftwareGl ? 0.38 : 1,
      ior: 1.52,
      thickness: 0.8,
      depthWrite: false,
    });

    // =========================================================================
    // 1. ELECTRICITY & OHM'S LAW CIRCUIT GROUP
    // =========================================================================
    const elecGroup = new THREE.Group();
    scene.add(elecGroup);

    const board = new THREE.Mesh(new THREE.BoxGeometry(5.8, 0.24, 3.8), slateMat);
    board.position.y = 0.12;
    board.receiveShadow = true;
    board.castShadow = true;
    elecGroup.add(board);

    // Battery pack (Composite 4-part group)
    const batteryBody = new THREE.Mesh(
      new THREE.BoxGeometry(1.1, 0.85, 0.7),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.6, metalness: 0.2 })
    );
    batteryBody.position.set(-2.0, 0.66, 0);
    batteryBody.castShadow = true;
    elecGroup.add(batteryBody);
    const batteryCap = new THREE.Mesh(
      new THREE.BoxGeometry(1.12, 0.16, 0.72),
      new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.45, metalness: 0.15 })
    );
    batteryCap.position.set(-2.0, 1.08, 0);
    elecGroup.add(batteryCap);
    for (const tz of [-0.18, 0.18]) {
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.18, 16), brassMat);
      post.position.set(-2.0, 1.24, tz);
      elecGroup.add(post);
    }

    // Circuit loop path for copper wire + animated electrons
    const wirePoints = [
      new THREE.Vector3(-2.0, 0.4, 1.25),
      new THREE.Vector3(2.0, 0.4, 1.25),
      new THREE.Vector3(2.0, 0.4, -1.25),
      new THREE.Vector3(-2.0, 0.4, -1.25),
    ];
    const circuitCurve = new THREE.CatmullRomCurve3(wirePoints, true, "catmullrom", 0.18);
    const wireMesh = new THREE.Mesh(
      new THREE.TubeGeometry(circuitCurve, 80, 0.05, 12, true),
      copperMat
    );
    wireMesh.castShadow = true;
    elecGroup.add(wireMesh);

    // Resistor cylinder + colored bands
    const resistorBody = new THREE.Mesh(
      new THREE.CylinderGeometry(0.22, 0.22, 1.1, 20),
      ceramicMat
    );
    resistorBody.rotation.z = Math.PI / 2;
    resistorBody.position.set(0, 0.44, 1.25);
    resistorBody.castShadow = true;
    elecGroup.add(resistorBody);
    [0xef4444, 0x3b82f6, 0xeab308].forEach((hex, idx) => {
      const band = new THREE.Mesh(
        new THREE.CylinderGeometry(0.23, 0.23, 0.09, 20),
        new THREE.MeshStandardMaterial({ color: hex, roughness: 0.4 })
      );
      band.rotation.z = Math.PI / 2;
      band.position.set(-0.28 + idx * 0.25, 0.44, 1.25);
      elecGroup.add(band);
    });

    // Bulb assembly (Socket + Filament + Glass Dome + PointLight)
    const bulbSocket = new THREE.Mesh(
      new THREE.CylinderGeometry(0.32, 0.36, 0.32, 24),
      brassMat
    );
    bulbSocket.position.set(2.0, 0.4, 0);
    bulbSocket.castShadow = true;
    elecGroup.add(bulbSocket);
    const filamentMat = new THREE.MeshStandardMaterial({
      color: 0xfef08a,
      emissive: 0xf59e0b,
      emissiveIntensity: 1.5,
      roughness: 0.2,
    });
    const filament = new THREE.Mesh(
      new THREE.TorusGeometry(0.14, 0.03, 10, 24, Math.PI * 1.4),
      filamentMat
    );
    filament.position.set(2.0, 0.85, 0);
    elecGroup.add(filament);
    const bulbDome = new THREE.Mesh(new THREE.SphereGeometry(0.45, 24, 24), glassMat);
    bulbDome.position.set(2.0, 0.92, 0);
    elecGroup.add(bulbDome);
    const bulbLight = new THREE.PointLight(0xfde047, 2.5, 7);
    bulbLight.position.set(2.0, 1.0, 0);
    elecGroup.add(bulbLight);

    // Ammeter dial + rotating needle
    const ammeterBase = new THREE.Mesh(
      new THREE.CylinderGeometry(0.55, 0.6, 0.2, 32),
      ceramicMat
    );
    ammeterBase.position.set(0, 0.34, -1.25);
    elecGroup.add(ammeterBase);
    const ammeterNeedleGroup = new THREE.Group();
    ammeterNeedleGroup.position.set(0, 0.46, -1.25);
    const needle = new THREE.Mesh(
      new THREE.BoxGeometry(0.04, 0.03, 0.42),
      new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.3 })
    );
    needle.position.z = -0.15;
    ammeterNeedleGroup.add(needle);
    elecGroup.add(ammeterNeedleGroup);

    // Flowing electrons (16 spheres)
    const ELECTRON_COUNT = 16;
    const electrons: THREE.Mesh[] = [];
    const eMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 1.4,
      roughness: 0.2,
    });
    const eGeo = new THREE.SphereGeometry(0.085, 12, 12);
    for (let i = 0; i < ELECTRON_COUNT; i++) {
      const m = new THREE.Mesh(eGeo, eMat);
      elecGroup.add(m);
      electrons.push(m);
    }

    // =========================================================================
    // 2. OPTICS & CONVEX LENS RAY REFRACTION GROUP
    // =========================================================================
    const opticsGroup = new THREE.Group();
    scene.add(opticsGroup);

    const rail = new THREE.Mesh(new THREE.BoxGeometry(7.2, 0.22, 0.7), slateMat);
    rail.position.y = 0.11;
    rail.receiveShadow = true;
    opticsGroup.add(rail);

    // Biconvex Lens via LatheGeometry
    const lensPts: THREE.Vector2[] = [];
    for (let i = 0; i <= 16; i++) {
      const t = (i / 16) * Math.PI - Math.PI / 2;
      const r = Math.cos(t) * 0.9;
      const y = Math.sin(t) * 0.22;
      lensPts.push(new THREE.Vector2(r, y));
    }
    const lensMesh = new THREE.Mesh(new THREE.LatheGeometry(lensPts, 32), glassMat);
    lensMesh.rotation.z = Math.PI / 2;
    lensMesh.position.set(0, 1.35, 0);
    opticsGroup.add(lensMesh);
    const lensStand = new THREE.Mesh(
      new THREE.CylinderGeometry(0.08, 0.16, 1.15, 16),
      brassMat
    );
    lensStand.position.set(0, 0.68, 0);
    opticsGroup.add(lensStand);

    // Focal markers F1, F2
    const fMarker1 = new THREE.Mesh(
      new THREE.CylinderGeometry(0.04, 0.04, 0.25, 12),
      new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0xb45309, emissiveIntensity: 0.7 })
    );
    const fMarker2 = fMarker1.clone();
    fMarker1.position.set(-1.15, 0.28, 0);
    fMarker2.position.set(1.15, 0.28, 0);
    opticsGroup.add(fMarker1, fMarker2);

    // Glowing Object Arrow Stand
    const objArrowGroup = new THREE.Group();
    const objStem = new THREE.Mesh(
      new THREE.CylinderGeometry(0.045, 0.045, 0.85, 14),
      new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0284c7, emissiveIntensity: 0.9 })
    );
    objStem.position.y = 0.65;
    const objTip = new THREE.Mesh(
      new THREE.ConeGeometry(0.11, 0.24, 16),
      new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x38bdf8, emissiveIntensity: 1.2 })
    );
    objTip.position.y = 1.18;
    objArrowGroup.add(objStem, objTip);
    opticsGroup.add(objArrowGroup);

    // Projection Screen & Inverted Image Arrow
    const screenGroup = new THREE.Group();
    const screenPanel = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 1.9, 1.4),
      ceramicMat
    );
    screenPanel.position.y = 1.2;
    screenGroup.add(screenPanel);
    const imgArrow = new THREE.Mesh(
      new THREE.ConeGeometry(0.1, 0.24, 16),
      new THREE.MeshStandardMaterial({ color: 0xf97316, emissive: 0xea580c, emissiveIntensity: 1.1 })
    );
    imgArrow.rotation.z = Math.PI;
    imgArrow.position.set(-0.07, 0.8, 0);
    screenGroup.add(imgArrow);
    opticsGroup.add(screenGroup);

    // Dynamic ray lines
    const rayMat = new THREE.LineBasicMaterial({ color: 0xfde047 });
    const rayGeo1 = new THREE.BufferGeometry();
    const rayGeo2 = new THREE.BufferGeometry();
    const rayLine1 = new THREE.Line(rayGeo1, rayMat);
    const rayLine2 = new THREE.Line(rayGeo2, rayMat);
    opticsGroup.add(rayLine1, rayLine2);

    // =========================================================================
    // 3. BOHR ATOMIC STRUCTURE GROUP
    // =========================================================================
    const atomGroup = new THREE.Group();
    scene.add(atomGroup);

    const nucleusGroup = new THREE.Group();
    nucleusGroup.position.y = 2.0;
    atomGroup.add(nucleusGroup);

    const protonMat = new THREE.MeshStandardMaterial({
      color: 0xef4444,
      emissive: 0x991b1b,
      emissiveIntensity: 0.7,
      roughness: 0.3,
    });
    const neutronMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.45,
      metalness: 0.4,
    });
    const nucleonGeo = new THREE.SphereGeometry(0.14, 14, 14);
    const nucleons: THREE.Mesh[] = [];
    for (let i = 0; i < 36; i++) {
      const m = new THREE.Mesh(nucleonGeo, i % 2 === 0 ? protonMat : neutronMat);
      const phi = Math.acos(1 - (2 * (i + 0.5)) / 36);
      const theta = Math.PI * (1 + Math.sqrt(5)) * i;
      const r = 0.22 + (i % 3) * 0.08;
      m.position.set(
        r * Math.sin(phi) * Math.cos(theta),
        r * Math.sin(phi) * Math.sin(theta),
        r * Math.cos(phi)
      );
      nucleusGroup.add(m);
      nucleons.push(m);
    }

    const shellRadii = [1.2, 2.0, 2.8];
    const shellTilts = [
      new THREE.Euler(0.35, 0, 0.2),
      new THREE.Euler(-0.4, 0.3, -0.25),
      new THREE.Euler(0.15, -0.35, 0.45),
    ];
    const shellGroups: THREE.Group[] = [];
    const atomElectrons: { mesh: THREE.Mesh; shellIdx: number; angle: number }[] = [];

    for (let s = 0; s < 3; s++) {
      const sg = new THREE.Group();
      sg.position.y = 2.0;
      sg.rotation.copy(shellTilts[s]);
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(shellRadii[s], 0.022, 12, 72),
        new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.45 })
      );
      ring.rotation.x = Math.PI / 2;
      sg.add(ring);
      atomGroup.add(sg);
      shellGroups.push(sg);
    }
    const maxCap = [2, 8, 8];
    for (let s = 0; s < 3; s++) {
      for (let e = 0; e < maxCap[s]; e++) {
        const em = new THREE.Mesh(
          new THREE.SphereGeometry(0.1, 14, 14),
          new THREE.MeshStandardMaterial({
            color: 0x38bdf8,
            emissive: 0x0ea5e9,
            emissiveIntensity: 1.5,
            roughness: 0.15,
          })
        );
        shellGroups[s].add(em);
        atomElectrons.push({ mesh: em, shellIdx: s, angle: (e / maxCap[s]) * Math.PI * 2 });
      }
    }

    // =========================================================================
    // 4. SOLAR SYSTEM & EARTH TILT GROUP
    // =========================================================================
    const solarGroup = new THREE.Group();
    scene.add(solarGroup);

    const sun = new THREE.Mesh(
      new THREE.SphereGeometry(0.75, 28, 28),
      new THREE.MeshStandardMaterial({
        color: 0xfbbf24,
        emissive: 0xf59e0b,
        emissiveIntensity: 2.0,
        roughness: 0.3,
      })
    );
    sun.position.y = 1.6;
    solarGroup.add(sun);
    const sunLight = new THREE.PointLight(0xfef08a, 3.2, 14);
    sunLight.position.set(0, 1.6, 0);
    solarGroup.add(sunLight);

    const planetDefs = [
      { r: 1.25, size: 0.12, color: 0x9ca3af, speed: 2.4 },
      { r: 1.75, size: 0.18, color: 0xfdba74, speed: 1.7 },
      { r: 2.35, size: 0.24, color: 0x3b82f6, speed: 1.2, isEarth: true },
      { r: 2.95, size: 0.16, color: 0xef4444, speed: 0.9 },
      { r: 3.7, size: 0.32, color: 0xfde68a, speed: 0.55, hasRings: true },
    ];
    const planetObjects: {
      pivot: THREE.Group;
      body: THREE.Mesh;
      speed: number;
      isEarth?: boolean;
      moonPivot?: THREE.Group;
    }[] = [];

    planetDefs.forEach((pd) => {
      const track = new THREE.Mesh(
        new THREE.TorusGeometry(pd.r, 0.012, 8, 84),
        new THREE.MeshBasicMaterial({ color: 0x64748b, transparent: true, opacity: 0.35 })
      );
      track.rotation.x = Math.PI / 2;
      track.position.y = 1.6;
      solarGroup.add(track);

      const pivot = new THREE.Group();
      pivot.position.y = 1.6;
      solarGroup.add(pivot);

      const bodyMat = pd.isEarth
        ? new THREE.MeshStandardMaterial({ map: earthTex, roughness: 0.65 })
        : new THREE.MeshStandardMaterial({ color: pd.color, roughness: 0.55 });
      const body = new THREE.Mesh(new THREE.SphereGeometry(pd.size, 20, 20), bodyMat);
      body.position.x = pd.r;
      pivot.add(body);

      let moonPivot: THREE.Group | undefined;
      if (pd.isEarth) {
        const axisRod = new THREE.Mesh(
          new THREE.CylinderGeometry(0.015, 0.015, 0.72, 8),
          brassMat
        );
        body.add(axisRod);
        moonPivot = new THREE.Group();
        body.add(moonPivot);
        const moon = new THREE.Mesh(
          new THREE.SphereGeometry(0.065, 12, 12),
          ceramicMat
        );
        moon.position.x = 0.42;
        moonPivot.add(moon);
      }
      if (pd.hasRings) {
        const ring = new THREE.Mesh(
          new THREE.RingGeometry(0.42, 0.66, 36),
          new THREE.MeshStandardMaterial({
            color: 0xd4af37,
            side: THREE.DoubleSide,
            roughness: 0.5,
          })
        );
        ring.rotation.x = Math.PI / 2.4;
        body.add(ring);
      }

      planetObjects.push({ pivot, body, speed: pd.speed, isEarth: pd.isEarth, moonPivot });
    });

    // =========================================================================
    // 5. LIVING CELL & ORGANELLE EXPLORER GROUP
    // =========================================================================
    const cellGroup = new THREE.Group();
    scene.add(cellGroup);

    const cellPedestal = new THREE.Mesh(
      new THREE.CylinderGeometry(2.4, 2.6, 0.25, 32),
      slateMat
    );
    cellPedestal.position.y = 0.125;
    cellGroup.add(cellPedestal);

    const cellBowl = new THREE.Mesh(
      new THREE.SphereGeometry(2.1, 32, 24, 0, Math.PI * 2, Math.PI * 0.45, Math.PI * 0.55),
      new THREE.MeshStandardMaterial({
        color: 0x0ea5e9,
        roughness: 0.45,
        side: THREE.DoubleSide,
      })
    );
    cellBowl.position.y = 1.65;
    cellGroup.add(cellBowl);

    const cellDome = new THREE.Mesh(
      new THREE.SphereGeometry(2.12, 32, 24, 0, Math.PI * 2, 0, Math.PI * 0.52),
      glassMat
    );
    cellDome.position.y = 1.65;
    cellGroup.add(cellDome);

    const nucleusCore = new THREE.Mesh(
      new THREE.SphereGeometry(0.65, 24, 24),
      new THREE.MeshStandardMaterial({
        color: 0xa855f7,
        emissive: 0x6b21a8,
        emissiveIntensity: 0.9,
        roughness: 0.3,
      })
    );
    nucleusCore.position.set(0, 1.75, 0);
    cellGroup.add(nucleusCore);

    const mitochondriaList: THREE.Mesh[] = [];
    const mitoMat = new THREE.MeshStandardMaterial({
      color: 0xf97316,
      emissive: 0x9a3412,
      emissiveIntensity: 0.7,
      roughness: 0.35,
    });
    const mitoGeo = new THREE.CapsuleGeometry(0.18, 0.42, 8, 16);
    [
      [1.15, 1.55, 0.65],
      [-1.1, 1.55, -0.7],
      [0.4, 1.48, -1.25],
    ].forEach(([x, y, z], i) => {
      const m = new THREE.Mesh(mitoGeo, mitoMat);
      m.position.set(x, y, z);
      m.rotation.set(0.3 * i, 0.8 * i, Math.PI / 2.3);
      cellGroup.add(m);
      mitochondriaList.push(m);
    });

    const chloroMat = new THREE.MeshStandardMaterial({
      color: 0x22c55e,
      emissive: 0x15803d,
      emissiveIntensity: 0.6,
      roughness: 0.35,
    });
    [
      [-1.1, 1.55, 0.85],
      [1.05, 1.55, -0.85],
      [-0.35, 1.5, 1.3],
    ].forEach(([x, y, z], i) => {
      const c = new THREE.Mesh(new THREE.SphereGeometry(0.24, 16, 12), chloroMat);
      c.scale.set(1.4, 0.6, 0.9);
      c.position.set(x, y, z);
      c.rotation.y = i * 1.1;
      cellGroup.add(c);
    });

    // =========================================================================
    // 6. 3D MENSURATION SOLIDS & TRIGONOMETRY LAB GROUP
    // =========================================================================
    const geomGroup = new THREE.Group();
    scene.add(geomGroup);

    const mathDeck = new THREE.Mesh(
      new THREE.CylinderGeometry(3.2, 3.3, 0.18, 48),
      slateMat
    );
    mathDeck.position.y = 0.09;
    geomGroup.add(mathDeck);

    const mathCone = new THREE.Mesh(
      new THREE.ConeGeometry(1, 1, 32),
      new THREE.MeshStandardMaterial({ color: 0x3b82f6, roughness: 0.35, metalness: 0.25 })
    );
    mathCone.castShadow = true;
    geomGroup.add(mathCone);

    const mathCylinder = new THREE.Mesh(
      new THREE.CylinderGeometry(1, 1, 1, 32),
      new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.32, metalness: 0.3 })
    );
    mathCylinder.castShadow = true;
    geomGroup.add(mathCylinder);

    const mathSphere = new THREE.Mesh(
      new THREE.SphereGeometry(1, 28, 28),
      new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.25, metalness: 0.35 })
    );
    mathSphere.castShadow = true;
    geomGroup.add(mathSphere);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const handleResize = () => {
      if (!mount) return;
      const w = mount.clientWidth || window.innerWidth;
      const h = mount.clientHeight || 420;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(mount);

    let frameId = 0;
    let disposed = false;
    let simTime = 0;
    let lastTheme: StudioTheme = "observatory";
    let lastReset = 0;
    const clock = new THREE.Clock();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const status = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (status === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.1);
      const st = stateRef.current;

      if (!st.paused) {
        simTime += dt;
      }

      if (st.resetTrigger !== lastReset) {
        lastReset = st.resetTrigger;
        camera.position.set(5.4, 4.2, 6.4);
        controls.target.set(0, 1.1, 0);
      }

      if (st.studioTheme !== lastTheme) {
        lastTheme = st.studioTheme;
        const isDay = lastTheme === "daylight";
        scene.background = (isDay ? lightBg : darkBg).clone();
        if (scene.fog instanceof THREE.FogExp2) {
          scene.fog.color.copy(isDay ? lightBg : darkBg);
        }
        floorMat.map = isDay ? lightGridTex : darkGridTex;
        floorMat.needsUpdate = true;
      }

      // Toggle only the active Lesson Simulation group
      elecGroup.visible = st.activeSim === "electricity";
      opticsGroup.visible = st.activeSim === "optics";
      atomGroup.visible = st.activeSim === "atom";
      solarGroup.visible = st.activeSim === "solar";
      cellGroup.visible = st.activeSim === "cell";
      geomGroup.visible = st.activeSim === "geometry";

      if (st.activeSim === "electricity") {
        const V = st.param1;
        const R = Math.max(0.5, st.param2);
        const I = V / R;
        const glow = Math.min(4.5, I * 0.65);
        filamentMat.emissiveIntensity = glow;
        bulbLight.intensity = glow * 1.4;
        ammeterNeedleGroup.rotation.y = THREE.MathUtils.clamp(
          (I / 8) * 1.4 - 0.7,
          -0.9,
          0.9
        );
        const driftRate = Math.min(1.8, I * 0.08);
        for (let i = 0; i < ELECTRON_COUNT; i++) {
          const u = ((i / ELECTRON_COUNT + simTime * driftRate) % 1 + 1) % 1;
          const pos = circuitCurve.getPointAt(u);
          electrons[i].position.copy(pos);
        }
      } else if (st.activeSim === "optics") {
        const u = st.param1;
        const f = st.param2;
        fMarker1.position.x = -f;
        fMarker2.position.x = f;
        objArrowGroup.position.set(-u, 0, 0);
        const v = u > f + 0.15 ? (u * f) / (u - f) : 4.2;
        const clampedV = THREE.MathUtils.clamp(v, 1.0, 4.4);
        const mag = clampedV / u;
        screenGroup.position.set(clampedV, 0, 0);
        imgArrow.scale.setScalar(THREE.MathUtils.clamp(mag, 0.4, 2.0));
        const tipY = 1.28;
        const imgTipY = Math.max(0.35, 1.35 - 0.07 * mag - 0.55 * mag);
        rayGeo1.setFromPoints([
          new THREE.Vector3(-u, tipY, 0),
          new THREE.Vector3(0, tipY, 0),
          new THREE.Vector3(clampedV, imgTipY, 0),
        ]);
        rayGeo2.setFromPoints([
          new THREE.Vector3(-u, tipY, 0),
          new THREE.Vector3(0, 1.35, 0),
          new THREE.Vector3(clampedV, imgTipY, 0),
        ]);
      } else if (st.activeSim === "atom") {
        const z = Math.round(st.param1);
        const spd = st.param2;
        nucleons.forEach((n, idx) => {
          n.visible = idx < z * 2;
        });
        nucleusGroup.rotation.y = simTime * 0.5;
        let rem = z;
        const counts = [0, 0, 0];
        counts[0] = Math.min(2, rem);
        rem -= counts[0];
        counts[1] = Math.min(8, rem);
        rem -= counts[1];
        counts[2] = Math.min(8, rem);

        let idxPerShell = [0, 0, 0];
        atomElectrons.forEach((item) => {
          const s = item.shellIdx;
          const posInShell = idxPerShell[s]++;
          item.mesh.visible = posInShell < counts[s];
          if (item.mesh.visible) {
            const a =
              (posInShell / Math.max(1, counts[s])) * Math.PI * 2 +
              simTime * spd * (2.0 - s * 0.45);
            item.mesh.position.set(
              Math.cos(a) * shellRadii[s],
              0,
              Math.sin(a) * shellRadii[s]
            );
          }
        });
      } else if (st.activeSim === "solar") {
        const spd = st.param1;
        const tiltRad = THREE.MathUtils.degToRad(st.param2);
        planetObjects.forEach((p, idx) => {
          p.pivot.rotation.y = simTime * spd * p.speed + idx * 1.1;
          p.body.rotation.y = simTime * 1.4;
          if (p.isEarth) {
            p.body.rotation.z = tiltRad;
            if (p.moonPivot) p.moonPivot.rotation.y = simTime * 2.2 * spd;
          }
        });
      } else if (st.activeSim === "cell") {
        const rate = st.param1;
        const open = st.param2;
        cellDome.position.y = 1.65 + open * 1.1;
        cellDome.rotation.z = -open * 0.4;
        nucleusCore.scale.setScalar(1 + Math.sin(simTime * rate * 2.2) * 0.05);
        mitochondriaList.forEach((m, i) => {
          m.position.y = 1.52 + Math.sin(simTime * rate * 2 + i) * 0.08;
        });
      } else if (st.activeSim === "geometry") {
        const r = st.param1;
        const h = st.param2;
        mathCone.scale.set(r * 0.85, h, r * 0.85);
        mathCone.position.set(-1.75, 0.18 + h / 2, 0);

        mathCylinder.scale.set(r * 0.85, h, r * 0.85);
        mathCylinder.position.set(0, 0.18 + h / 2, 0);

        mathSphere.scale.setScalar(r * 0.85);
        mathSphere.position.set(1.75, 0.18 + r * 0.85, 0);
      }

      controls.update();
      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      resizeObserver.disconnect();
      controls.dispose();
      renderer.domElement.removeEventListener("webglcontextlost", onContextLost);
      scene.traverse((obj) => {
        if (obj instanceof THREE.Mesh || obj instanceof THREE.Line) {
          obj.geometry.dispose();
          if (Array.isArray(obj.material)) {
            obj.material.forEach((m) => m.dispose());
          } else {
            obj.material.dispose();
          }
        }
      });
      darkGridTex.dispose();
      lightGridTex.dispose();
      earthTex.dispose();
      roomEnvTex.dispose();
      renderer.dispose();
    };
  }, []);

  const simMeta = SIM_CATALOG[activeSim];

  const liveReadout = useMemo(() => {
    if (activeSim === "electricity") {
      const current = param1 / Math.max(0.5, param2);
      const power = param1 * current;
      return `I = V/R = ${current.toFixed(2)} A · Power = ${power.toFixed(1)} W`;
    }
    if (activeSim === "optics") {
      const v =
        param1 > param2 + 0.15 ? (param1 * param2) / (param1 - param2) : 4.2;
      const m = v / param1;
      return `Image Distance v = ${v.toFixed(2)} m · Magnification = -${m.toFixed(2)}x`;
    }
    if (activeSim === "atom") {
      const z = Math.round(param1);
      const k = Math.min(2, z);
      const l = Math.min(8, Math.max(0, z - 2));
      const m = Math.max(0, z - 10);
      const sym = ELEMENTS_1_18[z - 1] || "El";
      return `${sym} (Z=${z}) · Shells K:${k} L:${l}${m > 0 ? ` M:${m}` : ""}`;
    }
    if (activeSim === "solar") {
      return `Earth Axial Tilt: ${param2.toFixed(1)}° · Orbit Speed: ${param1.toFixed(1)}x`;
    }
    if (activeSim === "cell") {
      return `Metabolic ATP Rate: ${param1.toFixed(1)}x · Cutaway: ${Math.round(param2 * 100)}%`;
    }
    const r = param1;
    const h = param2;
    const cylVol = Math.PI * r * r * h;
    const coneVol = cylVol / 3;
    return `Cyl V = ${cylVol.toFixed(2)} · Cone V = ${coneVol.toFixed(2)} · r=${r.toFixed(2)}, h=${h.toFixed(2)}`;
  }, [activeSim, param1, param2]);

  return (
    <div
      className={
        fullStage
          ? "fixed inset-0 z-40 bg-[#0B0F17] overflow-hidden select-none"
          : "relative w-full h-[380px] rounded-xl overflow-hidden border border-stone-200 bg-[#0B0F17]"
      }
    >
      <div ref={containerRef} className="w-full h-full" />

      {webglError && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#0B0F17] text-stone-200 p-6 text-center">
          <p className="font-display text-xl font-medium">
            3D Lesson Stage Unavailable
          </p>
          <p className="mt-2 text-sm text-stone-400 max-w-md">
            WebGL rendering could not be initialized on this device.
          </p>
        </div>
      )}

      {/* Embedded preview header (inside Study Loop) */}
      {!fullStage && (
        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-center justify-between p-3.5">
          <div
            className="pointer-events-auto px-3 py-1.5 rounded-lg text-xs font-medium text-stone-100 border border-white/10"
            style={{ backgroundColor: "rgba(11, 15, 23, 0.88)" }}
          >
            {simMeta.title}
          </div>
          {onExpandStage && (
            <button
              type="button"
              onClick={onExpandStage}
              className="pointer-events-auto inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-stone-100 border border-white/15 hover:bg-stone-800 transition-colors cursor-pointer"
              style={{ backgroundColor: "rgba(11, 15, 23, 0.9)" }}
            >
              <Expand className="w-3.5 h-3.5" />
              <span>Open 3D Lesson Stage</span>
            </button>
          )}
        </div>
      )}

      {/* Full-Stage Top-Left Bar: Back + Active Lesson Situation + Live Readout */}
      {fullStage && (
        <div className="pointer-events-none absolute top-5 left-5 right-5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-3">
            {onExitStage && (
              <button
                type="button"
                onClick={onExitStage}
                className="pointer-events-auto inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium text-stone-100 border border-white/15 hover:bg-stone-800 transition-colors cursor-pointer whitespace-nowrap"
                style={{ backgroundColor: "rgba(11, 15, 23, 0.92)" }}
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Tutorix AI</span>
              </button>
            )}
            <div
              className="pointer-events-auto px-3.5 py-2 rounded-lg border border-white/10 text-xs text-stone-200 flex flex-wrap items-center gap-2"
              style={{ backgroundColor: "rgba(11, 15, 23, 0.9)" }}
            >
              <span className="font-display font-semibold text-white">
                {exactMatchSim && studentContext.lessonTitle
                  ? studentContext.lessonTitle
                  : simMeta.title}
              </span>
              <span className="text-stone-500" aria-hidden="true">
                ·
              </span>
              <span className="text-stone-300">
                {exactMatchSim
                  ? `${studentContext.studentClass} CBSE ${studentContext.subject}`
                  : "Available Interactive 3D Simulations"}
              </span>
            </div>
          </div>

          <div
            className="pointer-events-auto px-3.5 py-2 rounded-lg border border-amber-400/30 text-xs font-mono-tabular text-amber-200"
            style={{ backgroundColor: "rgba(11, 15, 23, 0.92)" }}
          >
            {liveReadout}
          </div>
        </div>
      )}

      {/* Unified Collapsible Bottom Dock (Zero Backdrop Blur) */}
      {fullStage && (
        <div
          className="fixed left-1/2 bottom-5 z-50 w-[min(980px,95vw)] transition-transform duration-200 ease-out"
          style={{
            transform: dockCollapsed
              ? "translate(-50%, calc(100% - 36px))"
              : "translate(-50%, 0)",
          }}
        >
          <div className="flex justify-center">
            <button
              type="button"
              onClick={() => setDockCollapsed((v) => !v)}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-t-lg text-[11px] font-medium text-stone-200 border border-b-0 border-white/15 hover:text-white cursor-pointer"
              style={{ backgroundColor: "rgba(11, 15, 23, 0.94)" }}
            >
              {dockCollapsed ? (
                <>
                  <ChevronUp className="w-3.5 h-3.5" />
                  <span>Show Lesson Controls (H)</span>
                </>
              ) : (
                <>
                  <ChevronDown className="w-3.5 h-3.5" />
                  <span>Hide Lesson Controls (H)</span>
                </>
              )}
            </button>
          </div>

          <div
            className="rounded-xl border border-white/15 p-3.5 text-stone-100 shadow-2xl space-y-3"
            style={{ backgroundColor: "rgba(11, 15, 23, 0.94)" }}
          >
            {/* Lesson Situation Switcher */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-1.5">
                {(Object.keys(SIM_CATALOG) as LessonSimId[]).map((id) => {
                  const item = SIM_CATALOG[id];
                  const active = activeSim === id;
                  const isMatched = exactMatchSim === id;
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => selectSimManually(id)}
                      className={`px-2.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        active
                          ? "bg-white text-slate-950 font-semibold"
                          : "text-stone-300 hover:text-white hover:bg-white/10"
                      }`}
                    >
                      {item.shortLabel}
                      {isMatched ? " ★" : ""}
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setPaused((p) => !p)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium bg-slate-900 border border-white/10 text-stone-200 hover:text-white cursor-pointer"
                >
                  {paused ? (
                    <>
                      <Play className="w-3.5 h-3.5" />
                      <span>Play</span>
                    </>
                  ) : (
                    <>
                      <Pause className="w-3.5 h-3.5" />
                      <span>Pause</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setStudioTheme((t) =>
                      t === "observatory" ? "daylight" : "observatory"
                    )
                  }
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium bg-slate-900 border border-white/10 text-stone-200 hover:text-white cursor-pointer"
                >
                  {studioTheme === "observatory" ? (
                    <>
                      <Sun className="w-3.5 h-3.5 text-amber-300" />
                      <span>Light</span>
                    </>
                  ) : (
                    <>
                      <Moon className="w-3.5 h-3.5 text-blue-300" />
                      <span>Dark</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setResetTrigger((n) => n + 1)}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-medium bg-slate-900 border border-white/10 text-stone-200 hover:text-white cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset</span>
                </button>
              </div>
            </div>

            {/* Interactive Lesson Parameter Sliders */}
            <div className="flex flex-wrap items-center gap-6 pt-2 border-t border-white/10">
              <div className="flex items-center gap-3 flex-1 min-w-[220px]">
                <label
                  htmlFor="sim-param-1"
                  className="text-xs text-stone-300 whitespace-nowrap"
                >
                  {simMeta.param1Label}
                </label>
                <input
                  id="sim-param-1"
                  type="range"
                  min={simMeta.param1Min}
                  max={simMeta.param1Max}
                  step={simMeta.param1Step}
                  value={param1}
                  onChange={(e) => setParam1(parseFloat(e.target.value))}
                  className="flex-1 accent-amber-400 cursor-pointer"
                />
                <span className="font-mono-tabular text-xs text-amber-200 w-14 text-right">
                  {param1}
                  {simMeta.param1Unit}
                </span>
              </div>

              <div className="flex items-center gap-3 flex-1 min-w-[220px]">
                <label
                  htmlFor="sim-param-2"
                  className="text-xs text-stone-300 whitespace-nowrap"
                >
                  {simMeta.param2Label}
                </label>
                <input
                  id="sim-param-2"
                  type="range"
                  min={simMeta.param2Min}
                  max={simMeta.param2Max}
                  step={simMeta.param2Step}
                  value={param2}
                  onChange={(e) => setParam2(parseFloat(e.target.value))}
                  className="flex-1 accent-blue-400 cursor-pointer"
                />
                <span className="font-mono-tabular text-xs text-blue-200 w-14 text-right">
                  {param2}
                  {simMeta.param2Unit}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
