import React, { useEffect, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  FileText,
  ClipboardList,
  Users,
  Plus,
  Trash2,
  Loader2,
  Printer,
  Copy,
  Check,
  Download,
  LogOut,
  Wand2,
  Send,
  BookOpen,
  MessageSquare,
  ArrowLeft,
} from "lucide-react";
import {
  STUDENT_CLASSES,
  getSubjectsForClass,
  type StudentClass,
} from "../data/syllabusCatalog";
import { safeJsonResponse } from "../utils/freeLocalChat";
import type {
  SavedQuestionPaper,
  StudentTest,
  TeacherSession,
  TestQuestion,
  TestSubmission,
} from "../types";

interface TeacherPortalPageProps {
  session: TeacherSession;
  onLogout: () => void;
  onBackToStudentPortal: () => void;
  onSwitchToStudentTools: (
    target: "syllabus" | "loop" | "chat"
  ) => void;
}

type PortalTab = "tests" | "papers" | "results";

export const TeacherPortalPage: React.FC<TeacherPortalPageProps> = ({
  session,
  onLogout,
  onBackToStudentPortal,
  onSwitchToStudentTools,
}) => {
  const [activeTab, setActiveTab] = useState<PortalTab>("tests");

  // Teacher Tests & Submissions State
  const [publishedTests, setPublishedTests] = useState<StudentTest[]>([]);
  const [submissions, setSubmissions] = useState<TestSubmission[]>([]);
  const [savedPapers, setSavedPapers] = useState<SavedQuestionPaper[]>([]);

  // Student Test Builder State
  const [testClass, setTestClass] = useState<StudentClass>("Class 10");
  const [testSubject, setTestSubject] = useState("Science");
  const [testChapter, setTestChapter] = useState("Electricity");
  const [testTitle, setTestTitle] = useState(
    "Class 10 Science — Electricity Unit Test"
  );
  const [testDuration, setTestDuration] = useState(20);
  const [questionCount, setQuestionCount] = useState(5);
  const [difficulty, setDifficulty] = useState("CBSE Standard");
  const [customTestCode, setCustomTestCode] = useState("");
  const [draftQuestions, setDraftQuestions] = useState<TestQuestion[]>([]);
  const [generatingTest, setGeneratingTest] = useState(false);
  const [publishingTest, setPublishingTest] = useState(false);
  const [lastPublished, setLastPublished] = useState<{
    title: string;
    testCode: string;
  } | null>(null);
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);
  const [testError, setTestError] = useState<string | null>(null);

  // Question Paper Maker State
  const [qpSchool, setQpSchool] = useState("Kendriya Vidyalaya (KVS)");
  const [qpClass, setQpClass] = useState<StudentClass>("Class 10");
  const [qpSubject, setQpSubject] = useState("Science");
  const [qpChapters, setQpChapters] = useState(
    "Chemical Reactions & Equations, Life Processes, Light, Electricity"
  );
  const [qpExamType, setQpExamType] = useState("Periodic Test (PT-1)");
  const [qpMarks, setQpMarks] = useState(40);
  const [qpDuration, setQpDuration] = useState("90 Minutes");
  const [qpBlueprint, setQpBlueprint] = useState(
    "Section A: 10 MCQs (1M each), Section B: 4 Very Short Answer (2M each), Section C: 4 Short Answer (3M each), Section D: 1 Case-Based (5M), Section E: 1 Long Answer (5M)"
  );
  const [generatingPaper, setGeneratingPaper] = useState(false);
  const [activePaper, setActivePaper] = useState<SavedQuestionPaper | null>(
    null
  );
  const [paperViewMode, setPaperViewMode] = useState<"paper" | "key">("paper");
  const [paperError, setPaperError] = useState<string | null>(null);
  const [copiedPaper, setCopiedPaper] = useState(false);

  const authHeaders = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${session.token}`,
  };

  const fetchPortalData = async () => {
    try {
      const [testsRes, papersRes] = await Promise.all([
        fetch("/api/tests", { headers: authHeaders }),
        fetch("/api/question-papers", { headers: authHeaders }),
      ]);
      if (testsRes.ok) {
        const tData = await safeJsonResponse<{
          tests?: StudentTest[];
          submissions?: TestSubmission[];
        }>(testsRes);
        if (tData) {
          setPublishedTests(Array.isArray(tData.tests) ? tData.tests : []);
          setSubmissions(
            Array.isArray(tData.submissions) ? tData.submissions : []
          );
        }
      }
      if (papersRes.ok) {
        const pData = await safeJsonResponse<{
          questionPapers?: SavedQuestionPaper[];
        }>(papersRes);
        if (pData) {
          const list = Array.isArray(pData.questionPapers)
            ? pData.questionPapers
            : [];
          setSavedPapers(list);
          if (!activePaper && list.length > 0) {
            setActivePaper(list[0]);
          }
        }
      }
    } catch {
      // Ignore network hiccup cleanly
    }
  };

  useEffect(() => {
    fetchPortalData();
  }, []);

  const handleTestClassChange = (cls: StudentClass) => {
    setTestClass(cls);
    const valid = getSubjectsForClass(cls);
    if (!valid.includes(testSubject)) setTestSubject(valid[0]);
  };

  const handleQpClassChange = (cls: StudentClass) => {
    setQpClass(cls);
    const valid = getSubjectsForClass(cls);
    if (!valid.includes(qpSubject)) setQpSubject(valid[0]);
  };

  const handleGenerateTestQuestions = async () => {
    if (generatingTest) return;
    setGeneratingTest(true);
    setTestError(null);
    setLastPublished(null);
    try {
      const res = await fetch("/api/teacher/generate-test", {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({
          studentClass: testClass,
          subject: testSubject,
          chapter: testChapter,
          questionCount,
          difficulty,
        }),
      });
      const data = await safeJsonResponse<{
        questions?: TestQuestion[];
        error?: string;
      }>(res);
      if (!res.ok || !data) {
        throw new Error(data?.error || "Could not generate test.");
      }
      setDraftQuestions(data.questions || []);
    } catch (err) {
      setTestError(
        err instanceof Error ? err.message : "Failed to generate questions."
      );
    } finally {
      setGeneratingTest(false);
    }
  };

  const handleAddEmptyQuestion = () => {
    setDraftQuestions((prev) => [
      ...prev,
      {
        id: `q-${Date.now()}-${prev.length}`,
        question: "",
        options: ["Option A", "Option B", "Option C", "Option D"],
        correctIndex: 0,
        marks: 1,
        explanation: "",
      },
    ]);
  };

  const handleCopyCode = async (code: string, id: string) => {
    if (!code) return;
    try {
      await navigator.clipboard.writeText(code);
      setCopiedCodeId(id);
      setTimeout(() => setCopiedCodeId(null), 2000);
    } catch {
      // Clipboard fallback ignored
    }
  };

  const handlePublishTest = async () => {
    if (!testTitle.trim() || draftQuestions.length === 0 || publishingTest) {
      return;
    }
    setPublishingTest(true);
    setTestError(null);
    setLastPublished(null);
    try {
      const res = await fetch("/api/tests", {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({
          title: testTitle.trim(),
          studentClass: testClass,
          subject: testSubject,
          chapter: testChapter,
          durationMinutes: testDuration,
          customCode: customTestCode.trim(),
          questions: draftQuestions,
        }),
      });
      const data = await safeJsonResponse<{
        test?: StudentTest;
        error?: string;
      }>(res);
      if (!res.ok || !data?.test) {
        throw new Error(data?.error || "Could not publish test.");
      }
      setPublishedTests((prev) => [data.test!, ...prev]);
      setDraftQuestions([]);
      setCustomTestCode("");
      setLastPublished({
        title: data.test.title,
        testCode: data.test.testCode,
      });
    } catch (err) {
      setTestError(err instanceof Error ? err.message : "Publish failed.");
    } finally {
      setPublishingTest(false);
    }
  };

  const handleDeleteTest = async (id: string) => {
    const res = await fetch(`/api/tests/${id}`, {
      method: "DELETE",
      headers: authHeaders,
    });
    if (res.ok) {
      setPublishedTests((prev) => prev.filter((t) => t.id !== id));
    }
  };

  const handleGenerateQuestionPaper = async () => {
    if (generatingPaper) return;
    setGeneratingPaper(true);
    setPaperError(null);
    try {
      const res = await fetch("/api/teacher/question-paper", {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({
          schoolName: qpSchool,
          studentClass: qpClass,
          subject: qpSubject,
          chapters: qpChapters,
          examType: qpExamType,
          totalMarks: qpMarks,
          duration: qpDuration,
          blueprint: qpBlueprint,
        }),
      });
      const data = await safeJsonResponse<{
        questionPaper?: SavedQuestionPaper;
        error?: string;
      }>(res);
      if (!res.ok || !data?.questionPaper) {
        throw new Error(data?.error || "Failed to create question paper.");
      }
      setSavedPapers((prev) => [data.questionPaper!, ...prev]);
      setActivePaper(data.questionPaper);
      setPaperViewMode("paper");
    } catch (err) {
      setPaperError(
        err instanceof Error ? err.message : "Question paper generation failed."
      );
    } finally {
      setGeneratingPaper(false);
    }
  };

  const handleDeletePaper = async (id: string) => {
    const res = await fetch(`/api/question-papers/${id}`, {
      method: "DELETE",
      headers: authHeaders,
    });
    if (res.ok) {
      const remaining = savedPapers.filter((p) => p.id !== id);
      setSavedPapers(remaining);
      if (activePaper?.id === id) {
        setActivePaper(remaining[0] || null);
      }
    }
  };

  const activeMarkdown =
    paperViewMode === "paper"
      ? activePaper?.paperMarkdown || ""
      : activePaper?.answerKeyMarkdown || "";

  const handleCopyPaper = async () => {
    if (!activeMarkdown) return;
    await navigator.clipboard.writeText(activeMarkdown);
    setCopiedPaper(true);
    setTimeout(() => setCopiedPaper(false), 2000);
  };

  const handleDownloadPaper = () => {
    if (!activeMarkdown || !activePaper) return;
    const blob = new Blob([activeMarkdown], {
      type: "text/markdown;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${activePaper.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")}-${paperViewMode}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen flex flex-col ios-app-bg text-stone-900 page-transition-enter">
      {/* Standalone Dedicated Teacher Portal Top Navigation */}
      <header className="no-print sticky top-0 z-30 border-b backdrop-blur-xl bg-white/80 border-slate-200/80 shadow-[0_1px_12px_rgba(15,23,42,0.04)]">
        <div className="max-w-[1380px] mx-auto px-6 h-16 flex items-center justify-between gap-6">
          {/* Zone 1: Teacher Portal Brand Lockup */}
          <div className="inline-flex items-center gap-2.5 whitespace-nowrap shrink-0">
            <img
              src="/assets/aistudio/image_555f3288.png"
              alt="Tutorix AI logo"
              referrerPolicy="no-referrer"
              className="w-8 h-8 rounded-xl shadow-xs object-cover"
            />
            <div>
              <span className="font-display text-lg font-semibold tracking-tight text-stone-900">
                Tutorix AI
              </span>
              <span className="ml-2 text-xs font-medium text-blue-700 hidden sm:inline">
                · Teacher Portal
              </span>
            </div>
          </div>

          {/* Zone 2: Dedicated Teacher Workspace Tabs */}
          <nav
            aria-label="Teacher Portal Navigation"
            className="flex items-center gap-3 text-sm font-medium overflow-x-auto"
          >
            {(
              [
                {
                  id: "tests",
                  label: "Create Student Test",
                  icon: ClipboardList,
                },
                {
                  id: "papers",
                  label: "Question Paper Maker",
                  icon: FileText,
                },
                {
                  id: "results",
                  label: `Student Results (${submissions.length})`,
                  icon: Users,
                },
              ] as const
            ).map((tab) => {
              const Icon = tab.icon;
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`inline-flex items-center gap-1.5 py-1.5 px-3 rounded-xl transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? "bg-stone-900/5 text-stone-900 font-semibold shadow-[inset_0_1px_0_rgba(255,255,255,0.8)]"
                      : "text-stone-500 hover:text-stone-900 hover:bg-white/60"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Return to Student Portal & Sign Out */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={onBackToStudentPortal}
              className="ios-glass-btn inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-medium text-stone-800 cursor-pointer whitespace-nowrap shrink-0"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Student Portal</span>
            </button>

            <button
              type="button"
              onClick={onLogout}
              className="ios-glass-btn inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-medium text-red-700 cursor-pointer whitespace-nowrap shrink-0"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-[1380px] w-full mx-auto px-6 py-8 space-y-8">
        {/* KVS Faculty Welcome Banner */}
        <section className="no-print ios-glass-card rounded-3xl p-6 md:p-8 flex flex-wrap items-center justify-between gap-6">
          <div>
            <p className="text-xs font-medium text-blue-700">
              Kendriya Vidyalaya Sangathan (KVS) · Authorized Teacher Page
            </p>
            <h1 className="font-display text-2xl md:text-3xl font-semibold text-stone-900 mt-1">
              Welcome, {session.teacherName} Sir
            </h1>
            <p className="mt-1 text-sm text-stone-600">
              Prepare timed tests with auto-generated Student Exam Codes, build
              printable CBSE Question Papers with Marking Schemes, or review
              student scores.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => onSwitchToStudentTools("syllabus")}
              className="ios-glass-btn inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-medium text-stone-800 cursor-pointer whitespace-nowrap"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>CBSE Syllabus</span>
            </button>

            <button
              type="button"
              onClick={() => onSwitchToStudentTools("chat")}
              className="ios-glass-btn inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-medium text-stone-800 cursor-pointer whitespace-nowrap"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>AI Chat</span>
            </button>
          </div>
        </section>

      {/* TAB 1: STUDENT TEST BUILDER */}
      {activeTab === "tests" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <section className="lg:col-span-8 ios-glass-card rounded-3xl p-6 md:p-8 space-y-6">
            <div>
              <h2 className="font-display text-xl font-semibold text-stone-900">
                Create & Publish Student Test
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                Students can take published tests immediately with zero login on
                the KVS Tests page.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Test Title
                </label>
                <input
                  type="text"
                  value={testTitle}
                  onChange={(e) => setTestTitle(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-sm text-stone-900 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Chapter / Topic Focus
                </label>
                <input
                  type="text"
                  value={testChapter}
                  onChange={(e) => setTestChapter(e.target.value)}
                  placeholder="e.g., Ohm's Law & Circuits"
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-sm text-stone-900 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  CBSE Class
                </label>
                <select
                  value={testClass}
                  onChange={(e) =>
                    handleTestClassChange(e.target.value as StudentClass)
                  }
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-sm text-stone-900 focus:outline-none focus:border-blue-500"
                >
                  {STUDENT_CLASSES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Subject
                </label>
                <select
                  value={testSubject}
                  onChange={(e) => setTestSubject(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-sm text-stone-900 focus:outline-none focus:border-blue-500"
                >
                  {getSubjectsForClass(testClass).map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  AI Question Count
                </label>
                <select
                  value={questionCount}
                  onChange={(e) => setQuestionCount(Number(e.target.value))}
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-sm text-stone-900 focus:outline-none focus:border-blue-500"
                >
                  {[5, 10, 15, 20].map((n) => (
                    <option key={n} value={n}>
                      {n} Questions
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                    Difficulty
                  </label>
                  <select
                    value={difficulty}
                    onChange={(e) => setDifficulty(e.target.value)}
                    className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3 py-2.5 text-xs text-stone-900 focus:outline-none focus:border-blue-500"
                  >
                    <option value="Easy Foundation">Easy</option>
                    <option value="CBSE Standard">CBSE Standard</option>
                    <option value="Board Challenging">Board Level</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                    Minutes
                  </label>
                  <input
                    type="number"
                    min={5}
                    max={180}
                    value={testDuration}
                    onChange={(e) =>
                      setTestDuration(Number(e.target.value) || 20)
                    }
                    className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3 py-2.5 text-xs text-stone-900 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Test Access Code (Optional)
                </label>
                <input
                  type="text"
                  value={customTestCode}
                  onChange={(e) =>
                    setCustomTestCode(e.target.value.toUpperCase())
                  }
                  placeholder="Auto-generates e.g. KVS-4821"
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-sm font-mono-tabular text-stone-900 placeholder:text-stone-400 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={handleGenerateTestQuestions}
                disabled={generatingTest}
                className="ios-glass-btn-blue inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-semibold cursor-pointer disabled:opacity-50"
              >
                {generatingTest ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Wand2 className="w-3.5 h-3.5" />
                )}
                <span>
                  {generatingTest
                    ? "Drafting CBSE Questions..."
                    : "Generate CBSE Questions with AI"}
                </span>
              </button>

              <button
                type="button"
                onClick={handleAddEmptyQuestion}
                className="ios-glass-btn inline-flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs font-medium text-stone-800 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Custom Question</span>
              </button>
            </div>

            {testError && (
              <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-800">
                {testError}
              </div>
            )}

            {lastPublished && (
              <div className="rounded-2xl border border-emerald-200 bg-emerald-50/90 px-5 py-4 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold text-emerald-900">
                    Test Published & Ready for Students
                  </p>
                  <p className="text-xs text-emerald-800 mt-0.5">
                    Share code{" "}
                    <span className="font-mono-tabular font-bold text-stone-950">
                      {lastPublished.testCode}
                    </span>{" "}
                    with students so they can start "{lastPublished.title}" on
                    the KVS Tests page.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    handleCopyCode(lastPublished.testCode, "banner")
                  }
                  className="ios-glass-btn-primary inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer whitespace-nowrap"
                >
                  {copiedCodeId === "banner" ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Copied {lastPublished.testCode}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Code: {lastPublished.testCode}</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* Editable Draft Questions */}
            {draftQuestions.length > 0 && (
              <div className="space-y-4 pt-4 border-t border-slate-200/70">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-stone-900">
                    Draft Test Questions ({draftQuestions.length})
                  </h3>
                  <button
                    type="button"
                    onClick={handlePublishTest}
                    disabled={publishingTest || !testTitle.trim()}
                    className="ios-glass-btn-primary inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl text-xs font-semibold cursor-pointer disabled:opacity-50"
                  >
                    {publishingTest ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Send className="w-3.5 h-3.5" />
                    )}
                    <span>Publish Test to Students</span>
                  </button>
                </div>

                {draftQuestions.map((q, qIdx) => (
                  <div
                    key={q.id}
                    className="ios-glass-subtle rounded-2xl p-4 space-y-3"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-xs font-semibold text-stone-700 pt-2">
                        Q{qIdx + 1}
                      </span>
                      <input
                        type="text"
                        value={q.question}
                        onChange={(e) => {
                          const val = e.target.value;
                          setDraftQuestions((prev) =>
                            prev.map((item, idx) =>
                              idx === qIdx ? { ...item, question: val } : item
                            )
                          );
                        }}
                        placeholder="Enter question statement..."
                        className="flex-1 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-stone-900"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setDraftQuestions((prev) =>
                            prev.filter((_, idx) => idx !== qIdx)
                          )
                        }
                        className="p-2 text-stone-400 hover:text-red-600 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {q.options.map((opt, oIdx) => (
                        <div key={oIdx} className="flex items-center gap-2">
                          <input
                            type="radio"
                            name={`correct-${q.id}`}
                            checked={q.correctIndex === oIdx}
                            onChange={() =>
                              setDraftQuestions((prev) =>
                                prev.map((item, idx) =>
                                  idx === qIdx
                                    ? { ...item, correctIndex: oIdx }
                                    : item
                                )
                              )
                            }
                          />
                          <input
                            type="text"
                            value={opt}
                            onChange={(e) => {
                              const val = e.target.value;
                              setDraftQuestions((prev) =>
                                prev.map((item, idx) => {
                                  if (idx !== qIdx) return item;
                                  const nextOpts = [...item.options] as [
                                    string,
                                    string,
                                    string,
                                    string
                                  ];
                                  nextOpts[oIdx] = val;
                                  return { ...item, options: nextOpts };
                                })
                              );
                            }}
                            className="flex-1 rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-stone-900"
                          />
                        </div>
                      ))}
                    </div>

                    <input
                      type="text"
                      value={q.explanation}
                      onChange={(e) => {
                        const val = e.target.value;
                        setDraftQuestions((prev) =>
                          prev.map((item, idx) =>
                            idx === qIdx ? { ...item, explanation: val } : item
                          )
                        );
                      }}
                      placeholder="Short answer explanation for students..."
                      className="w-full rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs text-stone-700"
                    />
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Right Rail: Published Tests */}
          <aside className="lg:col-span-4 ios-glass-card rounded-3xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-base font-semibold text-stone-900">
                Published Tests
              </h3>
              <span className="font-mono-tabular text-xs text-stone-500">
                {publishedTests.length} live
              </span>
            </div>

            {publishedTests.length === 0 ? (
              <p className="text-xs text-stone-500 py-4">
                No tests published yet. Draft questions on the left and click
                Publish Test to Students.
              </p>
            ) : (
              <div className="space-y-3">
                {publishedTests.map((t) => (
                  <div
                    key={t.id}
                    className="ios-glass-subtle rounded-2xl p-4 flex items-start justify-between gap-3"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="text-[11px] font-mono-tabular text-stone-500">
                        {t.studentClass} · {t.subject}
                      </p>
                      <p className="text-xs font-semibold text-stone-900 mt-0.5">
                        {t.title}
                      </p>
                      <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px]">
                        <span className="font-mono-tabular font-semibold text-blue-700">
                          Code: {t.testCode}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleCopyCode(t.testCode, t.id)}
                          className="ios-glass-btn inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-medium text-stone-700 cursor-pointer"
                        >
                          {copiedCodeId === t.id ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-700" />
                              <span>Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>
                      </div>
                      <p className="text-[11px] text-stone-500 mt-1">
                        {t.questions.length} Qs · {t.durationMinutes} min
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDeleteTest(t.id)}
                      title="Delete test"
                      className="text-stone-400 hover:text-red-600 cursor-pointer p-1 shrink-0"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </aside>
        </div>
      )}

      {/* TAB 2: OFFICIAL CBSE / KVS QUESTION PAPER MAKER */}
      {activeTab === "papers" && (
        <div className="space-y-8">
          <section className="no-print ios-glass-card rounded-3xl p-6 md:p-8 space-y-5">
            <div>
              <h2 className="font-display text-xl font-semibold text-stone-900">
                CBSE / KVS Question Paper & Marking Scheme Maker
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                Generates a formal printable exam paper (Sections A–E with mark
                allocations & internal choices) plus a separate answer key.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  School / Vidyalaya Header
                </label>
                <input
                  type="text"
                  value={qpSchool}
                  onChange={(e) => setQpSchool(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-sm text-stone-900"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  CBSE Class
                </label>
                <select
                  value={qpClass}
                  onChange={(e) =>
                    handleQpClassChange(e.target.value as StudentClass)
                  }
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-sm text-stone-900"
                >
                  {STUDENT_CLASSES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Subject
                </label>
                <select
                  value={qpSubject}
                  onChange={(e) => setQpSubject(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-sm text-stone-900"
                >
                  {getSubjectsForClass(qpClass).map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Examination Type
                </label>
                <select
                  value={qpExamType}
                  onChange={(e) => setQpExamType(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-sm text-stone-900"
                >
                  <option value="Periodic Test (PT-1)">
                    Periodic Test (PT-1 / PT-2)
                  </option>
                  <option value="Half-Yearly Examination">
                    Half-Yearly Examination
                  </option>
                  <option value="Pre-Board Examination">
                    Pre-Board Examination
                  </option>
                  <option value="Annual Session Ending Exam">
                    Annual / Session Ending Exam
                  </option>
                  <option value="Unit Class Test">Unit Class Test</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Maximum Marks
                </label>
                <select
                  value={qpMarks}
                  onChange={(e) => setQpMarks(Number(e.target.value))}
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-sm text-stone-900"
                >
                  {[20, 30, 40, 50, 70, 80].map((m) => (
                    <option key={m} value={m}>
                      {m} Marks
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Time Allowed
                </label>
                <input
                  type="text"
                  value={qpDuration}
                  onChange={(e) => setQpDuration(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-sm text-stone-900"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Chapters / Syllabus Scope
                </label>
                <textarea
                  rows={2}
                  value={qpChapters}
                  onChange={(e) => setQpChapters(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-xs text-stone-900"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Section & Marks Blueprint
                </label>
                <textarea
                  rows={2}
                  value={qpBlueprint}
                  onChange={(e) => setQpBlueprint(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-xs text-stone-900"
                />
              </div>
            </div>

            {paperError && (
              <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-800">
                {paperError}
              </div>
            )}

            <div className="flex justify-end">
              <button
                type="button"
                onClick={handleGenerateQuestionPaper}
                disabled={generatingPaper}
                className="ios-glass-btn-primary inline-flex items-center gap-2 px-6 py-3 rounded-2xl text-sm font-semibold cursor-pointer disabled:opacity-50"
              >
                {generatingPaper ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Preparing Official Question Paper...</span>
                  </>
                ) : (
                  <>
                    <FileText className="w-4 h-4" />
                    <span>Generate KVS Question Paper</span>
                  </>
                )}
              </button>
            </div>
          </section>

          {/* Active Paper Preview + Saved Archive */}
          {activePaper && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              <article className="lg:col-span-9 ios-glass-card rounded-3xl p-8 md:p-12 space-y-6">
                <div className="no-print flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-slate-200/70">
                  <div className="ios-segmented flex items-center gap-1 p-1 rounded-2xl">
                    <button
                      type="button"
                      onClick={() => setPaperViewMode("paper")}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold cursor-pointer ${
                        paperViewMode === "paper"
                          ? "bg-white text-stone-900 shadow-sm"
                          : "text-stone-600"
                      }`}
                    >
                      Question Paper
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaperViewMode("key")}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold cursor-pointer ${
                        paperViewMode === "key"
                          ? "bg-white text-stone-900 shadow-sm"
                          : "text-stone-600"
                      }`}
                    >
                      Answer Key & Marking Scheme
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleCopyPaper}
                      className="ios-glass-btn inline-flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-medium text-stone-700 cursor-pointer"
                    >
                      {copiedPaper ? (
                        <Check className="w-3.5 h-3.5 text-emerald-700" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>{copiedPaper ? "Copied" : "Copy"}</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleDownloadPaper}
                      className="ios-glass-btn inline-flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-medium text-stone-700 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download .md</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="ios-glass-btn-primary inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-semibold cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Print Paper</span>
                    </button>
                  </div>
                </div>

                <div className="editorial-prose max-w-prose">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {activeMarkdown}
                  </ReactMarkdown>
                </div>
              </article>

              <aside className="no-print lg:col-span-3 ios-glass-card rounded-3xl p-5 space-y-3">
                <h3 className="font-display text-base font-semibold text-stone-900">
                  Saved Papers Archive
                </h3>
                <div className="space-y-2.5">
                  {savedPapers.map((p) => (
                    <div
                      key={p.id}
                      className={`rounded-2xl p-3.5 border transition-colors ${
                        activePaper.id === p.id
                          ? "bg-stone-900 text-white border-stone-900"
                          : "bg-white/70 border-slate-200/70 text-stone-900"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => setActivePaper(p)}
                          className="text-left flex-1 cursor-pointer"
                        >
                          <p
                            className={`text-[11px] font-mono-tabular ${
                              activePaper.id === p.id
                                ? "text-stone-300"
                                : "text-stone-500"
                            }`}
                          >
                            {p.studentClass} · {p.subject} · {p.totalMarks}M
                          </p>
                          <p className="text-xs font-semibold mt-0.5 line-clamp-2">
                            {p.title}
                          </p>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeletePaper(p.id)}
                          className="text-stone-400 hover:text-red-500 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </aside>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: STUDENT TEST RESULTS */}
      {activeTab === "results" && (
        <section className="ios-glass-card rounded-3xl p-6 md:p-8 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl font-semibold text-stone-900">
              Student Test Submissions Ledger
            </h2>
            <span className="font-mono-tabular text-xs text-stone-500">
              {submissions.length} submissions
            </span>
          </div>

          {submissions.length === 0 ? (
            <p className="text-xs text-stone-500 py-8 text-center">
              Once students submit any of your published tests on the KVS Tests
              page, their scores appear here automatically.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-stone-500">
                    <th className="py-3 px-3 font-semibold">Student Name</th>
                    <th className="py-3 px-3 font-semibold">Roll / Sec</th>
                    <th className="py-3 px-3 font-semibold">Class</th>
                    <th className="py-3 px-3 font-semibold">Test</th>
                    <th className="py-3 px-3 font-semibold text-right">
                      Score
                    </th>
                    <th className="py-3 px-3 font-semibold text-right">
                      Submitted
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200/60">
                  {submissions.map((s) => {
                    const testObj = publishedTests.find(
                      (t) => t.id === s.testId
                    );
                    const pct =
                      s.totalMarks > 0
                        ? Math.round((s.score / s.totalMarks) * 100)
                        : 0;
                    return (
                      <tr key={s.id}>
                        <td className="py-3 px-3 font-semibold text-stone-900">
                          {s.studentName}
                        </td>
                        <td className="py-3 px-3 text-stone-600">
                          {s.rollNumber || "—"}
                        </td>
                        <td className="py-3 px-3 text-stone-600">
                          {s.studentClass}
                        </td>
                        <td className="py-3 px-3 text-stone-800">
                          {testObj?.title || s.testId}
                        </td>
                        <td className="py-3 px-3 text-right font-mono-tabular font-semibold text-stone-900">
                          {s.score}/{s.totalMarks} ({pct}%)
                        </td>
                        <td className="py-3 px-3 text-right font-mono-tabular text-stone-500">
                          {new Date(s.submittedAt).toLocaleString()}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}
      </main>
    </div>
  );
};
