import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  ClipboardCheck,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  ArrowRight,
  MessageSquare,
  RefreshCw,
  KeyRound,
  Lock,
} from "lucide-react";
import {
  STUDENT_CLASSES,
  type StudentClass,
} from "../data/syllabusCatalog";
import { safeJsonResponse } from "../utils/freeLocalChat";
import type {
  StudentIdentity,
  StudentProfileContext,
  StudentTest,
} from "../types";

interface PublicTestSummary {
  id: string;
  title: string;
  studentClass: StudentClass;
  subject: string;
  chapter: string;
  durationMinutes: number;
  createdBy: string;
  createdAt: string;
  questionCount?: number;
}

interface StudentTestsPageProps {
  studentContext: StudentProfileContext;
  studentIdentity?: StudentIdentity | null;
  onAskDoubtInAiChat: (promptText: string) => void;
  onOpenTeacherLogin?: () => void;
}

interface GradedItem {
  questionId: string;
  question: string;
  options: [string, string, string, string];
  selectedIndex: number;
  correctIndex: number;
  isCorrect: boolean;
  marks: number;
  explanation: string;
}

export const StudentTestsPage: React.FC<StudentTestsPageProps> = ({
  studentContext,
  studentIdentity,
  onAskDoubtInAiChat,
  onOpenTeacherLogin,
}) => {
  const [tests, setTests] = useState<PublicTestSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterClass, setFilterClass] = useState<"All" | StudentClass>("All");

  // Enter Code to Start Exam
  const [testCodeInput, setTestCodeInput] = useState("");
  const [joining, setJoining] = useState(false);
  const [joinError, setJoinError] = useState<string | null>(null);
  const codeInputRef = useRef<HTMLInputElement | null>(null);

  // Active Exam Attempt State
  const [activeTest, setActiveTest] = useState<StudentTest | null>(null);
  const [secondsLeft, setSecondsLeft] = useState<number>(0);
  const [studentName, setStudentName] = useState(studentIdentity?.name || "");
  const [rollNumber, setRollNumber] = useState(
    studentIdentity?.studentId || ""
  );
  const [answers, setAnswers] = useState<number[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [result, setResult] = useState<{
    score: number;
    totalMarks: number;
    review: GradedItem[];
  } | null>(null);

  const loadTests = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/tests");
      const data = await safeJsonResponse<{ tests?: PublicTestSummary[] }>(res);
      if (data && Array.isArray(data.tests)) {
        setTests(data.tests);
      }
    } catch {
      // Ignore fetch hiccups gracefully
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTests();
  }, []);

  // Live exam countdown timer
  useEffect(() => {
    if (!activeTest || result || secondsLeft <= 0) return;
    const timer = window.setInterval(() => {
      setSecondsLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [activeTest, result, secondsLeft]);

  const filteredTests = useMemo(() => {
    if (filterClass === "All") return tests;
    return tests.filter((t) => t.studentClass === filterClass);
  }, [tests, filterClass]);

  const handleJoinByCode = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = testCodeInput.trim().toUpperCase();
    if (!clean || joining) return;

    setJoining(true);
    setJoinError(null);
    try {
      const res = await fetch("/api/tests/join", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ testCode: clean }),
      });
      const data = await safeJsonResponse<{
        test?: StudentTest;
        error?: string;
      }>(res);
      if (!res.ok || !data?.test) {
        throw new Error(
          data?.error || "Exam joining requires server mode or a valid code."
        );
      }
      const joinedTest = data.test;
      setActiveTest(joinedTest);
      setAnswers(new Array(joinedTest.questions.length).fill(-1));
      setSecondsLeft((joinedTest.durationMinutes || 20) * 60);
      setResult(null);
      setSubmitError(null);
    } catch (err) {
      setJoinError(
        err instanceof Error ? err.message : "Could not start exam."
      );
    } finally {
      setJoining(false);
    }
  };

  const handleSubmitTest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTest || submitting) return;
    if (!studentName.trim()) {
      setSubmitError("Please enter your full name before submitting.");
      return;
    }

    setSubmitting(true);
    setSubmitError(null);
    try {
      const res = await fetch(`/api/tests/${activeTest.id}/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          studentId: studentIdentity?.studentId,
          studentName: studentName.trim(),
          rollNumber: rollNumber.trim() || studentIdentity?.studentId || "",
          answers,
        }),
      });
      const data = await safeJsonResponse<{
        submission?: { score: number; totalMarks: number };
        review?: GradedItem[];
        error?: string;
      }>(res);
      if (!res.ok || !data?.submission) {
        throw new Error(data?.error || "Could not submit test.");
      }
      setResult({
        score: data.submission.score,
        totalMarks: data.submission.totalMarks,
        review: data.review || [],
      });
    } catch (err) {
      setSubmitError(
        err instanceof Error ? err.message : "Test submission failed."
      );
    } finally {
      setSubmitting(false);
    }
  };

  const formatTimer = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${String(mins).padStart(2, "0")}:${String(rem).padStart(2, "0")}`;
  };

  if (activeTest) {
    return (
      <div className="page-transition-enter max-w-4xl mx-auto px-3.5 sm:px-6 py-5 sm:py-8 space-y-5 sm:space-y-6">
        <div className="ios-glass-card rounded-3xl p-4 sm:p-6 md:p-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs font-medium text-stone-500">
              {activeTest.studentClass} CBSE · {activeTest.subject} · Code{" "}
              <span className="font-mono-tabular font-semibold text-stone-900">
                {activeTest.testCode}
              </span>
            </p>
            <h1 className="font-display text-2xl font-semibold text-stone-900 mt-1">
              {activeTest.title}
            </h1>
          </div>

          <div className="flex items-center gap-3">
            {!result && (
              <div className="ios-glass-subtle inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-mono-tabular font-semibold text-stone-900">
                <Clock className="w-3.5 h-3.5 text-blue-700" />
                <span>{formatTimer(secondsLeft)}</span>
              </div>
            )}
            <button
              type="button"
              onClick={() => {
                setActiveTest(null);
                setResult(null);
              }}
              className="ios-glass-btn px-4 py-2 rounded-2xl text-xs font-medium text-stone-800 cursor-pointer"
            >
              Exit Exam
            </button>
          </div>
        </div>

        {result ? (
          <div className="space-y-6">
            <div className="ios-glass-card rounded-3xl p-6 md:p-8 flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="text-xs font-medium text-emerald-700">
                  Exam Submitted & Auto-Graded
                </p>
                <h2 className="font-display text-2xl font-semibold text-stone-900 mt-1">
                  {studentName}:{" "}
                  <span className="font-mono-tabular">
                    {result.score} / {result.totalMarks}
                  </span>{" "}
                  Marks
                </h2>
              </div>

              <button
                type="button"
                onClick={() => {
                  const wrong = result.review
                    .filter((r) => !r.isCorrect)
                    .map((r) => r.question)
                    .slice(0, 3);
                  const prompt =
                    wrong.length > 0
                      ? `I just finished ${activeTest.title} (${activeTest.studentClass} ${activeTest.subject}) and got these questions wrong. Please explain them step by step:\n- ${wrong.join(
                          "\n- "
                        )}`
                      : `Explain the key concepts from ${activeTest.title} (${activeTest.studentClass} ${activeTest.subject}) with extra practice tips.`;
                  onAskDoubtInAiChat(prompt);
                }}
                className="ios-glass-btn-blue inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-semibold cursor-pointer whitespace-nowrap"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Clear Doubts in AI Chat</span>
              </button>
            </div>

            <div className="space-y-4">
              {result.review.map((item, idx) => (
                <article
                  key={item.questionId}
                  className="ios-glass-card rounded-3xl p-6 space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="text-sm font-semibold text-stone-900">
                      Q{idx + 1}. {item.question}
                    </h3>
                    <span
                      className={`inline-flex items-center gap-1 text-xs font-semibold shrink-0 ${
                        item.isCorrect ? "text-emerald-700" : "text-red-700"
                      }`}
                    >
                      {item.isCorrect ? (
                        <>
                          <CheckCircle2 className="w-4 h-4" />
                          <span>+{item.marks}</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="w-4 h-4" />
                          <span>0/{item.marks}</span>
                        </>
                      )}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {item.options.map((opt, oIdx) => {
                      const isCorrectOpt = oIdx === item.correctIndex;
                      const isChosenOpt = oIdx === item.selectedIndex;
                      return (
                        <div
                          key={oIdx}
                          className={`px-3.5 py-2.5 rounded-2xl border ${
                            isCorrectOpt
                              ? "border-emerald-300 bg-emerald-50/90 text-emerald-950 font-medium"
                              : isChosenOpt
                              ? "border-red-300 bg-red-50/90 text-red-900"
                              : "border-slate-200/70 bg-white/60 text-stone-600"
                          }`}
                        >
                          {String.fromCharCode(65 + oIdx)}. {opt}
                        </div>
                      );
                    })}
                  </div>

                  <p className="text-xs text-stone-700 leading-relaxed pt-1">
                    <strong>Explanation:</strong> {item.explanation}
                  </p>
                </article>
              ))}
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmitTest} className="space-y-6">
            <div className="ios-glass-card rounded-3xl p-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Student Full Name
                </label>
                <input
                  type="text"
                  required
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="Enter your full name"
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-sm text-stone-900 focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Roll Number / Section
                </label>
                <input
                  type="text"
                  value={rollNumber}
                  onChange={(e) => setRollNumber(e.target.value)}
                  placeholder="e.g., 10-A / Roll 24"
                  className="w-full rounded-2xl border border-slate-200/80 bg-white/80 px-3.5 py-2.5 text-sm text-stone-900 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="space-y-4">
              {activeTest.questions.map((q, qIdx) => (
                <article
                  key={q.id}
                  className="ios-glass-card rounded-3xl p-6 space-y-3"
                >
                  <div className="flex items-start justify-between gap-4">
                    <h3 className="text-sm font-semibold text-stone-900">
                      Q{qIdx + 1}. {q.question}
                    </h3>
                    <span className="font-mono-tabular text-xs text-stone-500 shrink-0">
                      [{q.marks}M]
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {q.options.map((opt, oIdx) => {
                      const selected = answers[qIdx] === oIdx;
                      return (
                        <button
                          key={oIdx}
                          type="button"
                          onClick={() =>
                            setAnswers((prev) => {
                              const next = [...prev];
                              next[qIdx] = oIdx;
                              return next;
                            })
                          }
                          className={`text-left px-4 py-3 rounded-2xl text-xs font-medium transition-all cursor-pointer ${
                            selected
                              ? "ios-glass-btn-blue"
                              : "ios-glass-btn text-stone-800"
                          }`}
                        >
                          {String.fromCharCode(65 + oIdx)}. {opt}
                        </button>
                      );
                    })}
                  </div>
                </article>
              ))}
            </div>

            {submitError && (
              <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-800">
                {submitError}
              </div>
            )}

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={submitting}
                className="ios-glass-btn-primary inline-flex items-center gap-2 px-6 py-3 rounded-2xl text-sm font-semibold disabled:opacity-50 cursor-pointer"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Submitting Exam...</span>
                  </>
                ) : (
                  <>
                    <ClipboardCheck className="w-4 h-4" />
                    <span>Submit Exam</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    );
  }

  return (
    <div className="page-transition-enter max-w-[1380px] mx-auto px-3.5 sm:px-6 py-5 sm:py-8 space-y-6 sm:space-y-8">
      {/* Enter Test Code to Start Exam Hero Card */}
      <section className="ios-glass-card rounded-3xl p-4 sm:p-6 md:p-8 space-y-5 sm:space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-xs font-medium text-stone-500">
              Student Exam Portal · Open Access · {studentContext.studentClass}{" "}
              CBSE
            </p>
            <h1 className="font-display text-2xl md:text-3xl font-semibold text-stone-900 mt-1 text-balance">
              Enter Exam Code to Start Test
            </h1>
            <p className="mt-1.5 text-sm text-stone-600 max-w-2xl">
              Enter the KVS test code generated by T.Sreenivas Rao Sir to unlock
              and start your timed exam right away.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={loadTests}
              className="ios-glass-btn inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-medium text-stone-800 cursor-pointer whitespace-nowrap"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Refresh</span>
            </button>

            {onOpenTeacherLogin && (
              <button
                type="button"
                onClick={onOpenTeacherLogin}
                className="ios-glass-btn-primary px-4 py-2 rounded-2xl text-xs font-medium cursor-pointer whitespace-nowrap"
              >
                Teacher Login
              </button>
            )}
          </div>
        </div>

        <form
          onSubmit={handleJoinByCode}
          className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 max-w-xl"
        >
          <div className="relative flex-1">
            <KeyRound className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              ref={codeInputRef}
              type="text"
              value={testCodeInput}
              onChange={(e) => {
                setTestCodeInput(e.target.value.toUpperCase());
                setJoinError(null);
              }}
              placeholder="Enter Test Code (e.g. KVS-4821)"
              className="w-full pl-10 pr-4 py-3 rounded-2xl border border-slate-200/80 bg-white/85 text-sm font-mono-tabular font-semibold tracking-wider text-stone-900 placeholder:font-sans placeholder:font-normal placeholder:tracking-normal placeholder:text-stone-400 focus:outline-none focus:border-blue-500"
            />
          </div>

          <button
            type="submit"
            disabled={joining || !testCodeInput.trim()}
            className="ios-glass-btn-blue inline-flex items-center justify-center gap-2 px-6 py-3 rounded-2xl text-sm font-semibold disabled:opacity-45 cursor-pointer whitespace-nowrap"
          >
            {joining ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Starting Exam...</span>
              </>
            ) : (
              <>
                <span>Start Exam</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {joinError && (
          <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-800 max-w-xl">
            {joinError}
          </div>
        )}
      </section>

      {/* Class Filter + Published KVS Exam Directory */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <h2 className="font-display text-lg font-semibold text-stone-900">
            Scheduled KVS Class Tests
          </h2>
          <div className="flex flex-wrap items-center gap-2">
            {(["All", ...STUDENT_CLASSES] as const).map((cls) => (
              <button
                key={cls}
                type="button"
                onClick={() => setFilterClass(cls)}
                className={`px-3 py-1.5 rounded-2xl text-xs font-medium cursor-pointer whitespace-nowrap ${
                  filterClass === cls
                    ? "ios-glass-btn-primary"
                    : "ios-glass-btn text-stone-700"
                }`}
              >
                {cls}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="ios-glass-card rounded-3xl p-10 text-center text-xs text-stone-500 flex items-center justify-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Checking scheduled KVS exams...</span>
          </div>
        ) : filteredTests.length === 0 ? (
          <div className="ios-glass-card rounded-3xl p-10 text-center space-y-2">
            <p className="font-display text-lg font-medium text-stone-900">
              No exams scheduled for {filterClass} yet
            </p>
            <p className="text-xs text-stone-600 max-w-md mx-auto">
              Once your teacher prepares a test and shares the Test Code, enter
              it above to begin your exam.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTests.map((t) => (
              <article
                key={t.id}
                className="ios-glass-card rounded-3xl p-6 flex flex-col justify-between gap-4"
              >
                <div>
                  <div className="text-[11px] font-mono-tabular text-stone-500 mb-1.5">
                    {t.studentClass} · {t.subject}
                    {t.chapter ? ` · ${t.chapter}` : ""}
                  </div>
                  <h3 className="font-display text-lg font-semibold text-stone-900">
                    {t.title}
                  </h3>
                  <div className="mt-2 flex items-center gap-3 text-xs text-stone-600">
                    <span className="font-mono-tabular">
                      {t.questionCount ?? 0} Questions
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="inline-flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{t.durationMinutes} min</span>
                    </span>
                  </div>
                  <p className="mt-1.5 text-[11px] text-stone-500">
                    Set by {t.createdBy} (KVS)
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    codeInputRef.current?.focus();
                    codeInputRef.current?.scrollIntoView({
                      behavior: "smooth",
                      block: "center",
                    });
                  }}
                  className="ios-glass-btn inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-semibold text-stone-800 cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5 text-stone-600" />
                  <span>Enter Code Above to Attempt</span>
                </button>
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
