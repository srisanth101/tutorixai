import React, { useState } from "react";
import {
  Check,
  Copy,
  GraduationCap,
  IdCard,
  Loader2,
  LogOut,
  ShieldCheck,
  User,
  X,
} from "lucide-react";
import { STUDENT_CLASSES, type StudentClass } from "../data/syllabusCatalog";
import { safeJsonResponse } from "../utils/freeLocalChat";
import type { StudentIdentity } from "../types";

interface StudentOnboardingModalProps {
  existingProfile: StudentIdentity | null;
  defaultClass: StudentClass;
  onComplete: (profile: StudentIdentity) => void;
  onLogout?: () => void;
  onOpenTeacherLogin?: () => void;
  onClose?: () => void;
}

const INDIA_BOARDS = [
  "CBSE",
  "ICSE / ISC",
  "State Board",
  "NIOS / IB",
] as const;

function buildFallbackStudentId(
  name: string,
  board: string,
  studentClass: string
): string {
  const seed = `${name.trim().toLowerCase()}|${board.trim().toLowerCase()}|${studentClass}`;
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash * 31 + seed.charCodeAt(i)) % 90000;
  }
  const num = 10000 + Math.abs(hash);
  return `SS-IND-${num}`;
}

export const StudentOnboardingModal: React.FC<StudentOnboardingModalProps> = ({
  existingProfile,
  defaultClass,
  onComplete,
  onLogout,
  onOpenTeacherLogin,
  onClose,
}) => {
  const [name, setName] = useState(existingProfile?.name || "");
  const [board, setBoard] = useState<string>(existingProfile?.board || "CBSE");
  const [studentClass, setStudentClass] = useState<StudentClass>(
    existingProfile?.studentClass || defaultClass
  );
  const [isKvStudent, setIsKvStudent] = useState<boolean>(
    Boolean(existingProfile?.isKvStudent)
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  const handleCopyId = () => {
    if (!existingProfile?.studentId) return;
    navigator.clipboard?.writeText(existingProfile.studentId).catch(() => {});
    setCopiedId(true);
    window.setTimeout(() => setCopiedId(false), 1800);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    const cleanBoard = board.trim() || "CBSE";
    if (!cleanName) {
      setError("Please enter your name.");
      return;
    }

    setSaving(true);
    setError(null);
    try {
      const res = await fetch("/api/student/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: cleanName,
          board: cleanBoard,
          studentClass,
          existingStudentId: existingProfile?.studentId,
          isKvStudent,
        }),
      });
      const data = await safeJsonResponse<{ profile?: StudentIdentity }>(res);
      if (res.ok && data?.profile) {
        onComplete(data.profile);
        return;
      }
    } catch {
      // Fallback gracefully so students across India always get instant access
    } finally {
      setSaving(false);
    }

    onComplete({
      studentId:
        existingProfile?.studentId ||
        buildFallbackStudentId(cleanName, cleanBoard, studentClass),
      name: cleanName,
      board: cleanBoard,
      studentClass,
      isKvStudent,
      createdAt: existingProfile?.createdAt || new Date().toISOString(),
    });
  };

  return (
    <div className="fixed inset-0 z-50 ios-app-bg/95 backdrop-blur-2xl flex items-center justify-center p-4 overflow-y-auto">
      <div className="page-transition-enter ios-glass-card w-full max-w-md rounded-3xl p-6 sm:p-8 space-y-5 shadow-2xl border border-white/80 my-auto">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <img
              src="/assets/aistudio/image_555f3288.png"
              alt="Tutorix AI logo"
              referrerPolicy="no-referrer"
              className="w-11 h-11 rounded-2xl shadow-sm object-cover shrink-0"
            />
            <div>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-200/80">
                All India · Classes 6–12
              </span>
              <h1 className="font-display text-xl sm:text-2xl font-semibold text-stone-900 mt-0.5">
                {existingProfile
                  ? "Your Profile & Fixed ID"
                  : "Welcome to Tutorix AI"}
              </h1>
            </div>
          </div>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              aria-label="Close profile dialog"
              className="p-2 rounded-xl text-stone-400 hover:text-stone-800 hover:bg-stone-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {existingProfile?.studentId && (
          <div className="space-y-2">
            <div className="rounded-2xl border border-indigo-200/80 bg-indigo-50/80 px-4 py-3 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <IdCard className="w-5 h-5 text-indigo-700 shrink-0" />
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-indigo-700">
                    Fixed Student ID
                  </p>
                  <p className="font-mono-tabular text-sm font-bold text-stone-900">
                    {existingProfile.studentId}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleCopyId}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white border border-indigo-200 text-xs font-medium text-indigo-700 hover:bg-indigo-100/60 cursor-pointer"
              >
                {copiedId ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy ID</span>
                  </>
                )}
              </button>
            </div>

            {onLogout && (
              <button
                type="button"
                onClick={onLogout}
                className="w-full py-2.5 px-4 rounded-2xl border border-red-200 bg-red-50 hover:bg-red-100 text-xs font-semibold text-red-700 flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out / Log Out (Clear Student Session)</span>
              </button>
            )}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* 1. Name */}
          <div>
            <label
              htmlFor="onboard-student-name"
              className="block text-xs font-semibold text-stone-700 mb-1.5"
            >
              Your Name
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="onboard-student-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name"
                autoFocus
                className="w-full pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200/90 bg-white/90 text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* 2. Board */}
          <div>
            <span className="block text-xs font-semibold text-stone-700 mb-1.5">
              Board
            </span>
            <div className="grid grid-cols-2 gap-2">
              {INDIA_BOARDS.map((b) => (
                <button
                  key={b}
                  type="button"
                  onClick={() => setBoard(b)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
                    board === b
                      ? "ios-glass-btn-blue"
                      : "ios-glass-btn text-stone-700"
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>

          {/* 3. Class */}
          <div>
            <span className="block text-xs font-semibold text-stone-700 mb-1.5">
              Class
            </span>
            <div className="flex flex-wrap gap-1.5">
              {STUDENT_CLASSES.map((cls) => (
                <button
                  key={cls}
                  type="button"
                  onClick={() => setStudentClass(cls)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
                    studentClass === cls
                      ? "ios-glass-btn-primary"
                      : "ios-glass-btn text-stone-700"
                  }`}
                >
                  {cls}
                </button>
              ))}
            </div>
          </div>

          {/* 4. KV Student Checkbox */}
          <div>
            <label className="flex items-center gap-3 p-3 rounded-2xl border border-blue-200/80 bg-blue-50/50 cursor-pointer text-xs font-semibold text-stone-800 hover:bg-blue-50 transition-colors">
              <input
                type="checkbox"
                checked={isKvStudent}
                onChange={(e) => setIsKvStudent(e.target.checked)}
                className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
              />
              <span>I am a Kendriya Vidyalaya (KV) Student (Enables KVS Tests)</span>
            </label>
          </div>

          {error && (
            <div className="rounded-2xl border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs text-red-800">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={saving}
            className="ios-glass-btn-primary w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl text-sm font-semibold disabled:opacity-50 cursor-pointer"
          >
            {saving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Starting...</span>
              </>
            ) : (
              <>
                <GraduationCap className="w-4 h-4" />
                <span>{existingProfile ? "Save Changes" : "Start Studying"}</span>
              </>
            )}
          </button>
        </form>

        <div className="pt-3 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="text-stone-500">
            Fixed Student ID stays saved automatically.
          </span>
          {onOpenTeacherLogin && (
            <button
              type="button"
              onClick={onOpenTeacherLogin}
              className="inline-flex items-center gap-1 font-semibold text-stone-700 hover:text-blue-700 cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Teacher Login</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
