import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  CheckCircle2,
  Copy,
  Check,
  Download,
  ExternalLink,
  Printer,
  AlertTriangle,
  FileText,
  ArrowRight,
  MessageSquare,
} from "lucide-react";
import type { CrewPhase, GroundedSource, ResearchClaim } from "../types";

interface MarkdownReportViewProps {
  topic: string;
  phase: CrewPhase;
  reportMarkdown: string;
  claims: ResearchClaim[];
  sources: GroundedSource[];
  visualBrief: string | null;
  completedAt: string | null;
  onGoToNewsroom: () => void;
  onAskTopicInChat?: (prompt: string) => void;
}

function extractNodeText(node: React.ReactNode): string {
  if (typeof node === "string" || typeof node === "number") {
    return String(node);
  }
  if (Array.isArray(node)) {
    return node.map(extractNodeText).join("");
  }
  if (React.isValidElement<{ children?: React.ReactNode }>(node)) {
    return extractNodeText(node.props.children);
  }
  return "";
}

export const MarkdownReportView: React.FC<MarkdownReportViewProps> = ({
  topic,
  phase,
  reportMarkdown,
  claims,
  sources,
  visualBrief,
  completedAt,
  onGoToNewsroom,
  onAskTopicInChat,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    if (!reportMarkdown) return;
    try {
      await navigator.clipboard.writeText(reportMarkdown);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard fallback ignored cleanly
    }
  };

  const handleDownload = () => {
    if (!reportMarkdown) return;
    const slug = (topic || "veritas-report")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 48);
    const blob = new Blob([reportMarkdown], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${slug || "veritas-dossier"}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  if (!reportMarkdown && phase !== "finalizing") {
    return (
      <div className="max-w-3xl mx-auto py-16 px-6 text-center">
        <div className="ios-glass-card w-12 h-12 mx-auto mb-5 rounded-2xl flex items-center justify-center text-stone-600">
          <FileText className="w-5 h-5" />
        </div>
        <h2 className="font-display text-2xl font-semibold text-stone-900">
          No Study Notes Compiled Yet
        </h2>
        <p className="mt-2.5 text-sm text-stone-600 max-w-md mx-auto leading-relaxed">
          Pick any Class (6–12) CBSE chapter on the Syllabus page and run the
          Study Loop to generate neat, easy-to-understand study notes here.
        </p>
        <button
          type="button"
          onClick={onGoToNewsroom}
          className="ios-glass-btn-primary mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl text-sm font-medium cursor-pointer"
        >
          <span>Go to Study Loop</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    );
  }

  const verifiedClaims = claims.filter((c) => c.status === "verified").length;
  const correctedClaims = claims.filter((c) => c.status === "corrected").length;
  const disputedClaims = claims.filter((c) => c.status === "disputed").length;

  return (
    <div className="max-w-[1280px] mx-auto px-3.5 sm:px-6 py-5 sm:py-8">
      {/* Editorial Utility Strip */}
      <div className="no-print flex flex-wrap items-center justify-between gap-4 pb-5 mb-8 border-b border-stone-200">
        <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500">
          <span className="font-medium text-stone-900">
            Student Study Notes
          </span>
          <span aria-hidden="true">·</span>
          <span>
            {phase === "finalizing"
              ? "Study Coach compiling neat notes"
              : completedAt
              ? `Ready at ${new Date(completedAt).toLocaleTimeString([], {
                  hour: "2-digit",
                  minute: "2-digit",
                })}`
              : "Draft in progress"}
          </span>
          <span aria-hidden="true">·</span>
          <span className="font-mono-tabular">
            {sources.length} verified study links
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopy}
            disabled={!reportMarkdown}
            className="ios-glass-btn inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-medium text-stone-700 disabled:opacity-40 cursor-pointer whitespace-nowrap"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-700" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Markdown</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleDownload}
            disabled={!reportMarkdown}
            className="ios-glass-btn inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-medium text-stone-700 disabled:opacity-40 cursor-pointer whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download .md</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            disabled={!reportMarkdown}
            className="ios-glass-btn-primary inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-medium disabled:opacity-40 cursor-pointer whitespace-nowrap"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Brief</span>
          </button>
        </div>
      </div>

      {/* Asymmetric 70% / 30% Publication Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Main Reading Sheet (Optimal 65-75ch Measure) */}
        <article className="lg:col-span-8 ios-glass-card rounded-3xl p-8 md:p-12">
          <div className="mb-6 flex flex-wrap items-center gap-2 text-xs text-stone-500">
            <span>Managing Editor: Clara Lin</span>
            <span aria-hidden="true">·</span>
            <span>Research: Elena Vance</span>
            <span aria-hidden="true">·</span>
            <span>Fact-Check: Marcus Thorne</span>
          </div>

          <div className="editorial-prose max-w-prose">
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              components={{
                h2: ({ children }) => {
                  const text = extractNodeText(children).trim();
                  return (
                    <div className="flex flex-wrap items-center justify-between gap-2 mt-8 mb-2 pb-1.5 border-b border-stone-200">
                      <h2 className="!m-0 !p-0 !border-0">{children}</h2>
                      {onAskTopicInChat && text && (
                        <button
                          type="button"
                          onClick={() =>
                            onAskTopicInChat(
                              `I am reading my study notes on "${topic || "this lesson"}". I didn't understand "${text}". Please explain it simply step by step!`
                            )
                          }
                          className="no-print inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 cursor-pointer whitespace-nowrap"
                        >
                          <MessageSquare className="w-3 h-3" />
                          <span>Ask AI Chat</span>
                        </button>
                      )}
                    </div>
                  );
                },
                h3: ({ children }) => {
                  const text = extractNodeText(children).trim();
                  return (
                    <div className="flex flex-wrap items-center justify-between gap-2 mt-5 mb-1.5">
                      <h3 className="!m-0">{children}</h3>
                      {onAskTopicInChat && text && (
                        <button
                          type="button"
                          onClick={() =>
                            onAskTopicInChat(
                              `I am reading my study notes on "${topic || "this lesson"}". I didn't understand "${text}". Please explain it clearly with an example!`
                            )
                          }
                          className="no-print inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/75 cursor-pointer whitespace-nowrap"
                        >
                          <MessageSquare className="w-2.5 h-2.5" />
                          <span>Ask AI Chat</span>
                        </button>
                      )}
                    </div>
                  );
                },
                a: ({ href, children }) => (
                  <a
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    {children}
                  </a>
                ),
              }}
            >
              {reportMarkdown || "_Synthesizing report stream..._"}
            </ReactMarkdown>
          </div>
        </article>

        {/* Margin Rail: Audit Ledger & Verified Sources */}
        <aside className="lg:col-span-4 space-y-6 no-print">
          {/* Verification Audit Summary */}
          <section className="ios-glass-card rounded-3xl p-5">
            <h3 className="font-display text-base font-semibold text-stone-900">
              Verification Audit
            </h3>
            <p className="mt-1 text-xs text-stone-500">
              Claims cross-examined by Marcus Thorne prior to publication.
            </p>

            <dl className="mt-4 divide-y divide-stone-100 text-xs">
              <div className="py-2.5 flex items-center justify-between">
                <dt className="text-stone-600 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Independently Verified</span>
                </dt>
                <dd className="font-mono-tabular font-semibold text-stone-900">
                  {verifiedClaims}
                </dd>
              </div>
              <div className="py-2.5 flex items-center justify-between">
                <dt className="text-stone-600 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-700" />
                  <span>Calibrated in Loop</span>
                </dt>
                <dd className="font-mono-tabular font-semibold text-stone-900">
                  {correctedClaims}
                </dd>
              </div>
              {disputedClaims > 0 && (
                <div className="py-2.5 flex items-center justify-between">
                  <dt className="text-stone-600">Open Disputes</dt>
                  <dd className="font-mono-tabular font-semibold text-red-700">
                    {disputedClaims}
                  </dd>
                </div>
              )}
              <div className="py-2.5 flex items-center justify-between">
                <dt className="text-stone-600">Grounded Web Sources</dt>
                <dd className="font-mono-tabular font-semibold text-stone-900">
                  {sources.length}
                </dd>
              </div>
            </dl>
          </section>

          {visualBrief && (
            <section className="ios-glass-card rounded-3xl p-5">
              <h3 className="font-display text-base font-semibold text-stone-900">
                Visual Evidence Notes
              </h3>
              <p className="mt-2 text-xs text-stone-600 leading-relaxed whitespace-pre-line">
                {visualBrief.slice(0, 520)}
                {visualBrief.length > 520 ? "..." : ""}
              </p>
            </section>
          )}

          {/* Grounded Bibliography */}
          <section className="ios-glass-card rounded-3xl p-5">
            <h3 className="font-display text-base font-semibold text-stone-900">
              Grounded Source Index
            </h3>
            <p className="mt-1 text-xs text-stone-500">
              Live URLs retrieved via Google Search grounding.
            </p>

            {sources.length === 0 ? (
              <p className="mt-4 text-xs text-stone-500">
                No external source links attached to this briefing yet.
              </p>
            ) : (
              <ol className="mt-4 space-y-3">
                {sources.map((src) => (
                  <li
                    key={src.url}
                    className="pb-3 border-b border-stone-100 last:border-b-0 last:pb-0"
                  >
                    <a
                      href={src.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group flex items-start gap-2.5 text-xs"
                    >
                      <span className="font-mono-tabular text-stone-400 shrink-0 mt-0.5">
                        [{src.id}]
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="font-medium text-stone-800 group-hover:text-blue-700 group-hover:underline leading-snug break-words">
                          {src.title}
                        </p>
                        <p className="mt-0.5 text-[11px] text-stone-500 flex items-center gap-1">
                          <span className="truncate">{src.domain}</span>
                          <ExternalLink className="w-3 h-3 shrink-0" />
                        </p>
                      </div>
                    </a>
                  </li>
                ))}
              </ol>
            )}
          </section>
        </aside>
      </div>
    </div>
  );
};
