import React, { useEffect, useMemo, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  Search,
  ShieldCheck,
  PenLine,
  Play,
  Square,
  ImagePlus,
  X,
  ScanEye,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  CircleDot,
  Loader2,
  ArrowRight,
  BookOpen,
  MessageSquare,
  Send,
  Sparkles,
  ListChecks,
  Layers,
  Calculator,
  Lightbulb,
  Globe,
  RefreshCw,
} from "lucide-react";
import { LessonStage3D, findMatchingSimulation } from "./LessonStage3D";
import { LessonStructureDiagramView } from "./LessonStructureDiagramView";
import {
  STUDENT_CLASSES,
  getSubjectsForClass,
  type StudentClass,
  type SyllabusLesson,
} from "../data/syllabusCatalog";
import { safeJsonResponse } from "../utils/freeLocalChat";
import {
  buildYoutubeThumbnailUrl,
  getCuratedYoutubeVideosForLesson,
} from "../utils/youtubeCurated";
import type {
  AgentId,
  CrewPhase,
  InvestigationState,
  StudentProfileContext,
  UploadedImagePayload,
  YoutubeVideoSuggestion,
} from "../types";

interface NewsroomWorkspaceProps {
  state: InvestigationState;
  studentContext: StudentProfileContext;
  lessons: SyllabusLesson[];
  onChangeStudentClass: (cls: StudentClass) => void;
  onChangeSubject: (subject: string) => void;
  onSelectLesson: (lesson: SyllabusLesson) => void;
  topicInput: string;
  setTopicInput: (val: string) => void;
  depth: "standard" | "deep";
  setDepth: (val: "standard" | "deep") => void;
  attachedImage: UploadedImagePayload | null;
  setAttachedImage: (img: UploadedImagePayload | null) => void;
  onStartInvestigation: (overrideTopic?: string) => void;
  onStopInvestigation: () => void;
  onOpenSyllabus: () => void;
  onExpand3DStage: () => void;
  onOpenReport: () => void;
  onOpenChat: () => void;
  onAskTopicInChat: (prompt: string) => void;
  overviewLoading?: boolean;
  onGenerateQuickOverview?: () => void;
  onNewTopic: () => void;
}

const PIPELINE_STEPS: Array<{ id: CrewPhase; label: string; agent: string }> = [
  { id: "planning", label: "01. Lesson Scope", agent: "Syllabus Map" },
  { id: "researching", label: "02. Web Research", agent: "NCERT + Search" },
  { id: "fact_checking", label: "03. Formula Audit", agent: "Fact Check" },
  { id: "self_correcting", label: "04. Simplification", agent: "Clarity Pass" },
  { id: "finalizing", label: "05. Master Guide", agent: "Printable Notes" },
];

function getPhaseOrder(phase: CrewPhase): number {
  const map: Record<CrewPhase, number> = {
    idle: -1,
    analyzing_image: 0,
    planning: 0,
    researching: 1,
    fact_checking: 2,
    self_correcting: 3,
    finalizing: 4,
    complete: 5,
    error: -1,
  };
  return map[phase];
}

function getAgentHeaderIcon(agentId: AgentId) {
  if (agentId === "researcher") {
    return <Search className="w-4 h-4 text-blue-700 shrink-0" />;
  }
  if (agentId === "fact_checker") {
    return <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0" />;
  }
  return <PenLine className="w-4 h-4 text-emerald-700 shrink-0" />;
}

function getStepRoleLabel(agentId: AgentId): string {
  if (agentId === "researcher") return "Gemini Syllabus Research";
  if (agentId === "fact_checker") return "Gemini Fact & Formula Check";
  return "Gemini Study Editor";
}

function extractNodeText(node: React.ReactNode): string {
  if (typeof node === "string" || typeof node === "number") {
    return String(node);
  }
  if (Array.isArray(node)) {
    return node.map(extractNodeText).join("");
  }
  if (React.isValidElement<{ children?: React.ReactNode }>(node)) {
    return extractNodeText(node.props.children);
  }
  return "";
}

export const NewsroomWorkspace: React.FC<NewsroomWorkspaceProps> = ({
  state,
  studentContext,
  lessons,
  onChangeStudentClass,
  onChangeSubject,
  onSelectLesson,
  topicInput,
  setTopicInput,
  depth,
  setDepth,
  attachedImage,
  setAttachedImage,
  onStartInvestigation,
  onStopInvestigation,
  onOpenSyllabus,
  onExpand3DStage,
  onOpenReport,
  onOpenChat,
  onAskTopicInChat,
  overviewLoading = false,
  onGenerateQuickOverview,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [imageAnalysisText, setImageAnalysisText] = useState<string | null>(null);
  const [analyzingImageOnly, setAnalyzingImageOnly] = useState(false);
  const [imageError, setImageError] = useState<string | null>(null);
  const [quickDoubtInput, setQuickDoubtInput] = useState("");
  const [showCustomPrompt, setShowCustomPrompt] = useState(false);
  const [liveYoutubeVideos, setLiveYoutubeVideos] = useState<
    YoutubeVideoSuggestion[]
  >([]);
  const [activeVideoModal, setActiveVideoModal] =
    useState<YoutubeVideoSuggestion | null>(null);
  const [failedThumbIds, setFailedThumbIds] = useState<Record<string, boolean>>(
    {}
  );

  // Fetch PW / Next Toppers / Magnet Brains YouTube video metadata safely (works both on localhost & Vercel static builds)
  useEffect(() => {
    let cancelled = false;
    const lessonName =
      studentContext.lessonTitle || lessons[0]?.title || studentContext.subject;
    const curated = getCuratedYoutubeVideosForLesson(studentContext, lessonName);
    setLiveYoutubeVideos(curated);

    const fetchVideos = async () => {
      try {
        const res = await fetch("/api/youtube/videos", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            studentContext,
            lessonTitle: lessonName,
          }),
        });
        if (!res.ok || cancelled) return;
        const data = await safeJsonResponse<{
          videos?: YoutubeVideoSuggestion[];
        }>(res);
        if (
          !cancelled &&
          data?.videos &&
          Array.isArray(data.videos) &&
          data.videos.length > 0
        ) {
          setLiveYoutubeVideos(data.videos);
        }
      } catch {
        // Keep instant curated PW / Next Toppers thumbnails smoothly
      }
    };

    void fetchVideos();
    return () => {
      cancelled = true;
    };
  }, [
    studentContext.studentClass,
    studentContext.subject,
    studentContext.lessonTitle,
  ]);

  const isRunning =
    state.phase !== "idle" &&
    state.phase !== "complete" &&
    state.phase !== "error";

  const currentPhaseIdx = getPhaseOrder(state.phase);
  const subjectsForClass = useMemo(
    () => getSubjectsForClass(studentContext.studentClass),
    [studentContext.studentClass]
  );

  // Only show 3D Stage when this specific lesson actually has a matching 3D simulation
  const matchedSim = useMemo(
    () => findMatchingSimulation(studentContext, topicInput),
    [studentContext.subject, studentContext.lessonTitle, topicInput]
  );

  const hasSidebarContent =
    Boolean(matchedSim) || state.claims.length > 0 || state.sources.length > 0;
  const hasDeepStudyContent =
    isRunning ||
    Boolean(state.reportMarkdown) ||
    state.messages.length > 0 ||
    state.phase === "complete";

  const askSpecificTopicInChat = (subtopicLabel: string) => {
    const lessonRef = studentContext.lessonTitle
      ? `${studentContext.studentClass} CBSE ${studentContext.subject} — "${studentContext.lessonTitle}"`
      : `${studentContext.studentClass} CBSE ${studentContext.subject}`;
    onAskTopicInChat(
      `I am studying ${lessonRef}. I didn't understand "${subtopicLabel}". Please explain this exact topic clearly in simple words with a daily-life example and key exam points!`
    );
  };

  const handleQuickDoubtSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = quickDoubtInput.trim();
    if (!cleaned) return;
    askSpecificTopicInChat(cleaned);
    setQuickDoubtInput("");
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setImageError("Please upload a valid image file (PNG, JPG, or WebP).");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || "");
      const base64 = result.split(",")[1] || "";
      setAttachedImage({
        mimeType: file.type,
        data: base64,
        name: file.name,
        previewUrl: result,
      });
      setImageAnalysisText(null);
      setImageError(null);
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleStandaloneImageScan = async () => {
    if (!attachedImage || analyzingImageOnly) return;
    setAnalyzingImageOnly(true);
    setImageError(null);
    try {
      const res = await fetch("/api/image/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          image: {
            mimeType: attachedImage.mimeType,
            data: attachedImage.data,
          },
          studentContext,
          prompt: topicInput.trim()
            ? `Explain this textbook page or diagram clearly in the context of: "${topicInput.trim()}".`
            : undefined,
        }),
      });
      const data = await safeJsonResponse<{ analysis?: string; error?: string }>(
        res
      );
      if (!res.ok || !data) {
        throw new Error(
          data?.error ||
            "Photo scanning requires backend server mode. Open AI Chat and type your question for instant free step-by-step help!"
        );
      }
      setImageAnalysisText(data.analysis || "");
    } catch (err) {
      setImageError(
        err instanceof Error ? err.message : "Image analysis failed."
      );
    } finally {
      setAnalyzingImageOnly(false);
    }
  };

  const detailSections = state.lessonOverview?.allDetailsSections || [];
  const displayedYoutubeVideos: YoutubeVideoSuggestion[] = useMemo(() => {
    if (liveYoutubeVideos.length > 0) return liveYoutubeVideos;
    return getCuratedYoutubeVideosForLesson(
      studentContext,
      studentContext.lessonTitle
    );
  }, [liveYoutubeVideos, studentContext]);

  return (
    <div className="page-transition-enter max-w-[1380px] mx-auto px-3.5 sm:px-6 py-5 sm:py-8 space-y-6">
      {/* 01. Gemini Study Loop Header & Lesson Switcher */}
      <section className="ios-glass-card rounded-3xl p-4 sm:p-6 md:p-7 space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs">
                <Sparkles className="w-3 h-3" />
                <span>Powered by Gemini</span>
              </span>
              <span className="text-xs font-medium text-stone-500">
                {studentContext.studentClass} · CBSE (NCERT) ·{" "}
                {studentContext.subject}
                {studentContext.lessonTitle
                  ? ` · ${studentContext.lessonTitle}`
                  : ""}
              </span>
            </div>
            <h1 className="font-display text-2xl md:text-3xl font-semibold text-stone-900 text-balance">
              {studentContext.lessonTitle
                ? `${studentContext.lessonTitle} — Complete Study Loop`
                : "Tutorix Study Loop — Complete Lesson Hub"}
            </h1>
            <p className="text-xs text-stone-500 max-w-2xl">
              Full chapter summary, key points, visual structure map, PW &amp;
              Next Toppers video lectures, and every topic explained
              step-by-step. Click <strong>Ask AI Chat</strong> on any part
              you don&apos;t understand.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onOpenSyllabus}
              className="ios-glass-btn inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-medium text-stone-800 cursor-pointer whitespace-nowrap"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>All CBSE Chapters</span>
            </button>

            <button
              type="button"
              onClick={onOpenChat}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-semibold text-white bg-gradient-to-b from-emerald-500 to-teal-600 hover:brightness-105 shadow-sm cursor-pointer whitespace-nowrap"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Open Free AI Chat</span>
            </button>
          </div>
        </div>

        {/* Direct Class, Subject & Lesson Picker inside Study Loop */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label
              htmlFor="loop-class-select"
              className="block text-[11px] font-semibold text-stone-500 mb-1"
            >
              Class
            </label>
            <select
              id="loop-class-select"
              value={studentContext.studentClass}
              onChange={(e) =>
                onChangeStudentClass(e.target.value as StudentClass)
              }
              disabled={isRunning}
              className="w-full rounded-2xl border border-slate-200/90 bg-white/90 px-3.5 py-2.5 text-xs font-semibold text-stone-900 focus:outline-none focus:border-blue-500 disabled:opacity-60 cursor-pointer"
            >
              {STUDENT_CLASSES.map((cls) => (
                <option key={cls} value={cls}>
                  {cls} CBSE
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="loop-subject-select"
              className="block text-[11px] font-semibold text-stone-500 mb-1"
            >
              Subject
            </label>
            <select
              id="loop-subject-select"
              value={studentContext.subject}
              onChange={(e) => onChangeSubject(e.target.value)}
              disabled={isRunning}
              className="w-full rounded-2xl border border-slate-200/90 bg-white/90 px-3.5 py-2.5 text-xs font-semibold text-stone-900 focus:outline-none focus:border-blue-500 disabled:opacity-60 cursor-pointer"
            >
              {subjectsForClass.map((subj) => (
                <option key={subj} value={subj}>
                  {subj}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="loop-lesson-select"
              className="block text-[11px] font-semibold text-stone-500 mb-1"
            >
              Lesson / Chapter
            </label>
            <select
              id="loop-lesson-select"
              value={
                lessons.find((l) => l.title === studentContext.lessonTitle)
                  ?.id ||
                lessons[0]?.id ||
                ""
              }
              onChange={(e) => {
                const picked = lessons.find((l) => l.id === e.target.value);
                if (picked) {
                  onSelectLesson(picked);
                }
              }}
              disabled={isRunning || lessons.length === 0}
              className="w-full rounded-2xl border border-slate-200/90 bg-white/90 px-3.5 py-2.5 text-xs font-semibold text-stone-900 focus:outline-none focus:border-blue-500 disabled:opacity-60 cursor-pointer"
            >
              {lessons.map((lesson) => (
                <option key={lesson.id} value={lesson.id}>
                  {lesson.chapterNumber}: {lesson.title}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Action Strip: Refresh Gemini Lesson, Deep Web Notes, Textbook Photo, Custom Focus */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex flex-wrap items-center gap-2.5">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />
            <button
              type="button"
              disabled={isRunning}
              onClick={() => fileInputRef.current?.click()}
              className="ios-glass-btn inline-flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs font-medium text-stone-700 cursor-pointer disabled:opacity-50 whitespace-nowrap"
            >
              <ImagePlus className="w-4 h-4" />
              <span>
                {attachedImage ? "Change Photo" : "Upload Textbook Photo"}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setShowCustomPrompt((v) => !v)}
              className="ios-glass-btn inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-medium text-stone-700 cursor-pointer whitespace-nowrap"
            >
              <PenLine className="w-3.5 h-3.5" />
              <span>
                {showCustomPrompt ? "Hide Custom Topic" : "Custom Topic Focus"}
              </span>
            </button>

            {attachedImage && (
              <div className="ios-glass-subtle flex items-center gap-2.5 px-3 py-1.5 rounded-2xl">
                <img
                  src={attachedImage.previewUrl}
                  alt={attachedImage.name}
                  referrerPolicy="no-referrer"
                  className="w-7 h-7 rounded-lg object-cover"
                />
                <span className="text-xs text-stone-700 max-w-[140px] truncate">
                  {attachedImage.name}
                </span>
                <button
                  type="button"
                  onClick={handleStandaloneImageScan}
                  disabled={analyzingImageOnly || isRunning}
                  className="ios-glass-btn-primary inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-medium disabled:opacity-50 cursor-pointer whitespace-nowrap"
                >
                  {analyzingImageOnly ? (
                    <Loader2 className="w-3 h-3 animate-spin" />
                  ) : (
                    <ScanEye className="w-3 h-3" />
                  )}
                  <span>Explain with Gemini</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAttachedImage(null);
                    setImageAnalysisText(null);
                  }}
                  disabled={isRunning}
                  className="text-stone-400 hover:text-stone-800 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {onGenerateQuickOverview && !isRunning && (
              <button
                type="button"
                onClick={onGenerateQuickOverview}
                disabled={!topicInput.trim() || overviewLoading}
                className="ios-glass-btn inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-medium text-stone-800 cursor-pointer whitespace-nowrap disabled:opacity-50"
              >
                <RefreshCw
                  className={`w-3.5 h-3.5 ${
                    overviewLoading ? "animate-spin text-blue-600" : ""
                  }`}
                />
                <span>Refresh Detailed Notes</span>
              </button>
            )}

            <div className="ios-segmented flex items-center gap-1 p-1 rounded-2xl">
              <button
                type="button"
                onClick={() => setDepth("standard")}
                disabled={isRunning}
                className={`px-2.5 py-1 rounded-xl text-[11px] font-medium transition-all whitespace-nowrap cursor-pointer ${
                  depth === "standard"
                    ? "bg-white text-stone-900 shadow-sm"
                    : "text-stone-600 hover:text-stone-900"
                }`}
              >
                Standard
              </button>
              <button
                type="button"
                onClick={() => setDepth("deep")}
                disabled={isRunning}
                className={`px-2.5 py-1 rounded-xl text-[11px] font-medium transition-all whitespace-nowrap cursor-pointer ${
                  depth === "deep"
                    ? "bg-white text-stone-900 shadow-sm"
                    : "text-stone-600 hover:text-stone-900"
                }`}
              >
                Deep Exam
              </button>
            </div>

            {isRunning ? (
              <button
                type="button"
                onClick={onStopInvestigation}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-red-600/90 text-white text-xs font-semibold hover:bg-red-700 transition-colors cursor-pointer whitespace-nowrap shadow-md"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>Stop Deep Guide</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => onStartInvestigation()}
                disabled={!topicInput.trim()}
                className="ios-glass-btn-primary inline-flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-semibold disabled:opacity-40 cursor-pointer whitespace-nowrap"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Deep Web-Verified Notes</span>
              </button>
            )}

            {state.phase === "complete" && state.reportMarkdown && (
              <button
                type="button"
                onClick={onOpenReport}
                className="ios-glass-btn inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-semibold text-stone-900 cursor-pointer whitespace-nowrap"
              >
                <span>Print Notes</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {showCustomPrompt && (
          <div className="pt-2 space-y-2">
            <textarea
              id="study-topic-input"
              rows={2}
              value={topicInput}
              onChange={(e) => setTopicInput(e.target.value)}
              disabled={isRunning}
              placeholder="Optional: customize the exact focus or specific question for this lesson..."
              className="w-full rounded-2xl border border-slate-200/80 bg-white/85 px-4 py-3 text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:border-blue-500 disabled:opacity-60"
            />
          </div>
        )}

        {imageError && <p className="text-xs text-red-700">{imageError}</p>}

        {imageAnalysisText && (
          <div className="mt-2 p-4 rounded-2xl border border-blue-200/80 bg-blue-50/50">
            <div className="flex items-center justify-between mb-2">
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-900">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                <span>Gemini Textbook Photo Explanation</span>
              </span>
              <button
                type="button"
                onClick={() => setImageAnalysisText(null)}
                className="text-stone-400 hover:text-stone-700 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="text-xs text-stone-700 leading-relaxed whitespace-pre-line">
              {imageAnalysisText}
            </div>
          </div>
        )}
      </section>

      {/* Ask AI Inline Doubt Bar */}
      <form
        onSubmit={handleQuickDoubtSubmit}
        className="ios-glass-card rounded-3xl p-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5"
      >
        <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 shrink-0 px-1">
          <Sparkles className="w-4 h-4 text-emerald-600" />
          <span>Didn&apos;t understand any topic? Ask Free AI Tutor:</span>
        </div>
        <input
          type="text"
          value={quickDoubtInput}
          onChange={(e) => setQuickDoubtInput(e.target.value)}
          placeholder={`Ask any doubt from ${
            studentContext.lessonTitle || studentContext.subject
          }...`}
          className="flex-1 rounded-2xl border border-slate-200/80 bg-white/90 px-3.5 py-2 text-xs text-stone-900 placeholder:text-stone-400 focus:outline-none focus:border-emerald-500"
        />
        <button
          type="submit"
          disabled={!quickDoubtInput.trim()}
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-2xl text-xs font-semibold text-white bg-gradient-to-b from-emerald-500 to-teal-600 hover:brightness-105 disabled:opacity-45 transition cursor-pointer whitespace-nowrap shrink-0"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Ask AI Chat</span>
        </button>
      </form>

      {state.error && (
        <div className="rounded-2xl border border-red-200 bg-red-50/90 px-5 py-4 text-sm text-red-900 flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Could Not Load Lesson Details</p>
              <p className="mt-0.5 text-xs text-red-800">{state.error}</p>
            </div>
          </div>
          {onGenerateQuickOverview && (
            <button
              type="button"
              onClick={onGenerateQuickOverview}
              className="px-3 py-1.5 rounded-xl bg-red-700 text-white text-xs font-semibold hover:bg-red-800 cursor-pointer shrink-0"
            >
              Retry with Gemini
            </button>
          )}
        </div>
      )}

      {/* Main Workspace Grid: Full width unless a 3D Simulation or Deep Claims/Sources exist */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-7 items-start">
        <div
          className={
            hasSidebarContent ? "lg:col-span-7 space-y-6" : "lg:col-span-12 space-y-6"
          }
        >
          {/* Core Lesson Overview Sections (Always Instant — Enriched Automatically in Background) */}
          {state.lessonOverview && (
            <div className="space-y-6">
              {/* 1. Gemini Full Summary */}
              <section className="ios-glass-card rounded-3xl p-6 space-y-3.5">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-stone-200/80">
                  <div className="flex items-center gap-2.5">
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
                      <Sparkles className="w-3 h-3" />
                      <span>Full Summary</span>
                    </span>
                    <h2 className="font-display text-lg font-semibold text-stone-900">
                      Complete Chapter Overview
                    </h2>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      askSpecificTopicInChat("Full Summary of this lesson")
                    }
                    className="inline-flex items-center gap-1 px-3 py-1 rounded-xl text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 cursor-pointer"
                  >
                    <MessageSquare className="w-3 h-3" />
                    <span>Ask AI Chat</span>
                  </button>
                </div>

                <div className="text-sm text-stone-700 leading-relaxed whitespace-pre-line">
                  {state.lessonOverview.fullSummary}
                </div>
              </section>

              {/* 2. Lesson Key Points */}
              <section className="ios-glass-card rounded-3xl p-6 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-stone-200/80">
                  <div className="flex items-center gap-2">
                    <ListChecks className="w-5 h-5 text-indigo-600" />
                    <h2 className="font-display text-lg font-semibold text-stone-900">
                      Lesson Key Points ({state.lessonOverview.keyPoints.length})
                    </h2>
                  </div>
                  <span className="text-[11px] font-medium text-stone-500">
                    Click Ask Gemini on any point you want explained
                  </span>
                </div>

                <div
                  className={
                    hasSidebarContent
                      ? "grid grid-cols-1 md:grid-cols-2 gap-3"
                      : "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3"
                  }
                >
                  {state.lessonOverview.keyPoints.map((kp, idx) => (
                    <div
                      key={kp.id || idx}
                      className="rounded-2xl border border-slate-200/85 bg-white/85 p-3.5 flex flex-col justify-between gap-2.5"
                    >
                      <div className="space-y-1.5">
                        <span className="inline-block font-mono-tabular text-[11px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-lg border border-indigo-200/70">
                          {idx + 1}. {kp.tag}
                        </span>
                        <p className="text-xs text-stone-800 leading-relaxed">
                          {kp.point}
                        </p>
                      </div>
                      <div>
                        <button
                          type="button"
                          onClick={() => askSpecificTopicInChat(kp.point)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/75 cursor-pointer"
                        >
                          <MessageSquare className="w-2.5 h-2.5" />
                          <span>Ask Gemini</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* 3. Gemini Lesson Structure Image */}
              <LessonStructureDiagramView
                diagram={state.lessonOverview.structureDiagram}
                onAskTopicInChat={(topicLabel) =>
                  askSpecificTopicInChat(topicLabel)
                }
              />

              {/* YouTube Video Tutorials WITH Real Thumbnails (PW, Next Toppers, Magnet Brains) */}
              {displayedYoutubeVideos.length > 0 && (
                <section className="ios-glass-card rounded-3xl p-6 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-stone-200/80">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-red-600 text-white flex items-center justify-center shadow-md shrink-0">
                        <Play className="w-4 h-4 fill-current" />
                      </div>
                      <div>
                        <h2 className="font-display text-lg font-semibold text-stone-900">
                          Top Video Lectures (Physics Wallah &amp; Next Toppers)
                        </h2>
                        <p className="text-xs text-stone-500">
                          Watch curated NCERT one-shots &amp; rapid revisions
                          with thumbnails right here
                        </p>
                      </div>
                    </div>
                  </div>

                  <div
                    className={`grid gap-4 ${
                      hasSidebarContent
                        ? "grid-cols-1 sm:grid-cols-2"
                        : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"
                    }`}
                  >
                    {displayedYoutubeVideos.map((yt) => {
                      const thumbUrl =
                        yt.thumbnailUrl ||
                        (yt.videoId
                          ? buildYoutubeThumbnailUrl(yt.videoId)
                          : undefined);
                      const hasFailed = Boolean(failedThumbIds[yt.id]);
                      const youtubeExternalUrl =
                        yt.watchUrl ||
                        `https://www.youtube.com/results?search_query=${encodeURIComponent(
                          yt.searchQuery
                        )}`;

                      const badgeStyle =
                        yt.badge === "Physics Wallah"
                          ? "bg-stone-900 text-amber-300 border-amber-400/40"
                          : yt.badge === "Next Toppers"
                          ? "bg-indigo-700 text-white border-indigo-400/40"
                          : "bg-red-600 text-white border-red-400/40";

                      return (
                        <article
                          key={yt.id}
                          className="group rounded-2xl border border-slate-200/90 bg-white/95 overflow-hidden flex flex-col justify-between shadow-xs hover:shadow-lg hover:border-red-300 transition-all"
                        >
                          {/* 16:9 YouTube Thumbnail Stage */}
                          <button
                            type="button"
                            onClick={() => {
                              if (yt.videoId) {
                                setActiveVideoModal(yt);
                              } else {
                                window.open(
                                  youtubeExternalUrl,
                                  "_blank",
                                  "noopener,noreferrer"
                                );
                              }
                            }}
                            className="relative aspect-video w-full bg-slate-900 overflow-hidden cursor-pointer text-left block"
                          >
                            {thumbUrl && !hasFailed ? (
                              <img
                                src={thumbUrl}
                                alt={yt.title}
                                loading="lazy"
                                referrerPolicy="no-referrer"
                                onError={() =>
                                  setFailedThumbIds((prev) => ({
                                    ...prev,
                                    [yt.id]: true,
                                  }))
                                }
                                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                              />
                            ) : (
                              <div className="w-full h-full bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-800 flex flex-col items-center justify-center p-4 text-center">
                                <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                                  {yt.badge || yt.channelTitle}
                                </span>
                                <span className="mt-1 text-xs font-medium text-white/90 line-clamp-2">
                                  {yt.title}
                                </span>
                              </div>
                            )}

                            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/15 to-transparent" />

                            <span
                              className={`absolute top-2.5 left-2.5 inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border shadow-sm ${badgeStyle}`}
                            >
                              {yt.badge || yt.channelTitle}
                            </span>

                            <div className="absolute inset-0 flex items-center justify-center">
                              <span className="w-12 h-12 rounded-full bg-red-600/95 text-white flex items-center justify-center shadow-xl ring-4 ring-white/25 transition-transform duration-200 group-hover:scale-110">
                                <Play className="w-5 h-5 fill-current ml-0.5" />
                              </span>
                            </div>

                            <span className="absolute bottom-2 right-2.5 px-2 py-0.5 rounded-md bg-black/75 text-[10px] font-semibold text-white">
                              Click to Play
                            </span>
                          </button>

                          {/* Card Info + Actions */}
                          <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                            <div className="space-y-1">
                              <h3 className="font-display text-sm font-semibold text-stone-900 leading-snug line-clamp-2 group-hover:text-red-700 transition-colors">
                                {yt.title}
                              </h3>
                              <p className="text-xs text-stone-500">
                                Channel:{" "}
                                <strong className="text-stone-700">
                                  {yt.channelTitle}
                                </strong>
                              </p>
                            </div>

                            <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
                              {yt.videoId ? (
                                <button
                                  type="button"
                                  onClick={() => setActiveVideoModal(yt)}
                                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-red-700 hover:text-red-800 cursor-pointer"
                                >
                                  <Play className="w-3.5 h-3.5 fill-current" />
                                  <span>Watch Here</span>
                                </button>
                              ) : (
                                <span className="text-[11px] font-medium text-stone-500">
                                  Curated Search
                                </span>
                              )}

                              <a
                                href={youtubeExternalUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-red-50 hover:bg-red-100 text-[11px] font-semibold text-red-700 transition-colors"
                              >
                                <span>YouTube</span>
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            </div>
                          </div>
                        </article>
                      );
                    })}
                  </div>
                </section>
              )}

              {/* Inline YouTube Video Player Modal */}
              {activeVideoModal && activeVideoModal.videoId && (
                <div
                  className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4"
                  onClick={() => setActiveVideoModal(null)}
                >
                  <div
                    className="w-full max-w-3xl rounded-3xl bg-zinc-950 border border-white/15 overflow-hidden shadow-2xl"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="px-5 py-3.5 border-b border-white/10 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-[11px] font-semibold text-amber-300 truncate">
                          {activeVideoModal.channelTitle}
                        </p>
                        <h3 className="text-sm font-semibold text-white truncate">
                          {activeVideoModal.title}
                        </h3>
                      </div>
                      <button
                        type="button"
                        onClick={() => setActiveVideoModal(null)}
                        aria-label="Close video player"
                        className="p-2 rounded-xl bg-white/10 text-white hover:bg-white/20 cursor-pointer shrink-0"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="aspect-video w-full bg-black">
                      <iframe
                        src={
                          activeVideoModal.embedUrl ||
                          `https://www.youtube.com/embed/${activeVideoModal.videoId}?autoplay=1&rel=0`
                        }
                        title={activeVideoModal.title}
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        className="w-full h-full border-0"
                      />
                    </div>

                    <div className="px-5 py-3 bg-zinc-900/90 flex items-center justify-between gap-3 text-xs">
                      <span className="text-zinc-400">
                        Playing curated lecture inside Tutorix AI
                      </span>
                      <a
                        href={
                          activeVideoModal.watchUrl ||
                          `https://www.youtube.com/watch?v=${activeVideoModal.videoId}`
                        }
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600 text-white font-semibold hover:bg-red-700"
                      >
                        <span>Open on YouTube</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                </div>
              )}

              {/* 4. All Lesson Details (Topic-by-Topic Deep Coverage) */}
              {detailSections.length > 0 && (
                <section className="ios-glass-card rounded-3xl p-6 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-stone-200/80">
                    <div className="flex items-center gap-2.5">
                      <Layers className="w-5 h-5 text-blue-600" />
                      <div>
                        <h2 className="font-display text-lg font-semibold text-stone-900">
                          All Lesson Details — Every Subtopic, Formulas &amp;
                          Examples ({detailSections.length})
                        </h2>
                        <p className="text-xs text-stone-500">
                          Everything inside this chapter explained clearly by
                          Gemini.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div
                    className={
                      hasSidebarContent
                        ? "space-y-4"
                        : "grid grid-cols-1 lg:grid-cols-2 gap-4"
                    }
                  >
                    {detailSections.map((sec, idx) => (
                      <article
                        key={`${sec.title}-${idx}`}
                        className="rounded-2xl border border-slate-200/85 bg-white/90 p-4 sm:p-5 flex flex-col justify-between gap-3 shadow-2xs"
                      >
                        <div className="space-y-3">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center gap-2">
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-lg bg-blue-600 text-white font-mono-tabular text-[11px] font-bold shrink-0">
                                {idx + 1}
                              </span>
                              <h3 className="font-display text-base font-semibold text-stone-900">
                                {sec.title}
                              </h3>
                            </div>
                            <button
                              type="button"
                              onClick={() => askSpecificTopicInChat(sec.title)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 cursor-pointer whitespace-nowrap shrink-0"
                            >
                              <MessageSquare className="w-3 h-3" />
                              <span>Not clear? Ask AI</span>
                            </button>
                          </div>

                          <p className="text-xs sm:text-sm text-stone-700 leading-relaxed whitespace-pre-line">
                            {sec.content}
                          </p>

                          {sec.formulaOrRule && (
                            <div className="rounded-xl border border-indigo-200/80 bg-indigo-50/75 px-3.5 py-2.5 flex items-start gap-2">
                              <Calculator className="w-4 h-4 text-indigo-700 shrink-0 mt-0.5" />
                              <div className="text-xs text-indigo-950 leading-snug">
                                <span className="font-semibold block text-[11px] uppercase tracking-wide text-indigo-700 mb-0.5">
                                  Formula / Key Rule
                                </span>
                                <span className="font-medium">
                                  {sec.formulaOrRule}
                                </span>
                              </div>
                            </div>
                          )}

                          {sec.example && (
                            <div className="rounded-xl border border-amber-200/80 bg-amber-50/70 px-3.5 py-2.5 flex items-start gap-2">
                              <Lightbulb className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                              <div className="text-xs text-stone-800 leading-snug">
                                <span className="font-semibold block text-[11px] uppercase tracking-wide text-amber-800 mb-0.5">
                                  Solved / Everyday Example
                                </span>
                                <span>{sec.example}</span>
                              </div>
                            </div>
                          )}
                        </div>
                      </article>
                    ))}
                  </div>
                </section>
              )}
            </div>
          )}

          {/* Optional Deep Web-Verified Study Guide (when triggered by user or started from Syllabus) */}
          {hasDeepStudyContent && (
            <div className="space-y-5 pt-2">
              <div className="ios-glass-card rounded-3xl p-5 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wide text-blue-700">
                      <Globe className="w-3.5 h-3.5" />
                      <span>Gemini Live Web-Verified Study Loop</span>
                    </span>
                    <h2 className="font-display text-lg font-semibold text-stone-900">
                      Deep NCERT &amp; CBSE Verified Master Guide
                    </h2>
                  </div>
                  {state.phase === "complete" && state.reportMarkdown && (
                    <button
                      type="button"
                      onClick={onOpenReport}
                      className="ios-glass-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-stone-800 cursor-pointer whitespace-nowrap"
                    >
                      <span>Full Print View</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  )}
                </div>

                {/* Compact Progress Stepper */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                  {PIPELINE_STEPS.map((step, idx) => {
                    const isDone =
                      state.phase === "complete" || currentPhaseIdx > idx;
                    const isActive = isRunning && currentPhaseIdx === idx;
                    return (
                      <div
                        key={step.id}
                        className={`rounded-2xl px-3.5 py-2.5 transition-all ${
                          isActive
                            ? "bg-stone-900/95 text-white border border-white/15 shadow-md"
                            : isDone
                            ? "bg-emerald-50/90 border border-emerald-200/80 text-stone-900"
                            : "ios-glass-subtle text-stone-500"
                        }`}
                      >
                        <div className="flex items-center justify-between gap-1.5">
                          <span className="text-[11px] font-semibold truncate">
                            {step.label}
                          </span>
                          {isActive ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
                          ) : isDone ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          ) : (
                            <CircleDot className="w-3.5 h-3.5 opacity-40 shrink-0" />
                          )}
                        </div>
                        <p
                          className={`mt-0.5 text-[10px] ${
                            isActive ? "text-stone-300" : "text-stone-500"
                          }`}
                        >
                          {step.agent}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {(state.reportMarkdown || state.phase === "finalizing") && (
                <article className="ios-glass-card rounded-3xl p-6 md:p-8 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-stone-200/80">
                    <div>
                      <span className="text-[11px] font-semibold uppercase tracking-wide text-emerald-700">
                        Gemini Complete Verified Study Guide
                      </span>
                      <h2 className="font-display text-xl font-semibold text-stone-900 mt-0.5">
                        {studentContext.lessonTitle || "Full Lesson Master Guide"}
                      </h2>
                    </div>
                    {state.phase === "finalizing" && (
                      <span className="inline-flex items-center gap-1.5 text-xs text-stone-600">
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Writing master guide...</span>
                      </span>
                    )}
                  </div>

                  <div className="editorial-prose max-w-none">
                    <ReactMarkdown
                      remarkPlugins={[remarkGfm]}
                      components={{
                        h2: ({ children }) => {
                          const headingText = extractNodeText(children).trim();
                          return (
                            <div className="flex flex-wrap items-center justify-between gap-2 mt-7 mb-2 pb-1.5 border-b border-stone-200">
                              <h2 className="!m-0 !p-0 !border-0">{children}</h2>
                              {headingText && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    askSpecificTopicInChat(headingText)
                                  }
                                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 transition cursor-pointer whitespace-nowrap"
                                >
                                  <MessageSquare className="w-3 h-3" />
                                  <span>Ask AI Chat</span>
                                </button>
                              )}
                            </div>
                          );
                        },
                        h3: ({ children }) => {
                          const subText = extractNodeText(children).trim();
                          return (
                            <div className="flex flex-wrap items-center justify-between gap-2 mt-5 mb-1.5">
                              <h3 className="!m-0">{children}</h3>
                              {subText && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    askSpecificTopicInChat(subText)
                                  }
                                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-medium text-emerald-700 bg-emerald-50/90 hover:bg-emerald-100 border border-emerald-200/70 transition cursor-pointer whitespace-nowrap"
                                >
                                  <MessageSquare className="w-2.5 h-2.5" />
                                  <span>Not clear? Ask AI</span>
                                </button>
                              )}
                            </div>
                          );
                        },
                        a: ({ href, children }) => (
                          <a
                            href={href}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            {children}
                          </a>
                        ),
                      }}
                    >
                      {state.reportMarkdown ||
                        "_Compiling complete web-verified lesson notes..._"}
                    </ReactMarkdown>
                  </div>
                </article>
              )}

              {state.messages.length > 0 && (
                <div className="space-y-3">
                  <h3 className="font-display text-base font-semibold text-stone-900 px-1">
                    Research &amp; Verification Log ({state.messages.length})
                  </h3>
                  {state.messages.map((msg) => (
                    <article
                      key={msg.id}
                      className="ios-glass-card rounded-3xl p-5"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 mb-2.5 border-b border-stone-100">
                        <div className="flex items-center gap-2 text-xs">
                          {getAgentHeaderIcon(msg.agentId)}
                          <span className="font-semibold text-stone-900">
                            {getStepRoleLabel(msg.agentId)}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => askSpecificTopicInChat(msg.headline)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/70 transition cursor-pointer whitespace-nowrap"
                        >
                          <MessageSquare className="w-3 h-3" />
                          <span>Ask AI Chat</span>
                        </button>
                      </div>

                      <h4 className="text-sm font-semibold text-stone-900 mb-2">
                        {msg.headline}
                      </h4>

                      {msg.subQueries && msg.subQueries.length > 0 && (
                        <div className="mb-3 p-3 rounded-xl bg-[#FAF9F6] border border-stone-200">
                          <p className="text-[11px] font-semibold text-stone-600 mb-1.5">
                            Topics Covered (click any to ask AI Chat)
                          </p>
                          <ol className="list-decimal pl-4 space-y-1 text-xs text-stone-700">
                            {msg.subQueries.map((q, i) => (
                              <li key={i} className="leading-snug">
                                <button
                                  type="button"
                                  onClick={() => askSpecificTopicInChat(q)}
                                  className="text-left hover:text-emerald-700 hover:underline cursor-pointer"
                                >
                                  {q}
                                </button>
                              </li>
                            ))}
                          </ol>
                        </div>
                      )}

                      <div className="text-xs md:text-sm text-stone-700 leading-relaxed space-y-2 [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:list-decimal [&_ol]:pl-5 [&_strong]:text-stone-900 [&_h3]:font-semibold [&_h3]:text-stone-900">
                        <ReactMarkdown remarkPlugins={[remarkGfm]}>
                          {msg.content}
                        </ReactMarkdown>
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Column (5/12): Rendered ONLY when 3D Simulation exists OR deep claims/sources exist */}
        {hasSidebarContent && (
          <aside className="lg:col-span-5 space-y-6">
            {matchedSim && (
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h2 className="font-display text-xl font-semibold text-stone-900">
                      3D Lesson Simulation
                    </h2>
                    <p className="text-xs text-stone-500 mt-0.5">
                      Interactive 3D lab available for this lesson.
                    </p>
                  </div>
                </div>

                <LessonStage3D
                  studentContext={studentContext}
                  topic={topicInput}
                  fullStage={false}
                  onExpandStage={onExpand3DStage}
                />
              </div>
            )}

            {state.claims.length > 0 && (
              <section className="ios-glass-card rounded-3xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-display text-base font-semibold text-stone-900">
                    Verified Concepts &amp; Formulas
                  </h3>
                  <span className="font-mono-tabular text-xs text-stone-500">
                    {state.claims.length} verified
                  </span>
                </div>

                <div className="divide-y divide-stone-100">
                  {state.claims.map((claim) => (
                    <div key={claim.id} className="py-3 first:pt-1 last:pb-1">
                      <div className="flex items-center justify-between gap-2 text-[11px] mb-1">
                        <div className="flex items-center gap-1.5 text-stone-500">
                          <span className="font-mono-tabular font-semibold text-stone-800">
                            {claim.id}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{claim.category}</span>
                        </div>

                        <span
                          className={`inline-flex items-center gap-1 font-medium ${
                            claim.status === "verified"
                              ? "text-emerald-700"
                              : claim.status === "corrected"
                              ? "text-blue-700"
                              : claim.status === "disputed"
                              ? "text-amber-700"
                              : "text-stone-500"
                          }`}
                        >
                          {claim.status === "verified" && (
                            <>
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Verified</span>
                            </>
                          )}
                          {claim.status === "corrected" && (
                            <>
                              <ShieldCheck className="w-3 h-3" />
                              <span>Clarified</span>
                            </>
                          )}
                          {claim.status === "disputed" && (
                            <>
                              <AlertTriangle className="w-3 h-3" />
                              <span>Needs Review</span>
                            </>
                          )}
                          {claim.status === "extracted" && (
                            <span>Under Review</span>
                          )}
                        </span>
                      </div>

                      <p className="text-xs text-stone-800 leading-relaxed">
                        {claim.statement}
                      </p>

                      {(claim.correctionNote || claim.factCheckNote) && (
                        <p className="mt-1.5 text-[11px] text-stone-500 leading-snug">
                          {claim.correctionNote || claim.factCheckNote}
                        </p>
                      )}

                      <div className="mt-2">
                        <button
                          type="button"
                          onClick={() => askSpecificTopicInChat(claim.statement)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/75 transition cursor-pointer"
                        >
                          <MessageSquare className="w-3 h-3" />
                          <span>Not clear? Ask AI</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {state.sources.length > 0 && (
              <section className="ios-glass-card rounded-3xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-display text-base font-semibold text-stone-900">
                    Verified CBSE Study Links
                  </h3>
                  <span className="font-mono-tabular text-xs text-stone-500">
                    {state.sources.length} URLs
                  </span>
                </div>

                <div className="max-h-72 overflow-y-auto divide-y divide-stone-100 pr-1">
                  {state.sources.map((src) => (
                    <a
                      key={src.url}
                      href={src.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-2.5 flex items-start gap-2.5 text-xs group"
                    >
                      <span className="font-mono-tabular text-stone-400 shrink-0">
                        [{src.id}]
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="font-medium text-stone-800 group-hover:text-blue-700 group-hover:underline truncate">
                          {src.title}
                        </p>
                        <p className="text-[11px] text-stone-500 flex items-center gap-1 mt-0.5">
                          <span className="truncate">{src.domain}</span>
                          <ExternalLink className="w-3 h-3 shrink-0" />
                        </p>
                      </div>
                    </a>
                  ))}
                </div>
              </section>
            )}
          </aside>
        )}
      </div>
    </div>
  );
};
