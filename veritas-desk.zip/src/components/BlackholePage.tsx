import React, { useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  Zap,
  Flame,
  Table2,
  Target,
  ImagePlus,
  X,
  Loader2,
  Copy,
  Check,
  ExternalLink,
  ArrowLeft,
  Orbit,
} from "lucide-react";
import {
  STUDENT_CLASSES,
  getSubjectsForClass,
  type StudentClass,
} from "../data/syllabusCatalog";
import {
  generateFreeLocalBlackholeReply,
  safeJsonResponse,
} from "../utils/freeLocalChat";
import type {
  BlackholeMode,
  GroundedSource,
  StudentProfileContext,
  UploadedImagePayload,
} from "../types";

interface BlackholePageProps {
  studentContext: StudentProfileContext;
  onChangeStudentClass: (cls: StudentClass) => void;
  onChangeSubject: (subject: string) => void;
  initialTopic: string;
  onBackToMain: () => void;
}

const BLACKHOLE_MODES: Array<{
  id: BlackholeMode;
  title: string;
  description: string;
  icon: React.FC<{ className?: string }>;
}> = [
  {
    id: "survival",
    title: "Last-Night Survival (80/20)",
    description: "Only the 20% high-weightage concepts that score 80% marks.",
    icon: Flame,
  },
  {
    id: "crash",
    title: "5-Min Zero-to-Hero",
    description: "Missed every class? Learn the whole chapter via a crisp story.",
    icon: Zap,
  },
  {
    id: "cheatsheet",
    title: "Cheat-Sheet Matrix",
    description: "All formulas, laws, units, bold keywords & mark-trap warnings.",
    icon: Table2,
  },
  {
    id: "questions",
    title: "Repeated CBSE Questions",
    description: "Top repeated board questions with step-marking hacks.",
    icon: Target,
  },
];

export const BlackholePage: React.FC<BlackholePageProps> = ({
  studentContext,
  onChangeStudentClass,
  onChangeSubject,
  initialTopic,
  onBackToMain,
}) => {
  const [mode, setMode] = useState<BlackholeMode>("survival");
  const [topic, setTopic] = useState<string>(
    initialTopic ||
      `${studentContext.studentClass} CBSE ${studentContext.subject}${
        studentContext.lessonTitle ? ` — ${studentContext.lessonTitle}` : ""
      }`
  );
  const [attachedImage, setAttachedImage] =
    useState<UploadedImagePayload | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultMarkdown, setResultMarkdown] = useState<string>("");
  const [sources, setSources] = useState<GroundedSource[]>([]);
  const [copied, setCopied] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const subjects = getSubjectsForClass(studentContext.studentClass);

  const handleImagePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Please select a PNG, JPG, or WebP photo.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result || "");
      const base64 = dataUrl.split(",")[1] || "";
      setAttachedImage({
        mimeType: file.type,
        data: base64,
        name: file.name,
        previewUrl: dataUrl,
      });
      setError(null);
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleActivateBlackhole = async (overrideMode?: BlackholeMode) => {
    const activeMode = overrideMode ?? mode;
    if (overrideMode) setMode(overrideMode);
    if ((!topic.trim() && !attachedImage) || loading) return;

    setLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/blackhole/rescue", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic: topic.trim(),
          mode: activeMode,
          studentContext,
          image: attachedImage
            ? {
                mimeType: attachedImage.mimeType,
                data: attachedImage.data,
              }
            : undefined,
        }),
      });

      const data = await safeJsonResponse<{
        content?: string;
        sources?: GroundedSource[];
      }>(res);
      if (res.ok && data?.content) {
        setResultMarkdown(data.content);
        setSources(Array.isArray(data.sources) ? data.sources : []);
        return;
      }
    } catch {
      // Fall back seamlessly to built-in free Blackhole notes below
    } finally {
      setLoading(false);
    }

    setResultMarkdown(
      generateFreeLocalBlackholeReply({
        topic: topic.trim(),
        mode: activeMode,
        studentContext,
      })
    );
    setSources([]);
  };

  const handleCopy = async () => {
    if (!resultMarkdown) return;
    try {
      await navigator.clipboard.writeText(resultMarkdown);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard fallback ignored
    }
  };

  return (
    <div className="blackhole-surface blackhole-page-enter min-h-screen text-zinc-100 flex flex-col">
      {/* Standalone Pure-Dark Top Navigation */}
      <header className="sticky top-0 z-30 border-b border-white/10 bg-black/80 backdrop-blur-xl">
        <div className="max-w-[1320px] mx-auto px-3.5 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-3 sm:gap-6">
          <div className="flex items-center gap-3 whitespace-nowrap shrink-0">
            <img
              src="/assets/aistudio/image_555f3288.png"
              alt="Tutorix AI logo"
              referrerPolicy="no-referrer"
              className="w-7 h-7 rounded-lg object-cover"
            />
            <span className="font-display text-lg font-semibold text-white">
              Blackhole
            </span>
          </div>

          <span className="hidden sm:inline text-xs text-zinc-400 whitespace-nowrap">
            {studentContext.studentClass} CBSE · {studentContext.subject}
          </span>

          <button
            type="button"
            onClick={onBackToMain}
            className="blackhole-glass-btn inline-flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-medium text-white cursor-pointer whitespace-nowrap shrink-0"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Tutorix AI</span>
          </button>
        </div>
      </header>

      <div className="flex-1 py-5 sm:py-8 px-3.5 sm:px-6">
        <div className="max-w-[1320px] mx-auto space-y-6 sm:space-y-8">
          {/* Pure-Dark Event Horizon Hero Card */}
          <section className="blackhole-glass-card blackhole-stagger-1 rounded-3xl p-5 sm:p-6 md:p-10 relative overflow-hidden">
            {/* Animated Singularity Accretion Rings (Compositor-only GPU transforms) */}
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -right-24 -top-24 w-80 h-80 flex items-center justify-center opacity-70"
            >
              <div className="blackhole-horizon-glow absolute w-64 h-64 rounded-full bg-gradient-to-tr from-amber-500/20 via-indigo-500/15 to-transparent blur-2xl" />
              <div
                className="blackhole-orbit-ring absolute w-72 h-72 rounded-full border border-white/15"
                style={{
                  borderTopColor: "rgba(253, 230, 138, 0.55)",
                  borderRightColor: "rgba(129, 140, 248, 0.3)",
                }}
              />
              <div
                className="blackhole-orbit-ring-reverse absolute w-52 h-52 rounded-full border border-white/10"
                style={{
                  borderBottomColor: "rgba(255, 255, 255, 0.45)",
                }}
              />
              <div className="w-28 h-28 rounded-full bg-black border border-white/25 shadow-[0_0_50px_rgba(255,255,255,0.12)]" />
            </div>

            <div className="relative z-10 max-w-2xl space-y-3">
              <div className="flex items-center gap-2.5 text-xs font-medium text-amber-300">
                <Orbit className="w-4 h-4 text-white" />
                <span>
                  Blackhole Backbenchers Engine · CBSE Classes 6 to 12
                </span>
              </div>

              <h1 className="font-display text-3xl md:text-5xl font-semibold tracking-tight text-white text-balance">
                Welcome to Blackhole
              </h1>

              <p className="text-sm md:text-base font-medium text-amber-200/95">
                Designed by your Srisanth
              </p>

              <p className="text-sm text-zinc-300 leading-relaxed max-w-xl">
                Built for backbenchers who need maximum marks in minimum time.
                Pick your rescue mode below to compress any NCERT chapter into
                an 80/20 survival kit, a 5-minute story, a formula cheat-sheet,
                or repeated CBSE board questions.
              </p>
            </div>

            {/* Class & Subject Glassmorphic Selectors */}
            <div className="relative z-10 mt-7 pt-6 border-t border-white/10 space-y-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-semibold text-zinc-400 w-16 shrink-0">
                  Class
                </span>
                {STUDENT_CLASSES.map((cls) => (
                  <button
                    key={cls}
                    type="button"
                    onClick={() => onChangeStudentClass(cls)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                      studentContext.studentClass === cls
                        ? "bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.25)]"
                        : "blackhole-glass-btn text-zinc-200"
                    }`}
                  >
                    {cls}
                  </button>
                ))}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-semibold text-zinc-400 w-16 shrink-0">
                  Subject
                </span>
                {subjects.map((subj) => (
                  <button
                    key={subj}
                    type="button"
                    onClick={() => onChangeSubject(subj)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                      studentContext.subject === subj
                        ? "bg-amber-300 text-black font-semibold shadow-[0_0_20px_rgba(253,230,138,0.3)]"
                        : "blackhole-glass-btn text-zinc-200"
                    }`}
                  >
                    {subj}
                  </button>
                ))}
              </div>
            </div>
          </section>

          {/* 4 Tactile Glassmorphic Backbencher Modes */}
          <section className="blackhole-stagger-2 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {BLACKHOLE_MODES.map((m) => {
              const Icon = m.icon;
              const active = mode === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMode(m.id)}
                  className={`text-left rounded-2xl p-5 transition-all duration-200 cursor-pointer active:scale-[0.97] ${
                    active
                      ? "bg-white/[0.11] border border-amber-300/70 shadow-[0_12px_36px_-10px_rgba(253,230,138,0.22)] backdrop-blur-xl -translate-y-0.5"
                      : "blackhole-glass-card hover:border-white/30 hover:-translate-y-0.5"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-2.5">
                    <Icon
                      className={`w-4 h-4 ${
                        active ? "text-amber-300" : "text-zinc-300"
                      }`}
                    />
                    {active && (
                      <span className="text-[11px] font-semibold text-amber-300">
                        Selected
                      </span>
                    )}
                  </div>
                  <h2 className="text-sm font-semibold text-white">
                    {m.title}
                  </h2>
                  <p className="mt-1.5 text-xs text-zinc-400 leading-relaxed">
                    {m.description}
                  </p>
                </button>
              );
            })}
          </section>

          {/* Topic Input + Photo Upload + Launch CTA */}
          <section className="blackhole-glass-card blackhole-stagger-3 rounded-3xl p-6 md:p-8 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="font-display text-lg font-semibold text-white">
                  Target Chapter, Topic, or Exam Question
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">
                  {studentContext.studentClass} CBSE · {studentContext.subject}
                  {studentContext.lessonTitle
                    ? ` · ${studentContext.lessonTitle}`
                    : ""}
                </p>
              </div>
            </div>

            <textarea
              rows={2}
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              disabled={loading}
              placeholder="Type any CBSE chapter, tricky concept, or exam question (e.g., Ohm's Law & Circuit Numericals)..."
              className="w-full rounded-2xl border border-white/15 bg-black px-4 py-3 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-amber-300/70 transition-colors"
            />

            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-3">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImagePick}
                  className="hidden"
                />
                <button
                  type="button"
                  disabled={loading}
                  onClick={() => fileInputRef.current?.click()}
                  className="blackhole-glass-btn inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-medium text-zinc-100 cursor-pointer whitespace-nowrap disabled:opacity-50"
                >
                  <ImagePlus className="w-4 h-4 text-amber-300" />
                  <span>
                    {attachedImage
                      ? "Change Question Photo"
                      : "Upload Question / Diagram Photo"}
                  </span>
                </button>

                {attachedImage && (
                  <div className="inline-flex items-center gap-2.5 px-3 py-1.5 rounded-2xl border border-white/15 bg-white/5">
                    <img
                      src={attachedImage.previewUrl}
                      alt={attachedImage.name}
                      referrerPolicy="no-referrer"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                    <span className="text-xs text-zinc-200 max-w-[160px] truncate">
                      {attachedImage.name}
                    </span>
                    <button
                      type="button"
                      onClick={() => setAttachedImage(null)}
                      className="text-zinc-400 hover:text-white cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              <button
                type="button"
                onClick={() => handleActivateBlackhole()}
                disabled={loading || (!topic.trim() && !attachedImage)}
                className="blackhole-cta-btn inline-flex items-center gap-2 px-6 py-3 rounded-2xl text-sm font-semibold cursor-pointer whitespace-nowrap disabled:opacity-45"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Running Blackhole Rescue...</span>
                  </>
                ) : (
                  <>
                    <Orbit className="w-4 h-4" />
                    <span>Activate Blackhole</span>
                  </>
                )}
              </button>
            </div>

            {error && (
              <div className="rounded-2xl border border-red-400/35 bg-red-950/60 px-4 py-3 text-xs text-red-200">
                {error}
              </div>
            )}
          </section>

          {/* Output Deck */}
          {resultMarkdown && (
            <section className="blackhole-glass-card page-transition-enter rounded-3xl p-6 md:p-10 space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-white/10">
                <div>
                  <p className="text-xs font-medium text-amber-300">
                    Blackhole Rescue Pack ·{" "}
                    {BLACKHOLE_MODES.find((m) => m.id === mode)?.title}
                  </p>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    {studentContext.studentClass} CBSE {studentContext.subject}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleCopy}
                  className="blackhole-glass-btn inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium text-zinc-100 cursor-pointer whitespace-nowrap"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Notes</span>
                    </>
                  )}
                </button>
              </div>

              <div className="blackhole-prose max-w-prose">
                <ReactMarkdown
                  remarkPlugins={[remarkGfm]}
                  components={{
                    a: ({ href, children }) => (
                      <a href={href} target="_blank" rel="noopener noreferrer">
                        {children}
                      </a>
                    ),
                  }}
                >
                  {resultMarkdown}
                </ReactMarkdown>
              </div>

              {sources.length > 0 && (
                <div className="pt-5 border-t border-white/10">
                  <p className="text-xs font-semibold text-zinc-300 mb-2.5">
                    Verified CBSE Reference Links
                  </p>
                  <div className="flex flex-wrap gap-3">
                    {sources.map((src) => (
                      <a
                        key={src.url}
                        href={src.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="blackhole-glass-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs text-blue-300 hover:text-white"
                      >
                        <span className="truncate max-w-[220px]">
                          {src.title}
                        </span>
                        <ExternalLink className="w-3 h-3 shrink-0" />
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </section>
          )}
        </div>
      </div>
    </div>
  );
};
