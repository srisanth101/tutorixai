import type { SyllabusLesson } from "../data/syllabusCatalog";
import type {
  LessonOverview,
  StudentProfileContext,
  StructureDiagramBranch,
} from "../types";
import { getCuratedYoutubeVideosForLesson } from "./youtubeCurated";

const ACCENTS: Array<StructureDiagramBranch["accent"]> = [
  "blue",
  "indigo",
  "emerald",
  "amber",
  "rose",
  "violet",
];

function splitFocusClauses(summary: string): string[] {
  return summary
    .replace(/\.$/, "")
    .split(/,|;|\band\b|\bwith\b/i)
    .map((s) => s.trim())
    .filter((s) => s.length >= 4);
}

/**
 * Generates an instant zero-latency structured LessonOverview from NCERT syllabus data
 * so Study Loop opens immediately with zero waiting spinner while background auto-prefetch
 * enriches and caches full notes across all chapters.
 */
export function buildInstantLessonOverview(
  ctx: StudentProfileContext,
  lesson?: SyllabusLesson | null
): LessonOverview {
  const title = lesson?.title || ctx.lessonTitle || `${ctx.subject} Lesson`;
  const chapterTag = lesson?.chapterNumber || "Chapter";
  const bookNote = lesson?.bookOrUnit ? ` (${lesson.bookOrUnit})` : "";
  const rawSummary =
    lesson?.summary ||
    `Core ${ctx.studentClass} CBSE ${ctx.subject} concepts, definitions, applications, and NCERT exam questions for ${title}.`;

  const clauses = splitFocusClauses(rawSummary);
  const topicA = clauses[0] || `Core concepts of ${title}`;
  const topicB = clauses[1] || `Fundamental laws & principles in ${title}`;
  const topicC = clauses[2] || `NCERT examples & numerical/conceptual problems`;
  const topicD = clauses[3] || `Real-world CBSE applications & exam revision`;

  const fullSummary = `${chapterTag}${bookNote} — ${title} is a core ${ctx.studentClass} CBSE (${ctx.subject}) chapter. In NCERT, this lesson builds foundational understanding around ${rawSummary.charAt(0).toLowerCase()}${rawSummary.slice(1)}\n\nStudents should master each core definition, understand how ${topicA.toLowerCase()} connects to ${topicB.toLowerCase()}, and practice step-by-step NCERT examples and CBSE board-style questions covered in the structured breakdown below.`;

  const keyPoints = [
    {
      id: "KP1",
      tag: "Core Focus",
      point: `${title} (${chapterTag}): ${rawSummary}`,
    },
    {
      id: "KP2",
      tag: "Concept",
      point: `Understand ${topicA} clearly with accurate NCERT terminology and units/rules.`,
    },
    {
      id: "KP3",
      tag: "Principle",
      point: `Connect ${topicB} to real-life daily observations and CBSE textbook activities.`,
    },
    {
      id: "KP4",
      tag: "Application",
      point: `Solve standard problems and reasoning questions involving ${topicC}.`,
    },
    {
      id: "KP5",
      tag: "Exam Tip",
      point: `Review NCERT in-text questions, back exercises, and common mistakes in ${title}.`,
    },
    {
      id: "KP6",
      tag: "Revision",
      point: `Use the Lesson Structure Map below to recall all subtopics of ${title} quickly before tests.`,
    },
  ];

  const allDetailsSections = [
    {
      title: `1. Introduction & Core Meaning (${topicA.slice(0, 38)})`,
      content: `${title} begins with understanding ${topicA}. Mastering the exact NCERT definition, keywords, and why this concept matters in everyday life builds a strong foundation for the rest of the chapter.`,
      formulaOrRule: `Key Focus: Define & identify ${topicA} accurately using NCERT terms.`,
      example: `Click "Not clear? Ask AI" on this card to get custom ${ctx.studentClass} solved examples for ${topicA}.`,
    },
    {
      title: `2. Core Laws, Rules & Mechanism (${topicB.slice(0, 36)})`,
      content: `This part of ${title} explains ${topicB}. Pay attention to cause-and-effect relationships, conditions where rules hold true, and comparisons frequently tested in CBSE 2-mark and 3-mark questions.`,
      formulaOrRule: `Core Principle: ${topicB}`,
      example: `Practice explaining why ${topicB} behaves this way in 2–3 clear exam points.`,
    },
    {
      title: `3. Key Applications & Problem Solving (${topicC.slice(0, 32)})`,
      content: `In CBSE exams, questions from ${title} often test ${topicC}. Always write the given information, state the relevant law or formula clearly, substitute values cleanly, and include proper SI units or reasoning.`,
      formulaOrRule: `Problem Method: Given → Principle/Formula → Stepwise Substitution → Final Answer.`,
      example: `Work through NCERT solved examples on ${topicC} to avoid sign or unit mistakes.`,
    },
    {
      title: `4. Chapter Summary & Exam Check (${topicD.slice(0, 32)})`,
      content: `Pulling together ${topicA}, ${topicB}, and ${topicC}, ensure you can answer both assertion-reason and case-study CBSE questions on ${title}.`,
      formulaOrRule: `Board Readiness: Revise definitions, diagrams, and NCERT back-exercise questions.`,
      example: `Use Free AI Chat anytime if any specific line, diagram, or question from ${title} feels unclear.`,
    },
  ];

  const branches: StructureDiagramBranch[] = [
    {
      title: "1. Foundation",
      subtitle: chapterTag,
      accent: ACCENTS[0],
      items: [topicA.slice(0, 44), "NCERT core definitions", "Everyday intuition"],
    },
    {
      title: "2. Core Principles",
      subtitle: ctx.subject,
      accent: ACCENTS[1],
      items: [topicB.slice(0, 44), "Key laws & rules", "Cause & effect"],
    },
    {
      title: "3. Applications",
      subtitle: "Problem Solving",
      accent: ACCENTS[2],
      items: [topicC.slice(0, 44), "Solved NCERT steps", "Diagrams & units"],
    },
    {
      title: "4. Exam Mastery",
      subtitle: `${ctx.studentClass} CBSE`,
      accent: ACCENTS[3],
      items: [topicD.slice(0, 44), "Common mistakes", "NCERT exercises"],
    },
  ];

  const youtubeSuggestions = getCuratedYoutubeVideosForLesson(ctx, title);

  return {
    lessonTitle: title,
    fullSummary,
    keyPoints,
    allDetailsSections,
    structureDiagram: {
      diagramTitle: `${chapterTag}: ${title} — Lesson Structure`,
      diagramType: "concept_map",
      centralTitle: title.slice(0, 34),
      centralSubtitle: `${ctx.studentClass} CBSE · ${ctx.subject}`,
      branches,
    },
    youtubeSuggestions,
    generatedBy: "Instant",
  };
}
