import type {
  AgentId,
  BlackholeMode,
  ResearchClaim,
  StudentProfileContext,
} from "../types";

/**
 * Safely parses JSON from a Response object.
 * On static hosts like Vercel where `/api/*` may rewrite to `index.html` (text/html),
 * calling `res.json()` throws `SyntaxError: Unexpected token '<'`.
 * Checking Content-Type first ensures zero JSON parse crashes anywhere.
 */
export async function safeJsonResponse<T = Record<string, unknown>>(
  res: Response
): Promise<T | null> {
  try {
    const contentType = res.headers.get("content-type")?.toLowerCase() || "";
    if (!contentType.includes("application/json")) {
      return null;
    }
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

interface TopicCheatEntry {
  keywords: string[];
  summary: string;
  formulas: string[];
  analogy: string;
  questions: Array<{ q: string; a: string }>;
  mistakes: string[];
}

const NCERT_KNOWLEDGE_BASE: TopicCheatEntry[] = [
  {
    keywords: ["electricity", "ohm", "current", "resistor", "circuit", "voltage", "power"],
    summary:
      "Electricity deals with the flow of electric charge ($Q$) through a conductor. Current ($I$) is the rate of flow of charge, potential difference ($V$) pushes the charge, and Resistance ($R$) opposes it.",
    formulas: [
      "`I = Q / t` — Electric Current (Unit: Ampere, A)",
      "`V = W / Q` — Potential Difference (Unit: Volt, V)",
      "`V = I × R` — Ohm's Law (R = Resistance in Ohm, Ω)",
      "`R = ρ × (L / A)` — Resistance depends on length, area & material",
      "`Rs = R1 + R2 + R3` (Series) & `1/Rp = 1/R1 + 1/R2` (Parallel)",
      "`H = I²Rt` — Joule's Law of Heating | `P = VI = I²R = V²/R` (Watt)",
    ],
    analogy:
      "Think of water flowing in a pipe: **Voltage ($V$)** is water pressure, **Current ($I$)** is how fast water flows, and **Resistance ($R$)** is a narrow squeeze in the pipe slowing water down.",
    questions: [
      {
        q: "A current of 0.5 A flows for 10 minutes. Find the electric charge.",
        a: "t = 10 × 60 = 600 s. So `Q = I × t = 0.5 × 600 = 300 C`.",
      },
      {
        q: "Why are household appliances connected in parallel instead of series?",
        a: "Each appliance gets full 220V voltage, has an independent switch, and if one fuses, others keep working.",
      },
    ],
    mistakes: [
      "Forgetting to convert minutes into seconds (`× 60`) in `Q = I × t`.",
      "Writing `Rp = 1/R1 + 1/R2` without taking the final reciprocal for parallel resistance!",
    ],
  },
  {
    keywords: ["light", "reflection", "refraction", "mirror", "lens", "concave", "convex", "snell"],
    summary:
      "Light travels in straight lines. Mirrors reflect light following ∠i = ∠r, while lenses refract (bend) light as it changes speed between media.",
    formulas: [
      "`1/f = 1/v + 1/u` — Mirror Formula (New Cartesian Sign Convention!)",
      "`m = -v/u = h'/h` — Magnification for Mirrors",
      "`1/f = 1/v - 1/u` — Lens Formula",
      "`m = v/u = h'/h` — Magnification for Lenses",
      "`P = 1 / f (in metres)` — Power of a Lens (Unit: Dioptre, D)",
      "`n = c / v = sin i / sin r` — Refractive Index & Snell's Law",
    ],
    analogy:
      "Imagine a toy car rolling from smooth tiles onto thick carpet at an angle: the wheel hitting carpet first slows down, making the car bend—just like light refracting from air into glass!",
    questions: [
      {
        q: "Find the power of a concave lens of focal length 2 m.",
        a: "For concave lens, focal length is negative (`f = -2 m`). `P = 1/(-2) = -0.5 D`.",
      },
      {
        q: "Which mirror gives an enlarged virtual image for shaving/dentists?",
        a: "Concave mirror when the object is placed between Pole (P) and Focus (F).",
      },
    ],
    mistakes: [
      "Forgetting sign conventions: object distance `u` is ALWAYS negative (`u < 0`).",
      "Converting focal length to metres before using `P = 1/f` (`P = 100 / f_in_cm`).",
    ],
  },
  {
    keywords: ["chemical reaction", "equation", "oxidation", "reduction", "redox", "displacement"],
    summary:
      "Chemical reactions rearrange atoms into new substances. By the Law of Conservation of Mass, total atoms on reactant and product sides must always stay balanced.",
    formulas: [
      "Combination: `A + B → AB` (e.g., `2H₂ + O₂ → 2H₂O`)",
      "Decomposition: `AB → A + B` (Thermal, Electrolytic, Photolytic)",
      "Displacement: `A + BC → AC + B` (More reactive metal displaces less reactive)",
      "Double Displacement: `AB + CD → AD + CB` (Ion exchange, often gives precipitate)",
      "OIL RIG: Oxidation Is Loss of e⁻ / Gain of O₂; Reduction Is Gain of e⁻ / Loss of O₂",
    ],
    analogy:
      "Balancing an equation is like counting LEGO bricks before and after rebuilding: you can change how the bricks are joined, but you never create or lose bricks!",
    questions: [
      {
        q: "Why is magnesium ribbon cleaned with sandpaper before burning?",
        a: "To remove the protective layer of magnesium oxide (MgO) formed on its surface so it burns easily.",
      },
      {
        q: "Why do we store silver chloride (AgCl) in dark-coloured bottles?",
        a: "Sunlight causes photolytic decomposition (`2AgCl → 2Ag + Cl₂`), turning it grey.",
      },
    ],
    mistakes: [
      "Changing subscripts (e.g., changing `H₂O` to `H₂O₂`) instead of changing coefficients when balancing!",
    ],
  },
  {
    keywords: ["acid", "base", "salt", "ph", "neutral", "bleaching", "baking soda", "plaster of paris"],
    summary:
      "Acids release `H⁺` (or `H₃O⁺`) ions in water and turn blue litmus red. Bases release `OH⁻` ions and turn red litmus blue. The pH scale measures `H⁺` strength from 0 to 14.",
    formulas: [
      "`Acid + Base → Salt + Water` (Neutralisation)",
      "`Acid + Metal → Salt + H₂↑` (Hydrogen burns with a 'pop' sound)",
      "Bleaching Powder: `Ca(OH)₂ + Cl₂ → CaOCl₂ + H₂O`",
      "Baking Soda (`NaHCO₃`) & Washing Soda (`Na₂CO₃·10H₂O`)",
      "Plaster of Paris: `CaSO₄·½H₂O` (+ `1½H₂O` → Gypsum `CaSO₄·2H₂O`)",
    ],
    analogy:
      "pH is like a tug-of-war: 7 is neutral water; below 7 `H⁺` ions dominate (sour acids like lemon), above 7 `OH⁻` ions dominate (soapy bases like baking soda).",
    questions: [
      {
        q: "Why should acid always be added slowly to water, never water to acid?",
        a: "Dilution is highly exothermic; adding water to acid can cause sudden boiling and acid splashing out.",
      },
    ],
    mistakes: [
      "Confusing Plaster of Paris (`½H₂O`) with Gypsum (`2H₂O`) in chemical formulas.",
    ],
  },
  {
    keywords: ["life process", "nutrition", "photosynthesis", "respiration", "heart", "nephron", "digestion"],
    summary:
      "Life Processes keep living organisms alive: Nutrition (energy intake), Respiration (releasing ATP from glucose), Transportation (heart/xylem/phloem), and Excretion (nephrons removing urea).",
    formulas: [
      "Photosynthesis: `6CO₂ + 12H₂O → C₆H₁₂O₆ + 6O₂ + 6H₂O` (Sunlight + Chlorophyll)",
      "Aerobic Respiration: `Glucose → Pyruvate → 6CO₂ + 6H₂O + 38 ATP`",
      "Anaerobic (Muscle cramps): `Pyruvate → Lactic Acid + Energy`",
      "Double Circulation: Right side pumps deoxygenated blood to lungs; Left side pumps oxygenated blood to body.",
    ],
    analogy:
      "Your body runs like a clean city: **Digestive system** = food kitchen, **Lungs + Heart** = delivery trucks carrying oxygen fuel, **Kidneys (Nephrons)** = smart water filters.",
    questions: [
      {
        q: "What is the role of HCl in the human stomach?",
        a: "Creates an acidic medium for enzyme Pepsin to digest proteins and kills harmful bacteria entering with food.",
      },
    ],
    mistakes: [
      "Mixing up Xylem (one-way water/minerals up) and Phloem (two-way food transport).",
    ],
  },
  {
    keywords: ["quadratic", "discriminant", "roots", "polynomial", "equation"],
    summary:
      "A quadratic equation has degree 2 and standard form `ax² + bx + c = 0` (`a ≠ 0`). It always has at most 2 roots, found either by factorisation or the Quadratic Formula.",
    formulas: [
      "Standard Form: `ax² + bx + c = 0` (`a ≠ 0`)",
      "Quadratic Formula: `x = (-b ± √(b² - 4ac)) / (2a)`",
      "Discriminant `D = b² - 4ac`",
      "`D > 0` → Two distinct real roots | `D = 0` → Two equal real roots | `D < 0` → No real roots",
    ],
    analogy:
      "Think of a parabola `y = ax² + bx + c` like a U-shaped bridge: its roots are the exact two points where the road touches the ground (`y = 0`).",
    questions: [
      {
        q: "Find `k` for which `2x² + kx + 3 = 0` has two equal real roots.",
        a: "Set `D = b² - 4ac = 0` ⇒ `k² - 4(2)(3) = 0` ⇒ `k² = 24` ⇒ `k = ±2√6`.",
      },
    ],
    mistakes: [
      "Forgetting the `±` sign when taking square roots (e.g., writing only `+2√6` instead of `±2√6`).",
    ],
  },
  {
    keywords: ["trigonometry", "sin", "cos", "tan", "sec", "cosec", "cot", "angle"],
    summary:
      "Trigonometry connects the angles of a right-angled triangle to the ratios of its sides. Memorising the standard table (0°, 30°, 45°, 60°, 90°) and the 3 fundamental identities solves almost every board question.",
    formulas: [
      "SOH-CAH-TOA: `sin θ = P/H`, `cos θ = B/H`, `tan θ = P/B`",
      "`sin²θ + cos²θ = 1`",
      "`1 + tan²θ = sec²θ` & `1 + cot²θ = cosec²θ`",
      "`sin(90° - θ) = cos θ`, `tan θ = sin θ / cos θ`",
    ],
    analogy:
      "If you know the shadow length of a school flagpole and the angle of the sun, trigonometry lets you measure the pole's exact height without climbing it!",
    questions: [
      {
        q: "Evaluate `2 tan²45° + cos²30° - sin²60°`.",
        a: "`tan 45° = 1`, `cos 30° = √3/2`, `sin 60° = √3/2`. Result = `2(1)² + (3/4) - (3/4) = 2`.",
      },
    ],
    mistakes: [
      "Confusing `(sin θ)²` with `sin(θ²)` — we write `sin²θ` to mean `(sin θ)²`.",
    ],
  },
  {
    keywords: ["gravitation", "gravity", "kepler", "free fall", "weight", "mass", "buoyancy", "archimedes"],
    summary:
      "Every object in the universe attracts every other object with a force proportional to their masses and inversely proportional to the square of distance between them.",
    formulas: [
      "`F = G × (M × m) / d²` (`G = 6.67 × 10⁻¹¹ N·m²/kg²`)",
      "`g = GM / R² ≈ 9.8 m/s²` on Earth",
      "`Weight W = m × g` (varies by location; Mass `m` stays constant everywhere!)",
      "Weight on Moon = `(1/6) × Weight on Earth`",
      "Pressure = `Thrust / Area` (Unit: Pascal, Pa)",
    ],
    analogy:
      "You drop a pebble and it falls toward Earth—Earth ALSO pulls tiny invisible force back, just like an invisible rubber band between every pair of masses!",
    questions: [
      {
        q: "If distance between two objects is doubled, what happens to gravitational force?",
        a: "Since `F ∝ 1/d²`, doubling distance makes force `1 / 2² = 1/4` of its original value.",
      },
    ],
    mistakes: [
      "Confusing `G` (Universal Constant everywhere) with `g` (acceleration due to gravity on a planet).",
    ],
  },
  {
    keywords: ["triangle", "similar", "bpt", "thales", "congruent", "pythagoras"],
    summary:
      "Similar triangles have the exact same shape (equal corresponding angles) and sides in the same ratio. Thales' Basic Proportionality Theorem (BPT) is the backbone of Class 10 Triangles.",
    formulas: [
      "**BPT (Thales Theorem):** If `DE ∥ BC` in ΔABC, then `AD/DB = AE/EC`.",
      "**Similarity Criteria:** `AAA` (or `AA`), `SAS`, and `SSS`.",
      "Ratio of perimeters of similar triangles = Ratio of corresponding sides.",
    ],
    analogy:
      "Zooming a photo on your phone creates a **similar triangle**: angles stay identical, while every side scales up by the same zoom factor!",
    questions: [
      {
        q: "State AA Similarity Criterion.",
        a: "If two angles of one triangle are respectively equal to two angles of another triangle, then the two triangles are similar.",
      },
    ],
    mistakes: [
      "Writing vertices in the wrong order in `ΔABC ~ ΔPQR` — corresponding equal angles must match position by position!",
    ],
  },
  {
    keywords: ["carbon", "covalent", "alkane", "alkene", "alkyne", "iupac", "ethanol", "ethanoic", "soap"],
    summary:
      "Carbon forms 4 covalent bonds (tetravalency) and links with itself in long chains/rings (catenation), creating millions of organic compounds.",
    formulas: [
      "Alkanes (single bond): `CₙH₂ₙ₊₂`",
      "Alkenes (double bond): `CₙH₂ₙ`",
      "Alkynes (triple bond): `CₙH₂ₙ₋₂`",
      "Esterification: `CH₃COOH + C₂H₅OH → CH₃COOC₂H₅ + H₂O` (sweet-smelling ester)",
    ],
    analogy:
      "Think of a carbon atom like a connector with **4 hands**: it can hold hydrogen, oxygen, or another carbon atom in chains, branches, or rings!",
    questions: [
      {
        q: "Why are soaps ineffective in hard water?",
        a: "Calcium and magnesium ions in hard water react with soap to form insoluble sticky scum, whereas detergents stay effective.",
      },
    ],
    mistakes: [
      "Showing ionic bonds for carbon — carbon shares electrons to form **covalent** bonds because gaining or losing 4 electrons requires too much energy.",
    ],
  },
];

function findTopicMatch(queryText: string): TopicCheatEntry | null {
  const lower = queryText.toLowerCase();
  let best: TopicCheatEntry | null = null;
  let bestScore = 0;

  for (const entry of NCERT_KNOWLEDGE_BASE) {
    let score = 0;
    for (const kw of entry.keywords) {
      if (lower.includes(kw)) {
        score += kw.length > 5 ? 3 : 2;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      best = entry;
    }
  }
  return bestScore > 0 ? best : null;
}

export interface FreeTutorChatParams {
  message: string;
  persona?: "crew" | AgentId;
  deepThinking?: boolean;
  studentContext?: StudentProfileContext;
  hasImage?: boolean;
  investigationContext?: {
    topic?: string;
    claims?: ResearchClaim[];
    reportMarkdown?: string;
  };
}

/**
 * 100% Free Built-In NCERT/CBSE Study Tutor Engine.
 * Responds cleanly with zero API key or server dependency (runs identically on Vercel static sites and localhost).
 */
export function generateFreeLocalTutorReply(
  params: FreeTutorChatParams
): string {
  const {
    message,
    persona = "crew",
    deepThinking = false,
    studentContext,
    hasImage = false,
    investigationContext,
  } = params;

  const cls = studentContext?.studentClass || "Class 10";
  const subj = studentContext?.subject || "Science";
  const lesson = studentContext?.lessonTitle || "";
  const cleanMsg = message.trim() || "Explain this concept simply.";

  const combinedSearchText = `${cleanMsg} ${lesson} ${subj} ${
    investigationContext?.topic || ""
  }`;
  const matched = findTopicMatch(combinedSearchText);

  const personaHeader: Record<"crew" | AgentId, string> = {
    crew: `### Tutorix Free Study Tutor (${cls} CBSE · ${subj})`,
    researcher: `### Elena · Concept Explorer (${cls} CBSE · ${subj})`,
    fact_checker: `### Marcus · Doubt & Formula Solver (${cls} CBSE · ${subj})`,
    editor: `### Clara · Exam Notes Coach (${cls} CBSE · ${subj})`,
  };

  const lower = cleanMsg.toLowerCase();
  const wantsQuiz =
    lower.includes("question") ||
    lower.includes("quiz") ||
    lower.includes("mcq") ||
    lower.includes("important") ||
    lower.includes("test");
  const wantsFormula =
    lower.includes("formula") ||
    lower.includes("numerical") ||
    lower.includes("solve") ||
    lower.includes("step");

  const lines: string[] = [personaHeader[persona]];

  if (hasImage) {
    lines.push(
      `> **Image Note:** Free offline tutor mode cannot read pixels inside your image file directly. Below is the guided NCERT method for **${
        lesson || subj
      }** — if you type the printed question text or numbers here, I will solve the exact steps right away!`
    );
  }

  lines.push(
    `**Your Question:** *${cleanMsg.slice(0, 220)}${
      cleanMsg.length > 220 ? "..." : ""
    }*`
  );

  if (matched) {
    lines.push(`#### 1. Crystal-Clear Concept\n${matched.summary}`);
    lines.push(`#### 2. Everyday Analogy\n${matched.analogy}`);
    lines.push(
      `#### 3. Key NCERT Formulas & Rules\n${matched.formulas
        .map((f) => `- ${f}`)
        .join("\n")}`
    );

    if (wantsQuiz || deepThinking) {
      lines.push(
        `#### 4. Important CBSE Questions & Answers\n${matched.questions
          .map(
            (qa, idx) =>
              `**Q${idx + 1}.** ${qa.q}\n- **Answer:** ${qa.a}`
          )
          .join("\n\n")}`
      );
    } else if (wantsFormula) {
      lines.push(
        `#### 4. 4-Step Numerical / Answer Template\n1. **Write Given Data** with proper SI units.\n2. **State the Exact Formula / Law** (worth 0.5–1 step mark in CBSE!).\n3. **Substitute Cleanly** and check signs/units.\n4. **Box the Final Answer** with units.`
      );
    }

    lines.push(
      `#### Common Mistakes to Avoid\n${matched.mistakes
        .map((m) => `- ${m}`)
        .join("\n")}`
    );
  } else {
    const contextClaims = (investigationContext?.claims || []).slice(0, 4);
    const topicTitle = lesson || subj;

    lines.push(
      `#### 1. Simple Explanation (${topicTitle})\nIn **${cls} CBSE ${subj}**, mastering **${topicTitle}** comes down to 3 clear pillars:\n- **Exact NCERT Definition:** Write key textbook terms clearly because CBSE marking schemes award marks for specific keywords.\n- **How It Works (Cause → Effect):** Ask *why* each step happens instead of memorising blindly.\n- **Application & Examples:** Practice 2 NCERT in-text examples and 2 back-exercise questions from ${topicTitle}.`
    );

    if (contextClaims.length > 0) {
      lines.push(
        `#### 2. Verified Key Facts From Your Active Lesson\n${contextClaims
          .map((c) => `- **${c.category}:** ${c.statement}`)
          .join("\n")}`
      );
    } else {
      lines.push(
        `#### 2. Step-by-Step Method to Solve Doubt\n1. **Break the question down:** Identify what chapter concept or law it points to in **${topicTitle}**.\n2. **Write what is given & what to find:** Even in theory questions, structure your answer in 3 crisp bullet points.\n3. **Connect a real-life example:** Adding a 1-line example makes your answer stand out to examiners.`
      );
    }

    lines.push(
      `#### 3. Quick Exam Checklist for ${topicTitle}\n- Can you define the main concept in 2 clear sentences?\n- Do you know the key formulas / units / dates or labelled diagram for **${topicTitle}**?\n- Try typing a specific formula, subtopic, or numerical from your book and I will break it down step by step!`
    );
  }

  lines.push(
    `\n*Need a simpler analogy or want me to quiz you on **${
      lesson || subj
    }**? Just ask below!*`
  );

  return lines.join("\n\n");
}

/**
 * Free built-in Blackhole Rescue response when remote AI API is unavailable or static-hosted on Vercel.
 */
export function generateFreeLocalBlackholeReply(params: {
  topic: string;
  mode: BlackholeMode;
  studentContext?: StudentProfileContext;
}): string {
  const cls = params.studentContext?.studentClass || "Class 10";
  const subj = params.studentContext?.subject || "Science";
  const topicName =
    params.topic.trim() ||
    params.studentContext?.lessonTitle ||
    `${cls} ${subj}`;
  const matched = findTopicMatch(`${topicName} ${subj}`);

  if (params.mode === "cheatsheet") {
    const items = matched
      ? matched.formulas
      : [
          `Core definitions & NCERT keywords for **${topicName}**`,
          `Primary rules / equations / relationships in **${subj}**`,
          `Standard SI units, exceptions & diagram labels`,
        ];
    return `## Blackhole Formula & Cheat-Sheet: ${topicName} (${cls})\n\n### Must-Know Rules & Formulas\n${items
      .map((f) => `- ${f}`)
      .join("\n")}\n\n### Traps That Cost Easy Marks\n${
      matched
        ? matched.mistakes.map((m) => `- ${m}`).join("\n")
        : "- Skipping units or mixing up definitions vs. examples.\n- Ignoring NCERT in-text activity reasons."
    }`;
  }

  if (params.mode === "crash") {
    return `## 5-Minute Crash Rescue: ${topicName} (${cls})\n\n### 1. The Big Picture in 60 Seconds\n${
      matched
        ? matched.analogy
        : `Think of **${topicName}** as a connected chain of cause and effect in ${subj}: learn the main idea first, then plug in the rules.`
    }\n\n### 2. Core Foundation\n${
      matched
        ? matched.summary
        : `Focus on the primary NCERT definition, one clean diagram/equation, and 2 solved textbook examples from **${topicName}**.`
    }\n\n### 3. Quick Practice\n${
      matched
        ? matched.questions
            .map((qa, i) => `**Q${i + 1}.** ${qa.q}\n> ${qa.a}`)
            .join("\n\n")
        : `- Read the bold headings of **${topicName}** in NCERT and explain each one aloud in 2 lines.`
    }`;
  }

  if (params.mode === "questions") {
    const qList = matched?.questions || [
      {
        q: `State the central law/principle of ${topicName} with one daily-life application.`,
        a: `Write the exact NCERT statement first, then add 1 real-world example for full 2/3-mark credit.`,
      },
      {
        q: `Explain the most important process/derivation or case study in ${topicName}.`,
        a: `Structure into: Given/Setup → Core Principle → Diagram/Formula → Final Conclusion.`,
      },
    ];
    return `## Top Repeated CBSE Pattern: ${topicName} (${cls})\n\n${qList
      .map(
        (qa, idx) =>
          `### Question ${idx + 1}\n**Q:** ${qa.q}\n\n**Scoring Answer:** ${qa.a}`
      )
      .join("\n\n")}\n\n### CBSE Step-Marking Hack\n- Always write **Given**, **Formula**, and **Final Unit** on separate lines so you lock in partial marks even if a calculation slips!`;
  }

  // Default: Last-Night Exam Survival
  return `## Last-Night 80/20 Survival Kit: ${topicName} (${cls} ${subj})\n\n### 1. The 20% That Scores 80% Marks\n${
    matched
      ? matched.summary
      : `Prioritise the core definitions, main laws/formulas, and NCERT back-exercise reasoning questions from **${topicName}**.`
  }\n\n### 2. High-Yield Rules & Formulas\n${
    matched
      ? matched.formulas.map((f) => `- ${f}`).join("\n")
      : "- Memorise the top 3 formulas/principles and 1 labelled diagram from this chapter."
  }\n\n### 3. Sure-Shot Practice\n${
    matched
      ? matched.questions
          .map((qa, i) => `- **Q${i + 1}:** ${qa.q}\n  *Ans:* ${qa.a}`)
          .join("\n")
      : "- Review NCERT in-text blue-box questions—CBSE directly picks 1-mark and 3-mark prompts from them!"
  }\n\n### 60-Second Panic Recap\n${
    matched
      ? matched.mistakes.map((m) => `- Watch out: ${m}`).join("\n")
      : "- Underline keywords in your exam answer sheet so the examiner spots points immediately."
  }`;
}
