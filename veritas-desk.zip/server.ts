import "dotenv/config";
import express from "express";
import fs from "fs";
import crypto from "crypto";
import path from "path";
import { fileURLToPath } from "url";
import { ThinkingLevel, Type } from "@google/genai";
import {
  extractGroundingSources,
  formatGeminiError,
  generateContentResilient,
  getGeminiClient,
  isRateLimitError,
  LITE_FALLBACK_MODEL,
  PRIMARY_MODEL,
  sendChatMessageResilient,
} from "./server/gemini.ts";
import {
  generateLessonOverviewWithGemini,
  runCrewInvestigation,
} from "./server/crewOrchestrator.ts";
import type {
  AgentId,
  BlackholeMode,
  LessonOverview,
  SavedQuestionPaper,
  StudentClass,
  StudentIdentity,
  StudentProfileContext,
  StudentTest,
  TestQuestion,
  TestSubmission,
  YoutubeVideoSuggestion,
} from "./src/types.ts";
import {
  generateFreeLocalBlackholeReply,
  generateFreeLocalTutorReply,
} from "./src/utils/freeLocalChat.ts";
import {
  buildYoutubeEmbedUrl,
  buildYoutubeThumbnailUrl,
  buildYoutubeWatchUrl,
  getCuratedYoutubeVideosForLesson,
} from "./src/utils/youtubeCurated.ts";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// -----------------------------------------------------------------------------
// KVS Teacher Auth & Persistent JSON Store (T.Sreenivas Rao)
// -----------------------------------------------------------------------------
const KVS_TEACHER_NAME = "T.Sreenivas Rao";
const KVS_TEACHER_PASSWORD = process.env.KVS_TEACHER_PASSWORD || "kvmlk";
const activeTeacherTokens = new Set<string>();

interface KvsStoreData {
  tests: StudentTest[];
  submissions: TestSubmission[];
  questionPapers: SavedQuestionPaper[];
}

const DATA_DIR = path.resolve(__dirname, "data");
const STORE_PATH = path.join(DATA_DIR, "kvs-store.json");

function loadKvsStore(): KvsStoreData {
  try {
    if (fs.existsSync(STORE_PATH)) {
      const raw = fs.readFileSync(STORE_PATH, "utf-8");
      const parsed = JSON.parse(raw) as Partial<KvsStoreData>;
      return {
        tests: Array.isArray(parsed.tests) ? parsed.tests : [],
        submissions: Array.isArray(parsed.submissions) ? parsed.submissions : [],
        questionPapers: Array.isArray(parsed.questionPapers)
          ? parsed.questionPapers
          : [],
      };
    }
  } catch {
    // Fallback to clean store
  }
  return { tests: [], submissions: [], questionPapers: [] };
}

function saveKvsStore(data: KvsStoreData): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(STORE_PATH, JSON.stringify(data, null, 2), "utf-8");
  } catch {
    // Ignore read-only fs errors gracefully
  }
}

const kvsStore: KvsStoreData = loadKvsStore();

function requireTeacherAuth(
  req: express.Request,
  res: express.Response
): boolean {
  const authHeader = req.headers.authorization || "";
  const token = authHeader.startsWith("Bearer ")
    ? authHeader.slice(7).trim()
    : "";
  if (!token || !activeTeacherTokens.has(token)) {
    res.status(401).json({
      error: "Teacher login required. Please log in as T.Sreenivas Rao.",
    });
    return false;
  }
  return true;
}

// In-memory syllabus cache so switching back between classes/boards is instant
const syllabusCache = new Map<
  string,
  {
    lessons: Array<{
      id: string;
      chapterNumber: string;
      title: string;
      summary: string;
      isLatestSync: boolean;
    }>;
    sources: Array<{ title: string; url: string; domain: string }>;
  }
>();

// In-memory Blackhole cache so repeat requests for the same topic/mode use zero quota
const blackholeCache = new Map<
  string,
  {
    content: string;
    sources: Array<{
      id: number;
      title: string;
      url: string;
      domain: string;
      discoveredBy: AgentId;
    }>;
  }
>();

// Persistent disk-backed Gemini Study Loop Overview cache (Full Summary + Key Points + All Details + Structure Diagram)
const OVERVIEWS_PATH = path.join(DATA_DIR, "lesson-overviews.json");
const STUDENT_PROFILES_PATH = path.join(DATA_DIR, "student-profiles.json");

function loadJsonFile<T>(filePath: string, fallback: T): T {
  try {
    if (fs.existsSync(filePath)) {
      const raw = fs.readFileSync(filePath, "utf-8");
      return JSON.parse(raw) as T;
    }
  } catch {
    // Ignore corrupt or missing file
  }
  return fallback;
}

function saveJsonFile(filePath: string, data: unknown): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
  } catch {
    // Ignore read-only fs errors gracefully
  }
}

function normalizeOverviewKey(
  studentClass = "",
  subject = "",
  lessonTitle = "",
  fallbackTopic = ""
): string {
  const cls = studentClass.trim().toLowerCase();
  const subj = subject.trim().toLowerCase();
  const lesson = lessonTitle.trim().toLowerCase();
  if (cls && subj && lesson) {
    return `${cls}|${subj}|${lesson}`;
  }
  return `${cls}|${subj}|${fallbackTopic.trim().slice(0, 140).toLowerCase()}`;
}

const persistedOverviews = loadJsonFile<Record<string, LessonOverview>>(
  OVERVIEWS_PATH,
  {}
);
const lessonOverviewCache = new Map<string, LessonOverview>(
  Object.entries(persistedOverviews)
);

function persistOverview(key: string, overview: LessonOverview): void {
  lessonOverviewCache.set(key, overview);
  saveJsonFile(
    OVERVIEWS_PATH,
    Object.fromEntries(lessonOverviewCache.entries())
  );
}

const studentProfilesStore: StudentIdentity[] = loadJsonFile<StudentIdentity[]>(
  STUDENT_PROFILES_PATH,
  []
);

function generateFixedStudentId(): string {
  const used = new Set(studentProfilesStore.map((p) => p.studentId));
  for (let i = 0; i < 40; i++) {
    const num = Math.floor(10000 + Math.random() * 89999);
    const candidate = `SS-IND-${num}`;
    if (!used.has(candidate)) return candidate;
  }
  return `SS-IND-${Date.now().toString().slice(-6)}`;
}

// Track active silent subject prefetch jobs so we never duplicate work
const activeSubjectPrefetches = new Set<string>();

interface PrefetchLessonItem {
  chapterNumber?: string;
  title: string;
  summary?: string;
}

async function runSilentSubjectPrefetch(
  studentClass: StudentClass,
  subject: string,
  lessons: PrefetchLessonItem[]
): Promise<void> {
  const jobKey = `${studentClass}|${subject}`.toLowerCase();
  if (activeSubjectPrefetches.has(jobKey)) return;
  activeSubjectPrefetches.add(jobKey);

  try {
    const ai = getGeminiClient();
    for (const lesson of lessons) {
      const key = normalizeOverviewKey(studentClass, subject, lesson.title);
      if (lessonOverviewCache.has(key)) continue;

      const topicPrompt = `${studentClass} CBSE ${subject} — ${
        lesson.chapterNumber || ""
      }: ${lesson.title}. ${
        lesson.summary || ""
      } Cover ONLY this lesson with full summary, key points, all subtopics, formulas, and examples.`;

      try {
        const overview = await generateLessonOverviewWithGemini(
          ai,
          topicPrompt,
          {
            studentClass,
            board: "CBSE",
            subject,
            lessonTitle: lesson.title,
          },
          undefined,
          true
        );
        persistOverview(key, overview);
        await new Promise((r) => setTimeout(r, 350));
      } catch (err) {
        if (isRateLimitError(err)) {
          // Stop quiet background loop cleanly on rate limit; remaining chapters load on demand
          break;
        }
      }
    }
  } catch {
    // Missing API key or offline; skip background prefetch gracefully
  } finally {
    activeSubjectPrefetches.delete(jobKey);
  }
}

async function createServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: "18mb" }));

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: "studysphere-ai" });
  });

  // ---------------------------------------------------------------------------
  // 0a. All-India Student Registration (Name, Board, Class) & Fixed Student ID
  // ---------------------------------------------------------------------------
  app.post("/api/student/register", (req, res) => {
    const {
      name,
      board = "CBSE",
      studentClass = "Class 10",
      existingStudentId = "",
      isKvStudent = false,
    } = req.body || {};

    const cleanName = typeof name === "string" ? name.trim() : "";
    const cleanBoard =
      typeof board === "string" && board.trim() ? board.trim() : "CBSE";
    const parsedKv = Boolean(isKvStudent);

    if (!cleanName) {
      res.status(400).json({
        error: "Student name is required.",
      });
      return;
    }

    // Preserve Fixed Student ID if studentId already exists or same name+board returns
    let existing = existingStudentId
      ? studentProfilesStore.find(
          (p) => p.studentId === String(existingStudentId).trim()
        )
      : undefined;

    if (!existing) {
      existing = studentProfilesStore.find(
        (p) =>
          p.name.toLowerCase() === cleanName.toLowerCase() &&
          (p.board || "CBSE").toLowerCase() === cleanBoard.toLowerCase()
      );
    }

    if (existing) {
      existing.name = cleanName;
      existing.board = cleanBoard;
      existing.studentClass =
        (studentClass as StudentClass) || existing.studentClass;
      existing.isKvStudent = parsedKv;
      saveJsonFile(STUDENT_PROFILES_PATH, studentProfilesStore);
      res.json({ profile: existing });
      return;
    }

    const created: StudentIdentity = {
      studentId: generateFixedStudentId(),
      name: cleanName,
      board: cleanBoard,
      studentClass: (studentClass as StudentClass) || "Class 10",
      isKvStudent: parsedKv,
      createdAt: new Date().toISOString(),
    };
    studentProfilesStore.unshift(created);
    saveJsonFile(STUDENT_PROFILES_PATH, studentProfilesStore);
    res.json({ profile: created });
  });

  // ---------------------------------------------------------------------------
  // 0. Automatic CBSE NCERT Complete Chapter Sync (Classes 6-12)
  // ---------------------------------------------------------------------------
  app.post("/api/syllabus/lessons", async (req, res) => {
    try {
      const {
        studentClass = "Class 10",
        subject = "Science",
      } = req.body || {};

      const cacheKey = `${studentClass}|CBSE|${subject}`;
      const cached = syllabusCache.get(cacheKey);
      if (cached) {
        res.json(cached);
        return;
      }

      const ai = getGeminiClient();

      // Step 1: Search live latest 2026-27 CBSE NCERT complete chapter list via Google Search
      const searchResp = await generateContentResilient(ai, {
        model: PRIMARY_MODEL,
        contents: `Find the COMPLETE official CBSE NCERT 2026-2027 chapter list (ALL chapters in the textbook, do not omit any) for ${studentClass} CBSE ${subject}. List every single chapter in order with its chapter number, book/part if applicable, and a clear 1-sentence student-friendly summary.`,
        config: {
          tools: [{ googleSearch: {} }],
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        },
      });

      const rawList = searchResp.text?.trim() || "";
      const sources = extractGroundingSources(searchResp);

      // Step 2: Structure ALL chapters into clean JSON array via fast gemini-3.1-flash-lite
      const jsonResp = await generateContentResilient(ai, {
        model: LITE_FALLBACK_MODEL,
        contents: `Convert this complete CBSE NCERT chapter list into a clean JSON array containing ALL chapters (every single one listed) for ${studentClass} CBSE ${subject}:\n\n${rawList}`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                chapterNumber: {
                  type: Type.STRING,
                  description: "e.g. Ch 1, Ch 2, History Ch 1",
                },
                title: {
                  type: Type.STRING,
                  description: "Clean chapter title",
                },
                summary: {
                  type: Type.STRING,
                  description: "1 clear sentence describing what students learn",
                },
              },
              required: ["chapterNumber", "title", "summary"],
            },
          },
        },
      });

      const parsed = JSON.parse((jsonResp.text || "[]").trim()) as Array<{
        chapterNumber: string;
        title: string;
        summary: string;
      }>;

      const lessons = parsed.map((item, idx) => ({
        id: `${cacheKey}-${idx}`,
        chapterNumber: item.chapterNumber || `Ch ${idx + 1}`,
        title: item.title,
        summary: item.summary,
        isLatestSync: true,
      }));

      const payload = { lessons, sources };
      if (lessons.length > 0) {
        syllabusCache.set(cacheKey, payload);
      }
      res.json(payload);
    } catch (err) {
      res
        .status(isRateLimitError(err) ? 429 : 500)
        .json({ error: formatGeminiError(err) });
    }
  });

  // ---------------------------------------------------------------------------
  // 1. SSE Streaming Student Study Loop
  // ---------------------------------------------------------------------------
  app.post("/api/crew/investigate", async (req, res) => {
    const { topic, depth, image, studentContext } = req.body || {};

    if (!topic || typeof topic !== "string" || !topic.trim()) {
      res.status(400).json({ error: "Please provide a study topic or lesson." });
      return;
    }

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders?.();

    const controller = new AbortController();
    req.on("close", () => {
      controller.abort();
    });

    const emit = (event: string, data: unknown) => {
      if (res.writableEnded) return;
      res.write(`event: ${event}\n`);
      res.write(`data: ${JSON.stringify(data)}\n\n`);
    };

    try {
      await runCrewInvestigation(
        {
          topic: topic.trim(),
          depth: depth === "deep" ? "deep" : "standard",
          studentContext: studentContext
            ? (studentContext as StudentProfileContext)
            : undefined,
          image:
            image &&
            typeof image.data === "string" &&
            typeof image.mimeType === "string"
              ? {
                  data: image.data,
                  mimeType: image.mimeType,
                  name: image.name,
                }
              : undefined,
        },
        emit,
        controller.signal
      );
    } catch (err) {
      if (!controller.signal.aborted) {
        emit("crew_error", { message: formatGeminiError(err) });
      }
    } finally {
      if (!res.writableEnded) {
        res.end();
      }
    }
  });

  // ---------------------------------------------------------------------------
  // 1b. Persistent Full Summary, Key Points, All Details & Structure Diagram
  // ---------------------------------------------------------------------------
  app.post("/api/study-loop/overview", async (req, res) => {
    try {
      const { topic, studentContext } = req.body || {};
      if (!topic || typeof topic !== "string" || !topic.trim()) {
        res.status(400).json({ error: "Please provide a lesson or topic." });
        return;
      }

      const sc = studentContext as StudentProfileContext | undefined;
      const cacheKey = normalizeOverviewKey(
        sc?.studentClass,
        sc?.subject,
        sc?.lessonTitle,
        topic
      );
      const cached = lessonOverviewCache.get(cacheKey);
      if (cached) {
        res.json({ lessonOverview: cached, cached: true });
        return;
      }

      const ai = getGeminiClient();
      const lessonOverview = await generateLessonOverviewWithGemini(
        ai,
        topic.trim(),
        sc
      );
      persistOverview(cacheKey, lessonOverview);
      res.json({ lessonOverview, cached: false });
    } catch (err) {
      res
        .status(isRateLimitError(err) ? 429 : 500)
        .json({ error: formatGeminiError(err) });
    }
  });

  // Silent subject-wide chapter auto-prefetch + instant cached lookup
  app.post("/api/study-loop/prefetch-subject", (req, res) => {
    const {
      studentClass = "Class 10",
      subject = "Science",
      lessons = [],
    } = req.body || {};

    const cleanLessons = Array.isArray(lessons)
      ? (lessons as PrefetchLessonItem[]).filter(
          (l) => typeof l?.title === "string" && l.title.trim().length > 0
        )
      : [];

    const cached: Record<string, LessonOverview> = {};
    const missing: PrefetchLessonItem[] = [];

    for (const lesson of cleanLessons) {
      const key = normalizeOverviewKey(
        String(studentClass),
        String(subject),
        lesson.title
      );
      const hit = lessonOverviewCache.get(key);
      if (hit) {
        cached[lesson.title] = hit;
      } else {
        missing.push(lesson);
      }
    }

    if (missing.length > 0) {
      void runSilentSubjectPrefetch(
        studentClass as StudentClass,
        String(subject),
        missing
      );
    }

    res.json({
      cached,
      cachedCount: Object.keys(cached).length,
      totalCount: cleanLessons.length,
      prefetchingRemaining: missing.length,
    });
  });

  // ---------------------------------------------------------------------------
  // 1c. Live YouTube Video Recommendations (PW / Next Toppers / Magnet Brains)
  // ---------------------------------------------------------------------------
  const youtubeCache = new Map<string, YoutubeVideoSuggestion[]>();

  async function searchYoutubeVideosByQuery(
    query: string,
    preferredBadge: string,
    limit = 1
  ): Promise<YoutubeVideoSuggestion[]> {
    const collected: YoutubeVideoSuggestion[] = [];
    const seenIds = new Set<string>();

    // Optional YouTube Data API v3 if configured cleanly in server env
    const ytApiKey = process.env.YOUTUBE_API_KEY;
    if (ytApiKey) {
      try {
        const apiUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=${Math.min(
          limit + 1,
          4
        )}&q=${encodeURIComponent(query)}&key=${encodeURIComponent(ytApiKey)}`;
        const apiRes = await fetch(apiUrl);
        if (apiRes.ok) {
          const json = (await apiRes.json()) as {
            items?: Array<{
              id?: { videoId?: string };
              snippet?: {
                title?: string;
                channelTitle?: string;
                thumbnails?: { high?: { url?: string }; medium?: { url?: string } };
              };
            }>;
          };
          for (const item of json.items || []) {
            const vid = item.id?.videoId;
            if (!vid || seenIds.has(vid)) continue;
            seenIds.add(vid);
            collected.push({
              id: `yt-api-${vid}`,
              title: item.snippet?.title || query,
              channelTitle: item.snippet?.channelTitle || preferredBadge,
              badge: preferredBadge,
              videoId: vid,
              thumbnailUrl:
                item.snippet?.thumbnails?.high?.url ||
                item.snippet?.thumbnails?.medium?.url ||
                buildYoutubeThumbnailUrl(vid),
              watchUrl: buildYoutubeWatchUrl(vid),
              embedUrl: buildYoutubeEmbedUrl(vid),
              searchQuery: query,
            });
            if (collected.length >= limit) break;
          }
          if (collected.length > 0) return collected;
        }
      } catch {
        // Fallback to oembed search scraping below
      }
    }

    try {
      const searchRes = await fetch(
        `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`,
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
          },
        }
      );
      if (searchRes.ok) {
        const html = await searchRes.text();
        const matches = Array.from(
          html.matchAll(/"videoId":"([a-zA-Z0-9_-]{11})"/g)
        ).map((m) => m[1]);
        const uniqueIds = Array.from(new Set(matches)).slice(0, limit + 2);
        for (const vid of uniqueIds) {
          if (seenIds.has(vid)) continue;
          try {
            const oembedRes = await fetch(
              `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${vid}&format=json`
            );
            if (!oembedRes.ok) continue;
            const oembed = (await oembedRes.json()) as {
              title?: string;
              author_name?: string;
              thumbnail_url?: string;
            };
            if (!oembed.title) continue;
            seenIds.add(vid);
            collected.push({
              id: `yt-live-${vid}`,
              title: oembed.title,
              channelTitle: oembed.author_name || preferredBadge,
              badge: preferredBadge,
              videoId: vid,
              thumbnailUrl: buildYoutubeThumbnailUrl(vid),
              watchUrl: buildYoutubeWatchUrl(vid),
              embedUrl: buildYoutubeEmbedUrl(vid),
              searchQuery: query,
            });
            if (collected.length >= limit) break;
          } catch {
            // Skip invalid candidate
          }
        }
      }
    } catch {
      // Fallback handled by caller
    }
    return collected;
  }

  app.post("/api/youtube/videos", async (req, res) => {
    const { studentContext, lessonTitle } = req.body || {};
    const ctx: StudentProfileContext = studentContext || {
      studentClass: "Class 10",
      board: "CBSE",
      subject: "Science",
      lessonTitle: typeof lessonTitle === "string" ? lessonTitle : "Electricity",
    };
    const title = String(lessonTitle || ctx.lessonTitle || ctx.subject).trim();
    const cacheKey = `${ctx.studentClass}|${ctx.subject}|${title}`.toLowerCase();

    const cached = youtubeCache.get(cacheKey);
    if (cached && cached.length > 0) {
      res.json({ videos: cached });
      return;
    }

    const fallback = getCuratedYoutubeVideosForLesson(ctx, title);
    try {
      const [pwResults, ntResults, mbResults] = await Promise.all([
        searchYoutubeVideosByQuery(
          `${ctx.studentClass} ${ctx.subject} ${title} Physics Wallah Foundation`,
          "Physics Wallah",
          1
        ),
        searchYoutubeVideosByQuery(
          `${ctx.studentClass} ${ctx.subject} ${title} Next Toppers`,
          "Next Toppers",
          1
        ),
        searchYoutubeVideosByQuery(
          `${ctx.studentClass} ${ctx.subject} ${title} Magnet Brains one shot`,
          "Magnet Brains",
          1
        ),
      ]);

      const merged: YoutubeVideoSuggestion[] = [];
      const usedVideoIds = new Set<string>();
      for (const item of [...pwResults, ...ntResults, ...mbResults, ...fallback]) {
        const keyId = item.videoId || item.id;
        if (usedVideoIds.has(keyId)) continue;
        usedVideoIds.add(keyId);
        merged.push(item);
        if (merged.length >= 4) break;
      }

      if (merged.length > 0) {
        youtubeCache.set(cacheKey, merged);
        res.json({ videos: merged });
        return;
      }
    } catch {
      // Serve curated videos cleanly
    }

    res.json({ videos: fallback });
  });

  app.get("/api/study-loop/cached-batch", (req, res) => {
    const studentClass = String(req.query.studentClass || "").trim().toLowerCase();
    const subject = String(req.query.subject || "").trim().toLowerCase();
    const prefix = `${studentClass}|${subject}|`;
    const cached: Record<string, LessonOverview> = {};

    for (const [k, v] of lessonOverviewCache.entries()) {
      if (k.startsWith(prefix)) {
        const titleKey = v.lessonTitle || k.slice(prefix.length);
        cached[titleKey] = v;
      }
    }

    res.json({
      cached,
      inProgress: activeSubjectPrefetches.has(`${studentClass}|${subject}`),
    });
  });

  // ---------------------------------------------------------------------------
  // 2. Standalone Textbook / Diagram / Homework Photo Analysis
  // ---------------------------------------------------------------------------
  app.post("/api/image/analyze", async (req, res) => {
    try {
      const { image, prompt, studentContext } = req.body || {};
      if (!image?.data || !image?.mimeType) {
        res.status(400).json({ error: "Image data and mimeType are required." });
        return;
      }

      const classNote = studentContext
        ? `Explain clearly for a ${studentContext.studentClass} CBSE (NCERT) ${studentContext.subject} student.`
        : "Explain clearly in simple, student-friendly steps.";

      const ai = getGeminiClient();
      const response = await generateContentResilient(ai, {
        model: PRIMARY_MODEL,
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: image.mimeType,
                data: image.data,
              },
            },
            {
              text:
                typeof prompt === "string" && prompt.trim()
                  ? `${prompt.trim()}\n${classNote}`
                  : `Inspect this textbook page, diagram, or question photo. ${classNote} Break down every label, formula, or problem step-by-step so it is easy to understand.`,
            },
          ],
        },
        config: {
          systemInstruction:
            "You are Elena Vance, Concept Explorer helping CBSE school students understand diagrams, formulas, and textbook questions clearly.",
          thinkingConfig: { thinkingLevel: ThinkingLevel.MEDIUM },
        },
      });

      res.json({
        analysis: response.text || "Unable to extract visual details.",
      });
    } catch (err) {
      res
        .status(isRateLimitError(err) ? 429 : 500)
        .json({ error: formatGeminiError(err) });
    }
  });

  // ---------------------------------------------------------------------------
  // 3. Multi-Turn Student Gemini Study Chat
  // ---------------------------------------------------------------------------
  app.post("/api/chat", async (req, res) => {
    try {
      const {
        message,
        history = [],
        persona = "crew",
        deepThinking = false,
        investigationContext,
        studentContext,
        image,
      } = req.body || {};

      if (
        (!message || typeof message !== "string" || !message.trim()) &&
        !image?.data
      ) {
        res.status(400).json({ error: "Message or image is required." });
        return;
      }

      const studentProfileBlock = studentContext
        ? `\nStudent Profile: ${studentContext.studentClass} · CBSE (NCERT) · Subject: ${studentContext.subject}${
            studentContext.lessonTitle
              ? ` · Current Lesson: "${studentContext.lessonTitle}"`
              : ""
          }. Tailor your vocabulary, examples, and CBSE exam tips strictly to this grade level so it is super easy to understand.`
        : "\nKeep explanations clear, structured, and easy for CBSE school students (Class 6 to 12) to understand.";

      const personaInstructions: Record<"crew" | AgentId, string> = {
        crew: "You represent the Student Study Crew (Elena - Concept Explorer, Marcus - Doubt & Fact-Checker, Clara - Study Notes Coach). Give super clear, encouraging, step-by-step explanations with everyday examples.",
        researcher:
          "You are Elena Vance, Concept Explorer. Explain concepts intuitively using simple everyday analogies, clear definitions, and live syllabus examples.",
        fact_checker:
          "You are Marcus Thorne, Doubt Solver & Fact-Checker. Help students spot common misconceptions, verify formulas/units, and test their understanding gently.",
        editor:
          "You are Clara Lin, Study Notes & Exam Coach. Summarize concepts neatly, create quick-revision bullet points, tables, and practice questions with solutions.",
      };

      const selectedPersona: "crew" | AgentId =
        persona === "researcher" ||
        persona === "fact_checker" ||
        persona === "editor"
          ? persona
          : "crew";

      const contextBlock = investigationContext?.topic
        ? `\n\nActive Study Topic: ${
            investigationContext.topic
          }\nVerified Key Points:\n${(investigationContext.claims || [])
            .slice(0, 8)
            .map(
              (c: { id: string; status: string; statement: string }) =>
                `- [${c.id} · ${c.status}] ${c.statement}`
            )
            .join("\n")}\nStudy Notes Excerpt:\n${String(
            investigationContext.reportMarkdown || ""
          ).slice(0, 3500)}`
        : "";

      const systemInstruction = `${personaInstructions[selectedPersona]}${studentProfileBlock}${contextBlock}\nUse Google Search grounding whenever fresh curriculum details or verified facts are helpful.`;

      const ai = getGeminiClient();

      const formattedHistory = Array.isArray(history)
        ? history
            .filter(
              (turn: { role?: string; text?: string }) =>
                (turn.role === "user" || turn.role === "model") &&
                typeof turn.text === "string" &&
                turn.text.trim().length > 0
            )
            .slice(-14)
            .map((turn: { role: "user" | "model"; text: string }) => ({
              role: turn.role,
              parts: [{ text: turn.text }],
            }))
        : [];

      const userParts: Array<
        { text: string } | { inlineData: { mimeType: string; data: string } }
      > = [];
      if (image?.data && image?.mimeType) {
        userParts.push({
          inlineData: { mimeType: image.mimeType, data: image.data },
        });
      }
      userParts.push({
        text:
          typeof message === "string" && message.trim()
            ? message.trim()
            : "Please explain this uploaded study image step by step.",
      });

      const chatMessage =
        userParts.length === 1 && "text" in userParts[0]
          ? userParts[0].text
          : userParts;

      const response = await sendChatMessageResilient(ai, {
        history: formattedHistory,
        config: {
          systemInstruction,
          tools: [{ googleSearch: {} }],
          thinkingConfig: {
            thinkingLevel: deepThinking
              ? ThinkingLevel.HIGH
              : ThinkingLevel.MEDIUM,
          },
        },
        message: chatMessage,
      });

      const rawSources = extractGroundingSources(response);
      const sources = rawSources.map((s, idx) => ({
        id: idx + 1,
        title: s.title,
        url: s.url,
        domain: s.domain,
        discoveredBy: (selectedPersona === "crew"
          ? "researcher"
          : selectedPersona) as AgentId,
      }));

      res.json({
        reply: response.text || "No response generated.",
        sources,
      });
    } catch {
      const {
        message = "",
        persona = "crew",
        deepThinking = false,
        investigationContext,
        studentContext,
        image,
      } = req.body || {};
      const selectedPersona: "crew" | AgentId =
        persona === "researcher" ||
        persona === "fact_checker" ||
        persona === "editor"
          ? persona
          : "crew";
      const fallbackReply = generateFreeLocalTutorReply({
        message: typeof message === "string" ? message : "",
        persona: selectedPersona,
        deepThinking: Boolean(deepThinking),
        studentContext,
        hasImage: Boolean(image?.data),
        investigationContext,
      });
      res.json({
        reply: fallbackReply,
        sources: [],
        freeFallback: true,
      });
    }
  });

  // ---------------------------------------------------------------------------
  // 4. BLACKHOLE — High-Power Backbencher Exam & Concept Rescue Engine
  // ---------------------------------------------------------------------------
  app.post("/api/blackhole/rescue", async (req, res) => {
    try {
      const {
        topic,
        mode = "survival",
        studentContext,
        image,
      } = req.body || {};

      if ((!topic || typeof topic !== "string" || !topic.trim()) && !image?.data) {
        res.status(400).json({
          error: "Enter a chapter/topic or upload a question photo to activate Blackhole.",
        });
        return;
      }

      const cls = studentContext?.studentClass || "Class 10";
      const subj = studentContext?.subject || "Science";
      const lesson = studentContext?.lessonTitle
        ? ` — Lesson: "${studentContext.lessonTitle}"`
        : "";
      const targetTopic = (topic || "").trim() || `${cls} CBSE ${subj}${lesson}`;

      const modePrompts: Record<string, string> = {
        survival: `MODE: LAST-NIGHT EXAM SURVIVAL (80/20 RULE).
The student has an exam tomorrow and zero time for fluff. Give:
1. **The 20% That Scores 80% Marks**: The 4–5 highest-weightage sub-topics CBSE actually tests.
2. **Ultra-Short Core Explanations**: Zero textbook bloat—plain, memorable street-smart language.
3. **Sure-Shot 3-Mark & 5-Mark Exam Prompts + Exact Scoring Bullet Answers**.
4. **Memory Mnemonics & 60-Second Panic Recap**.`,
        crash: `MODE: ZERO-TO-HERO 5-MINUTE CRASH.
The student missed every class on this chapter and knows nothing yet. Give:
1. **The Whole Chapter as a 1-Minute Real-Life Story / Analogy** (funny, unforgettable, relatable).
2. **3 Building Blocks Explained From Scratch** (step-by-step, zero assumed prior knowledge).
3. **Why This Actually Matters + 2 Quick Solved Examples** so they immediately get how problems work.`,
        cheatsheet: `MODE: BLACKHOLE CHEAT-SHEET & FORMULA MATRIX.
Compress the entire topic into a razor-sharp revision dashboard:
1. **Clean Markdown Table of Every Formula, Law, Unit & Symbol** (or Key Dates/Terms/Events for humanities).
2. **One-Line Definitions (Exam-Ready Keywords)** highlighted in bold.
3. **Common Traps That Cost Easy Marks** (sign errors, unit conversions, exceptions).`,
        questions: `MODE: TOP REPEATED CBSE QUESTIONS & STEP-MARKING HACKS.
Use Google Search to check real CBSE sample paper / PYQ patterns for ${cls} ${subj}:
1. **Top 5 Most Repeated CBSE Questions** (1-mark MCQ, 2-mark, 3-mark, and 5-mark Case/Long Answer) with crisp model answers.
2. **CBSE Step-Marking Hacks**: How to structure diagrams, given/to-find steps, and keywords to grab partial and full marks fast.`,
      };

      const selectedModePrompt =
        modePrompts[typeof mode === "string" ? mode : "survival"] ||
        modePrompts.survival;

      const modeKey = typeof mode === "string" ? mode : "survival";
      const bhCacheKey = !image?.data
        ? `${cls}|${subj}|${modeKey}|${targetTopic.toLowerCase()}`
        : null;

      if (bhCacheKey) {
        const cached = blackholeCache.get(bhCacheKey);
        if (cached) {
          res.json(cached);
          return;
        }
      }

      const ai = getGeminiClient();
      const parts: Array<
        { text: string } | { inlineData: { mimeType: string; data: string } }
      > = [];
      if (image?.data && image?.mimeType) {
        parts.push({
          inlineData: { mimeType: image.mimeType, data: image.data },
        });
      }
      parts.push({
        text: `Student Profile: ${cls} CBSE (NCERT) · Subject: ${subj}${lesson}
Target Topic / Question: "${targetTopic}"

${selectedModePrompt}
${
  image?.data
    ? "\nAlso solve/explain every question, diagram, or formula visible in the attached photo step-by-step!"
    : ""
}`,
      });

      const response = await generateContentResilient(ai, {
        model: PRIMARY_MODEL,
        contents: { parts },
        config: {
          systemInstruction:
            "You are BLACKHOLE, the ultimate high-speed academic rescue engine built for CBSE backbenchers (Classes 6–12). Be razor-sharp, street-smart, encouraging, strictly accurate to NCERT/CBSE, and allergic to boring walls of text.",
          tools: [{ googleSearch: {} }],
          thinkingConfig: { thinkingLevel: ThinkingLevel.MEDIUM },
        },
      });

      const rawSources = extractGroundingSources(response);
      const sources = rawSources.map((s, idx) => ({
        id: idx + 1,
        title: s.title,
        url: s.url,
        domain: s.domain,
        discoveredBy: "researcher" as AgentId,
      }));

      const payload = {
        content: response.text || "Unable to generate Blackhole rescue pack.",
        sources,
      };
      if (bhCacheKey && payload.content) {
        if (blackholeCache.size >= 60) {
          const oldestKey = blackholeCache.keys().next().value;
          if (oldestKey) blackholeCache.delete(oldestKey);
        }
        blackholeCache.set(bhCacheKey, payload);
      }

      res.json(payload);
    } catch {
      const { topic = "", mode = "survival", studentContext } = req.body || {};
      const fallbackMarkdown = generateFreeLocalBlackholeReply({
        topic: typeof topic === "string" ? topic : "",
        mode: (typeof mode === "string" ? mode : "survival") as BlackholeMode,
        studentContext,
      });
      res.json({
        content: fallbackMarkdown,
        sources: [],
        freeFallback: true,
      });
    }
  });

  // ---------------------------------------------------------------------------
  // 5. KVS TEACHER PORTAL — Auth, Student Test Builder & Question Paper Maker
  // ---------------------------------------------------------------------------
  app.post("/api/teacher/login", (req, res) => {
    const { teacherName, password } = req.body || {};
    const cleanName = typeof teacherName === "string" ? teacherName.trim() : "";
    const cleanPass = typeof password === "string" ? password.trim() : "";

    if (cleanName !== KVS_TEACHER_NAME) {
      res.status(401).json({
        error: `Only authorized KVS faculty (${KVS_TEACHER_NAME}) can access the Teacher Portal.`,
      });
      return;
    }

    if (cleanPass !== KVS_TEACHER_PASSWORD) {
      res.status(401).json({
        error: "Incorrect KVS teacher password. Please try again.",
      });
      return;
    }

    const token = crypto.randomBytes(24).toString("hex");
    activeTeacherTokens.add(token);
    res.json({
      token,
      teacherName: KVS_TEACHER_NAME,
      organization: "KVS",
    });
  });

  app.post("/api/teacher/logout", (req, res) => {
    const authHeader = req.headers.authorization || "";
    const token = authHeader.startsWith("Bearer ")
      ? authHeader.slice(7).trim()
      : "";
    if (token) activeTeacherTokens.delete(token);
    res.json({ ok: true });
  });

  app.get("/api/teacher/verify", (req, res) => {
    const authHeader = req.headers.authorization || "";
    const token = authHeader.startsWith("Bearer ")
      ? authHeader.slice(7).trim()
      : "";
    if (!token || !activeTeacherTokens.has(token)) {
      res.status(401).json({ valid: false });
      return;
    }
    res.json({
      valid: true,
      teacherName: KVS_TEACHER_NAME,
      organization: "KVS",
    });
  });

  // AI-generate interactive MCQ test questions for KVS Teacher
  app.post("/api/teacher/generate-test", async (req, res) => {
    if (!requireTeacherAuth(req, res)) return;
    try {
      const {
        studentClass = "Class 10",
        subject = "Science",
        chapter = "",
        questionCount = 5,
        difficulty = "CBSE Standard",
      } = req.body || {};

      const count = Math.min(Math.max(Number(questionCount) || 5, 1), 20);
      const ai = getGeminiClient();

      const resp = await generateContentResilient(ai, {
        model: PRIMARY_MODEL,
        contents: `Create ${count} high-quality CBSE NCERT multiple-choice test questions for ${studentClass} ${subject}${
          chapter ? ` focused on chapter/topic "${chapter}"` : ""
        }. Difficulty level: ${difficulty}.
Each question must have exactly 4 distinct options (A, B, C, D), the 0-based correctIndex (0..3), marks (1 or 2), and a clear student-friendly step-by-step explanation.`,
        config: {
          systemInstruction:
            "You are assisting KVS Senior Faculty (T.Sreenivas Rao) to design crisp, accurate CBSE NCERT student assessments.",
          thinkingConfig: { thinkingLevel: ThinkingLevel.MEDIUM },
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                correctIndex: { type: Type.INTEGER },
                marks: { type: Type.INTEGER },
                explanation: { type: Type.STRING },
              },
              required: [
                "question",
                "options",
                "correctIndex",
                "marks",
                "explanation",
              ],
            },
          },
        },
      });

      const parsed = JSON.parse((resp.text || "[]").trim()) as Array<{
        question: string;
        options: string[];
        correctIndex: number;
        marks: number;
        explanation: string;
      }>;

      const questions: TestQuestion[] = parsed.slice(0, count).map((q, idx) => {
        const opts = Array.isArray(q.options) ? q.options.slice(0, 4) : [];
        while (opts.length < 4) opts.push(`Option ${opts.length + 1}`);
        const cIdx =
          typeof q.correctIndex === "number" &&
          q.correctIndex >= 0 &&
          q.correctIndex <= 3
            ? q.correctIndex
            : 0;
        return {
          id: `q-${Date.now()}-${idx}`,
          question: q.question,
          options: [opts[0], opts[1], opts[2], opts[3]],
          correctIndex: cIdx,
          marks: typeof q.marks === "number" && q.marks > 0 ? q.marks : 1,
          explanation: q.explanation || "Refer to CBSE NCERT textbook.",
        };
      });

      res.json({ questions });
    } catch (err) {
      res
        .status(isRateLimitError(err) ? 429 : 500)
        .json({ error: formatGeminiError(err) });
    }
  });

  // AI-generate full CBSE/KVS Printable Question Paper + Marking Scheme
  app.post("/api/teacher/question-paper", async (req, res) => {
    if (!requireTeacherAuth(req, res)) return;
    try {
      const {
        schoolName = "Kendriya Vidyalaya (KVS)",
        studentClass = "Class 10",
        subject = "Science",
        chapters = "",
        examType = "Periodic Test / Unit Exam",
        totalMarks = 40,
        duration = "90 Minutes",
        blueprint = "Section A: MCQs (1M), Section B: Very Short Answer (2M), Section C: Short Answer (3M), Section D: Case-Based (4M), Section E: Long Answer (5M)",
      } = req.body || {};

      const ai = getGeminiClient();
      const resp = await generateContentResilient(ai, {
        model: PRIMARY_MODEL,
        contents: `Generate an official, ready-to-print CBSE / KVS Question Paper AND a separate Answer Key & Marking Scheme.
School: ${schoolName}
Prepared By: ${KVS_TEACHER_NAME} (KVS)
Class: ${studentClass} CBSE (NCERT)
Subject: ${subject}
Chapters / Syllabus Scope: ${chapters || "Full Term CBSE Syllabus"}
Examination Type: ${examType}
Maximum Marks: ${totalMarks}
Time Allowed: ${duration}
Section Blueprint: ${blueprint}

Use Google Search to follow the latest 2025-26 / 2026-27 CBSE Competency-Based Question Paper pattern (assertion-reason, case study, numericals/application where applicable). Make sure total marks across all sections add up cleanly to ${totalMarks} marks.`,
        config: {
          systemInstruction:
            "You are an expert CBSE / KVS Question Paper Setter working for T.Sreenivas Rao. Produce clean, well-formatted Markdown with exact mark brackets [1], [2], [3], [4], [5], General Instructions, and internal choices.",
          tools: [{ googleSearch: {} }],
          thinkingConfig: { thinkingLevel: ThinkingLevel.MEDIUM },
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: {
                type: Type.STRING,
                description: "Clean exam title",
              },
              paperMarkdown: {
                type: Type.STRING,
                description:
                  "Complete formatted Markdown question paper with school header, instructions, and Sections A-E.",
              },
              answerKeyMarkdown: {
                type: Type.STRING,
                description:
                  "Complete step-by-step Marking Scheme and Answer Key matching every question.",
              },
            },
            required: ["title", "paperMarkdown", "answerKeyMarkdown"],
          },
        },
      });

      const generated = JSON.parse((resp.text || "{}").trim()) as {
        title?: string;
        paperMarkdown?: string;
        answerKeyMarkdown?: string;
      };

      const saved: SavedQuestionPaper = {
        id: `qp-${Date.now()}`,
        title:
          generated.title ||
          `${studentClass} ${subject} — ${examType}`,
        schoolName,
        teacherName: KVS_TEACHER_NAME,
        studentClass,
        subject,
        examType,
        totalMarks: Number(totalMarks) || 40,
        duration,
        paperMarkdown: generated.paperMarkdown || "",
        answerKeyMarkdown: generated.answerKeyMarkdown || "",
        createdAt: new Date().toISOString(),
      };

      kvsStore.questionPapers.unshift(saved);
      saveKvsStore(kvsStore);

      res.json({ questionPaper: saved });
    } catch (err) {
      res
        .status(isRateLimitError(err) ? 429 : 500)
        .json({ error: formatGeminiError(err) });
    }
  });

  // List & Manage Saved Question Papers (Teacher only)
  app.get("/api/question-papers", (req, res) => {
    if (!requireTeacherAuth(req, res)) return;
    res.json({ questionPapers: kvsStore.questionPapers });
  });

  app.delete("/api/question-papers/:id", (req, res) => {
    if (!requireTeacherAuth(req, res)) return;
    kvsStore.questionPapers = kvsStore.questionPapers.filter(
      (p) => p.id !== req.params.id
    );
    saveKvsStore(kvsStore);
    res.json({ ok: true });
  });

  function generateUniqueTestCode(): string {
    const existing = new Set(
      kvsStore.tests.map((t) => (t.testCode || "").toUpperCase())
    );
    for (let i = 0; i < 30; i++) {
      const digits = Math.floor(1000 + Math.random() * 9000);
      const candidate = `KVS-${digits}`;
      if (!existing.has(candidate)) return candidate;
    }
    return `KVS-${Date.now().toString().slice(-5)}`;
  }

  // Public list of published tests for students (hides answer keys and testCodes unless teacher)
  app.get("/api/tests", (req, res) => {
    const authHeader = req.headers.authorization || "";
    const token = authHeader.startsWith("Bearer ")
      ? authHeader.slice(7).trim()
      : "";
    const isTeacher = Boolean(token && activeTeacherTokens.has(token));

    if (isTeacher) {
      res.json({
        tests: kvsStore.tests,
        submissions: kvsStore.submissions,
      });
      return;
    }

    const publicTests = kvsStore.tests
      .filter((t) => t.published)
      .map((t) => ({
        id: t.id,
        testCode: "",
        title: t.title,
        studentClass: t.studentClass,
        subject: t.subject,
        chapter: t.chapter,
        durationMinutes: t.durationMinutes,
        createdBy: t.createdBy,
        createdAt: t.createdAt,
        published: t.published,
        questionCount: t.questions.length,
        questions: [],
      }));
    res.json({ tests: publicTests });
  });

  // Student enters a Teacher-generated Test Code to start the exam
  app.post("/api/tests/join", (req, res) => {
    const rawCode =
      typeof req.body?.testCode === "string"
        ? req.body.testCode.trim().toUpperCase()
        : "";
    if (!rawCode) {
      res.status(400).json({ error: "Please enter a valid KVS test code." });
      return;
    }

    const match = kvsStore.tests.find(
      (t) =>
        t.published && (t.testCode || "").trim().toUpperCase() === rawCode
    );
    if (!match) {
      res.status(404).json({
        error: `No active KVS test found for code "${rawCode}". Check the code shared by your teacher.`,
      });
      return;
    }

    const sanitizedTest: StudentTest = {
      ...match,
      questions: match.questions.map((q) => ({
        id: q.id,
        question: q.question,
        options: q.options,
        marks: q.marks,
        correctIndex: -1,
        explanation: "",
      })),
    };

    res.json({ test: sanitizedTest });
  });

  // Teacher creates/publishes a student test and generates its Test Code
  app.post("/api/tests", (req, res) => {
    if (!requireTeacherAuth(req, res)) return;
    const {
      title,
      studentClass,
      subject,
      chapter = "",
      durationMinutes = 20,
      questions = [],
      customCode = "",
    } = req.body || {};

    if (!title || !Array.isArray(questions) || questions.length === 0) {
      res.status(400).json({
        error: "Test title and at least 1 question are required.",
      });
      return;
    }

    const cleanedCustom =
      typeof customCode === "string"
        ? customCode.trim().toUpperCase().replace(/[^A-Z0-9-]/g, "")
        : "";

    if (
      cleanedCustom &&
      kvsStore.tests.some(
        (t) => (t.testCode || "").toUpperCase() === cleanedCustom
      )
    ) {
      res.status(400).json({
        error: `Test code "${cleanedCustom}" is already in use. Leave blank to auto-generate or pick another.`,
      });
      return;
    }

    const testCode = cleanedCustom || generateUniqueTestCode();

    const newTest: StudentTest = {
      id: `test-${Date.now()}`,
      testCode,
      title: String(title).trim(),
      studentClass: studentClass || "Class 10",
      subject: subject || "Science",
      chapter: String(chapter || "").trim(),
      durationMinutes: Number(durationMinutes) || 20,
      createdBy: KVS_TEACHER_NAME,
      createdAt: new Date().toISOString(),
      questions: questions as TestQuestion[],
      published: true,
    };

    kvsStore.tests.unshift(newTest);
    saveKvsStore(kvsStore);
    res.json({ test: newTest });
  });

  app.delete("/api/tests/:id", (req, res) => {
    if (!requireTeacherAuth(req, res)) return;
    kvsStore.tests = kvsStore.tests.filter((t) => t.id !== req.params.id);
    kvsStore.submissions = kvsStore.submissions.filter(
      (s) => s.testId !== req.params.id
    );
    saveKvsStore(kvsStore);
    res.json({ ok: true });
  });

  // Student submits a test & receives instant grading + explanations
  app.post("/api/tests/:id/submit", (req, res) => {
    const test = kvsStore.tests.find((t) => t.id === req.params.id);
    if (!test) {
      res.status(404).json({ error: "Test not found." });
      return;
    }

    const {
      studentId = "",
      studentName,
      rollNumber = "",
      answers = [],
    } = req.body || {};
    if (!studentName || typeof studentName !== "string" || !studentName.trim()) {
      res.status(400).json({ error: "Please enter your name before submitting." });
      return;
    }

    let score = 0;
    let totalMarks = 0;
    const ansArray = Array.isArray(answers) ? answers : [];

    const review = test.questions.map((q, idx) => {
      const selected = typeof ansArray[idx] === "number" ? ansArray[idx] : -1;
      const isCorrect = selected === q.correctIndex;
      totalMarks += q.marks;
      if (isCorrect) score += q.marks;
      return {
        questionId: q.id,
        question: q.question,
        options: q.options,
        selectedIndex: selected,
        correctIndex: q.correctIndex,
        isCorrect,
        marks: q.marks,
        explanation: q.explanation,
      };
    });

    const submission: TestSubmission = {
      id: `sub-${Date.now()}`,
      testId: test.id,
      studentId: String(studentId || "").trim() || undefined,
      studentName: studentName.trim(),
      studentClass: test.studentClass,
      rollNumber: String(rollNumber || studentId || "").trim(),
      score,
      totalMarks,
      submittedAt: new Date().toISOString(),
      answers: test.questions.map((_, idx) =>
        typeof ansArray[idx] === "number" ? ansArray[idx] : -1
      ),
    };

    kvsStore.submissions.unshift(submission);
    saveKvsStore(kvsStore);

    res.json({ submission, review });
  });

  // ---------------------------------------------------------------------------
  // Vite Middleware (Dev) or Static Dist Serving (Production)
  // ---------------------------------------------------------------------------
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Veritas Desk server listening on http://0.0.0.0:${PORT}`);
  });
}

createServer();
